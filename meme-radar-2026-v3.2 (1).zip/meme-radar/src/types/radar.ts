import type { ChainKey } from "@/lib/chains";

/** Normalised pair, built server-side from DEXScreener data. */
export interface RadarPair {
  chain: ChainKey;
  pairAddress: string;
  dexId: string;
  url: string | null;
  baseAddress: string;
  baseSymbol: string;
  baseName: string;
  quoteAddress: string;
  quoteSymbol: string;
  priceUsd: number;
  priceNative: number;
  change5m: number;
  change1h: number;
  change6h: number;
  change24h: number;
  volume5m: number;
  volume1h: number;
  volume6h: number;
  volume24h: number;
  buys5m: number;
  sells5m: number;
  buys1h: number;
  sells1h: number;
  buys6h: number;
  sells6h: number;
  buys24h: number;
  sells24h: number;
  liquidityUsd: number;
  fdv: number;
  marketCap: number;
  createdAt: number | null;
  imageUrl: string | null;
  boosts: number;
  websites: string[];
  socials: { type: string; url: string }[];
}

export interface SecurityInfo {
  source: "birdeye" | "rugcheck" | "none";
  top10HolderPct: number | null;
  mintable: boolean | null;
  freezable: boolean | null;
  mutableMetadata: boolean | null;
  honeypot: boolean | null;
  buyTax: number | null;
  sellTax: number | null;
  holders: number | null;
  rugcheckScore: number | null;
  rugcheckRisks: string[];
  note?: string;
}

export interface RiskFlag {
  level: "ok" | "warn" | "danger";
  label: string;
}

export interface RiskReport {
  score: number; // 0 (safe) … 100 (very risky)
  grade: "LOW" | "MEDIUM" | "HIGH" | "EXTREME";
  flags: RiskFlag[];
}

export type Timeframe = "1m" | "5m" | "15m" | "1h" | "4h" | "1d";

export interface Candle {
  t: number; // unix ms (candle open)
  o: number;
  h: number;
  l: number;
  c: number;
  v: number; // volume in USD
}

export interface OhlcvResponse {
  candles: Candle[];
  source: "geckoterminal" | "birdeye";
  timeframe: Timeframe;
}

export type LaunchStage = "bonding" | "graduating" | "graduated" | "new-listing";

/** Normalised upcoming / just-launched token from a launchpad adapter. */
export interface LaunchItem {
  chain: ChainKey;
  address: string;
  symbol: string;
  name: string;
  imageUrl: string | null;
  platform: string; // "Pump.fun", "Clanker", "DEXScreener"
  stage: LaunchStage;
  /** Bonding curve progress 0–100 (null when the platform has no curve) */
  progress: number | null;
  marketCapUsd: number | null;
  createdAt: number | null;
  creator: string | null;
  pairAddress: string | null;
  socials: { x: string | null; telegram: string | null; website: string | null };
  description: string;
}

export interface LaunchResponse {
  items: LaunchItem[];
  providers: { name: string; ok: boolean; count: number; error?: string }[];
  updatedAt: number;
}
