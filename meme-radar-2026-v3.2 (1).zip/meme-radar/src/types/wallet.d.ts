export {};

interface Eip1193Provider {
  isMetaMask?: boolean;
  request(args: { method: string; params?: unknown[] | Record<string, unknown> }): Promise<unknown>;
  on?(event: string, cb: (...args: unknown[]) => void): void;
  removeListener?(event: string, cb: (...args: unknown[]) => void): void;
  providers?: Eip1193Provider[];
}

interface PhantomSolana {
  isPhantom?: boolean;
  publicKey?: { toString(): string } | null;
  connect(opts?: { onlyIfTrusted?: boolean }): Promise<{ publicKey: { toString(): string } }>;
  disconnect(): Promise<void>;
  signAndSendTransaction(tx: unknown): Promise<{ signature: string }>;
  on?(event: string, cb: (...args: unknown[]) => void): void;
}

/** qrcodejs 1.0.0 (davidshimjs) global from cdnjs */
interface QRCodeOptions {
  text: string;
  width?: number;
  height?: number;
  colorDark?: string;
  colorLight?: string;
  correctLevel?: number;
}
interface QRCodeInstance {
  clear(): void;
  makeCode(text: string): void;
}
interface QRCodeCtor {
  new (el: HTMLElement, opts: QRCodeOptions | string): QRCodeInstance;
  CorrectLevel: { L: number; M: number; Q: number; H: number };
}

declare global {
  interface Window {
    ethereum?: Eip1193Provider;
    phantom?: { solana?: PhantomSolana; ethereum?: Eip1193Provider };
    solana?: PhantomSolana;
    QRCode?: QRCodeCtor;
  }
  interface WindowEventMap {
    "eip6963:announceProvider": CustomEvent<{
      info: { uuid: string; name: string; icon: string; rdns: string };
      provider: Eip1193Provider;
    }>;
  }
  type EIP1193Provider = Eip1193Provider;
  type PhantomProvider = PhantomSolana;
}
