"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { disconnectSession, hasWalletConnect, startPairing } from "@/lib/walletconnect";

export type WalletKind = "phantom" | "metamask" | "walletconnect";

export interface WalletState {
  kind: WalletKind;
  address: string;
  /** EVM chain id (hex) when known */
  chainId?: string;
  wcTopic?: string;
}

function getPhantom(): PhantomProvider | undefined {
  if (typeof window === "undefined") return undefined;
  const p = window.phantom?.solana ?? window.solana;
  return p?.isPhantom ? p : undefined;
}

/** Prefer MetaMask announced through EIP-6963, then legacy window.ethereum. */
function useEip6963MetaMask() {
  const found = useRef<EIP1193Provider | undefined>(undefined);
  useEffect(() => {
    const onAnnounce = (e: WindowEventMap["eip6963:announceProvider"]) => {
      if (e.detail?.info?.rdns === "io.metamask") found.current = e.detail.provider;
    };
    window.addEventListener("eip6963:announceProvider", onAnnounce);
    window.dispatchEvent(new Event("eip6963:requestProvider"));
    return () => window.removeEventListener("eip6963:announceProvider", onAnnounce);
  }, []);
  return useCallback((): EIP1193Provider | undefined => {
    if (found.current) return found.current;
    const eth = window.ethereum;
    if (!eth) return undefined;
    if (eth.providers?.length) return eth.providers.find((p) => p.isMetaMask) ?? eth.providers[0];
    return eth;
  }, []);
}

export function useWallet() {
  const [wallet, setWallet] = useState<WalletState | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [wcUri, setWcUri] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const getMetaMask = useEip6963MetaMask();

  const connectPhantom = useCallback(async () => {
    setError(null);
    const p = getPhantom();
    if (!p) {
      // Mobile: open this page inside Phantom's in-app browser.
      const url = encodeURIComponent(window.location.href);
      const ref = encodeURIComponent(window.location.origin);
      if (/Android|iPhone|iPad/i.test(navigator.userAgent)) {
        window.location.href = `https://phantom.app/ul/browse/${url}?ref=${ref}`;
        return;
      }
      setError("Phantom not found. Install it from phantom.com");
      return;
    }
    setBusy(true);
    try {
      const res = await p.connect();
      setWallet({ kind: "phantom", address: res.publicKey.toString() });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Phantom connection rejected");
    } finally {
      setBusy(false);
    }
  }, []);

  const connectMetaMask = useCallback(async () => {
    setError(null);
    const eth = getMetaMask();
    if (!eth) {
      if (/Android|iPhone|iPad/i.test(navigator.userAgent)) {
        window.location.href = `https://metamask.app.link/dapp/${window.location.host}${window.location.pathname}`;
        return;
      }
      setError("MetaMask not found. Install it from metamask.io");
      return;
    }
    setBusy(true);
    try {
      const accounts = (await eth.request({ method: "eth_requestAccounts" })) as string[];
      const chainId = (await eth.request({ method: "eth_chainId" })) as string;
      if (!accounts?.[0]) throw new Error("No account returned");
      setWallet({ kind: "metamask", address: accounts[0], chainId });
    } catch (e) {
      setError(e instanceof Error ? e.message : "MetaMask connection rejected");
    } finally {
      setBusy(false);
    }
  }, [getMetaMask]);

  /** Starts a WalletConnect v2 pairing and exposes the wc: URI for the QR code. */
  const connectWalletConnect = useCallback(async () => {
    setError(null);
    setWcUri(null);
    if (!hasWalletConnect()) {
      setError("NEXT_PUBLIC_WC_PROJECT_ID is not set – showing MetaMask deep-link QR instead.");
      return;
    }
    setBusy(true);
    try {
      const { uri, approval } = await startPairing();
      setWcUri(uri);
      setBusy(false);
      const session = await approval;
      const first = session.accounts[0] ?? "";
      const [, chainRef, address] = first.split(":");
      if (!address) throw new Error("Wallet returned no EVM account");
      setWallet({
        kind: "walletconnect",
        address,
        chainId: `0x${Number(chainRef).toString(16)}`,
        wcTopic: session.topic,
      });
      setWcUri(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "WalletConnect pairing failed");
      setBusy(false);
    }
  }, []);

  const disconnect = useCallback(async () => {
    const w = wallet;
    setWallet(null);
    setWcUri(null);
    if (!w) return;
    if (w.kind === "phantom") await getPhantom()?.disconnect().catch(() => undefined);
    if (w.kind === "walletconnect" && w.wcTopic) await disconnectSession(w.wcTopic);
  }, [wallet]);

  // React to account / chain changes in MetaMask.
  useEffect(() => {
    if (wallet?.kind !== "metamask") return;
    const eth = getMetaMask();
    if (!eth?.on) return;
    const onAccounts = (...args: unknown[]) => {
      const accs = args[0] as string[] | undefined;
      if (!accs?.length) setWallet(null);
      else setWallet((w) => (w ? { ...w, address: accs[0] } : w));
    };
    const onChain = (...args: unknown[]) => setWallet((w) => (w ? { ...w, chainId: String(args[0]) } : w));
    eth.on("accountsChanged", onAccounts);
    eth.on("chainChanged", onChain);
    return () => {
      eth.removeListener?.("accountsChanged", onAccounts);
      eth.removeListener?.("chainChanged", onChain);
    };
  }, [wallet?.kind, getMetaMask]);

  return {
    wallet,
    error,
    busy,
    wcUri,
    connectPhantom,
    connectMetaMask,
    connectWalletConnect,
    disconnect,
    getPhantom,
    getMetaMask,
  };
}

export type UseWallet = ReturnType<typeof useWallet>;
