import { ShieldCheck } from "lucide-react";

export function NonCustodialBanner() {
  return (
    <div
      role="note"
      className="flex items-start gap-3 border-b border-emerald-500/30 bg-emerald-500/10 px-4 py-2 text-xs text-emerald-200 sm:items-center"
    >
      <ShieldCheck className="mt-0.5 size-4 shrink-0 text-emerald-400 sm:mt-0" aria-hidden />
      <p>
        <strong className="font-semibold text-emerald-300">Trung tâm tín hiệu · 100% non-custodial.</strong> Meme Radar chỉ cung cấp dữ
        liệu và tín hiệu: không giữ tiền của bất kỳ ai, không cung cấp thanh khoản, không hỏi seed phrase, không tự giao dịch. Mọi lệnh do
        bạn tự ký trong ví của mình. Meme coin rủi ro rất cao, đây không phải lời khuyên tài chính.
      </p>
    </div>
  );
}
