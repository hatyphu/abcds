"use client";

import { useMemo, useState } from "react";
import { ExternalLink, Zap, Route } from "lucide-react";
import { CHAINS } from "@/lib/chains";
import { dexSwapUrl, photonUrl } from "@/lib/links";
import { buildSwapTx, fromRaw, getQuote, toRaw, tokenDecimals, WSOL, type JupQuote } from "@/lib/jupiter";
import { price as fmtPrice } from "@/lib/format";
import type { RadarPair, RiskReport } from "@/types/radar";
import type { UseWallet } from "@/hooks/use-wallet";

type Mode = "direct" | "photon";
type Side = "buy" | "sell";

const SOL_PRESETS = ["0.1", "0.25", "0.5", "1"];
const MAX_SLIPPAGE = 50;

interface Props {
  pair: RadarPair;
  risk: RiskReport;
  w: UseWallet;
  onConnect: () => void;
}

export function TradeTerminal({ pair, risk, w, onConnect }: Props) {
  const [mode, setMode] = useState<Mode>("direct");
  const [side, setSide] = useState<Side>("buy");
  const [amount, setAmount] = useState("0.1");
  const [slippage, setSlippage] = useState("10");
  const [quote, setQuote] = useState<JupQuote | null>(null);
  const [quoteDecimals, setQuoteDecimals] = useState<{ in: number; out: number } | null>(null);
  const [status, setStatus] = useState<{ kind: "info" | "error" | "ok"; text: string; sig?: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [ack, setAck] = useState(false);

  const chain = CHAINS[pair.chain];
  const isSol = pair.chain === "solana";
  const photon = photonUrl(pair.chain, pair.pairAddress);
  const highRisk = risk.grade === "HIGH" || risk.grade === "EXTREME";
  const slipNum = Number(slippage);
  const slippageValid = Number.isFinite(slipNum) && slipNum > 0 && slipNum <= MAX_SLIPPAGE;
  const amountValid = /^\d+(\.\d+)?$/.test(amount.trim()) && Number(amount) > 0 && Number(amount) <= 1_000_000_000;

  const walletOk = useMemo(() => {
    if (!w.wallet) return false;
    return isSol ? w.wallet.kind === "phantom" : w.wallet.kind !== "phantom";
  }, [w.wallet, isSol]);

  const reset = () => {
    setQuote(null);
    setStatus(null);
  };

  async function fetchQuote() {
    if (!amountValid || !slippageValid) return;
    setBusy(true);
    setStatus({ kind: "info", text: "Fetching Jupiter route…" });
    try {
      const tokenDec = await tokenDecimals(pair.baseAddress);
      const inMint = side === "buy" ? WSOL : pair.baseAddress;
      const outMint = side === "buy" ? pair.baseAddress : WSOL;
      const dec = side === "buy" ? { in: 9, out: tokenDec } : { in: tokenDec, out: 9 };
      const q = await getQuote(inMint, outMint, toRaw(amount, dec.in), Math.round(slipNum * 100));
      setQuote(q);
      setQuoteDecimals(dec);
      setStatus(null);
    } catch (e) {
      setStatus({ kind: "error", text: e instanceof Error ? e.message : "Quote failed" });
    } finally {
      setBusy(false);
    }
  }

  async function executeSolana() {
    if (!quote || !w.wallet || w.wallet.kind !== "phantom") return;
    const phantom = w.getPhantom();
    if (!phantom) {
      setStatus({ kind: "error", text: "Phantom not available" });
      return;
    }
    setBusy(true);
    setStatus({ kind: "info", text: "Building transaction… confirm in Phantom." });
    try {
      const b64 = await buildSwapTx(quote, w.wallet.address);
      const { VersionedTransaction } = await import("@solana/web3.js");
      const bytes = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
      const tx = VersionedTransaction.deserialize(bytes);
      const { signature } = await phantom.signAndSendTransaction(tx);
      setStatus({ kind: "ok", text: "Transaction sent", sig: signature });
      setQuote(null);
    } catch (e) {
      setStatus({ kind: "error", text: e instanceof Error ? e.message : "Transaction rejected" });
    } finally {
      setBusy(false);
    }
  }

  const priceImpact = quote ? Number(quote.priceImpactPct) * 100 : 0;
  const outAmount = quote && quoteDecimals ? fromRaw(quote.outAmount, quoteDecimals.out) : 0;

  return (
    <section className="rounded-xl border border-zinc-800 bg-zinc-950" aria-label="Trading terminal">
      <div className="grid grid-cols-2 border-b border-zinc-800 text-sm">
        <TabBtn active={mode === "direct"} onClick={() => setMode("direct")} icon={<Zap className="size-4" />}>
          Direct Trade
        </TabBtn>
        <TabBtn active={mode === "photon"} onClick={() => setMode("photon")} icon={<Route className="size-4" />}>
          Route to Photon
        </TabBtn>
      </div>

      <div className="space-y-3 p-4">
        {highRisk && (
          <label className="flex items-start gap-2 rounded-lg border border-red-500/40 bg-red-500/10 p-2 text-xs text-red-200">
            <input type="checkbox" checked={ack} onChange={(e) => setAck(e.target.checked)} className="mt-0.5" />
            Risk grade {risk.grade} ({risk.score}/100). I understand this token may be a rug or honeypot.
          </label>
        )}

        {mode === "photon" ? (
          <div className="space-y-3 text-sm text-zinc-300">
            <p>Open this pair in Photon&apos;s terminal. You trade there with your own Photon wallet.</p>
            {photon ? (
              <a
                href={photon}
                target="_blank"
                rel="noopener noreferrer"
                aria-disabled={highRisk && !ack}
                onClick={(e) => {
                if (highRisk && !ack) e.preventDefault();
              }}
                className="flex items-center justify-center gap-2 rounded-lg bg-violet-600 py-2.5 font-semibold text-white hover:bg-violet-500 aria-disabled:cursor-not-allowed aria-disabled:opacity-40"
              >
                Open {pair.baseSymbol} in Photon <ExternalLink className="size-4" />
              </a>
            ) : (
              <p className="rounded-lg bg-zinc-900 p-3 text-xs text-zinc-400">
                Photon routes Solana pairs only. Use Direct Trade for {chain.label}.
              </p>
            )}
          </div>
        ) : isSol ? (
          <>
            <div className="grid grid-cols-2 gap-1 rounded-lg bg-zinc-900 p-1 text-sm">
              {(["buy", "sell"] as const).map((s) => (
                <button
                  key={s}
                  onClick={() => {
                    setSide(s);
                    setAmount(s === "buy" ? "0.1" : "");
                    reset();
                  }}
                  className={`rounded-md py-1.5 font-semibold capitalize ${
                    side === s ? (s === "buy" ? "bg-emerald-600 text-white" : "bg-red-600 text-white") : "text-zinc-400"
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
            <label className="block text-xs text-zinc-400">
              Amount ({side === "buy" ? "SOL" : pair.baseSymbol})
              <input
                inputMode="decimal"
                value={amount}
                onChange={(e) => {
                  setAmount(e.target.value.replace(/[^\d.]/g, ""));
                  reset();
                }}
                className="mt-1 w-full rounded-lg border border-zinc-800 bg-zinc-900 px-3 py-2 font-mono text-white outline-none focus:border-emerald-500"
              />
            </label>
            {side === "buy" && (
              <div className="flex gap-1">
                {SOL_PRESETS.map((v) => (
                  <button
                    key={v}
                    onClick={() => {
                      setAmount(v);
                      reset();
                    }}
                    className="flex-1 rounded bg-zinc-900 py-1 text-xs text-zinc-300 hover:bg-zinc-800"
                  >
                    {v}
                  </button>
                ))}
              </div>
            )}
            <label className="block text-xs text-zinc-400">
              Slippage % (max {MAX_SLIPPAGE})
              <input
                inputMode="decimal"
                value={slippage}
                onChange={(e) => {
                  setSlippage(e.target.value.replace(/[^\d.]/g, ""));
                  reset();
                }}
                className="mt-1 w-full rounded-lg border border-zinc-800 bg-zinc-900 px-3 py-2 font-mono text-white outline-none focus:border-emerald-500"
              />
            </label>
            {!slippageValid && <p className="text-xs text-red-400">Slippage must be between 0 and {MAX_SLIPPAGE}%.</p>}

            {quote && quoteDecimals && (
              <div className="space-y-1 rounded-lg bg-zinc-900 p-3 text-xs text-zinc-300">
                <Row k="You receive (est.)" v={`${outAmount.toLocaleString("en-US", { maximumFractionDigits: 6 })} ${side === "buy" ? pair.baseSymbol : "SOL"}`} />
                <Row k="Price impact" v={`${priceImpact.toFixed(2)}%`} warn={priceImpact > 5} />
                <Row k="Route" v={quote.routePlan.map((r) => r.swapInfo.label ?? "?").join(" → ") || "–"} />
                <Row k="Current price" v={fmtPrice(pair.priceUsd)} />
              </div>
            )}

            {!walletOk ? (
              <button onClick={onConnect} className="w-full rounded-lg bg-zinc-800 py-2.5 font-semibold text-white hover:bg-zinc-700">
                Connect Phantom to trade
              </button>
            ) : !quote ? (
              <button
                onClick={fetchQuote}
                disabled={busy || !amountValid || !slippageValid}
                className="w-full rounded-lg bg-sky-600 py-2.5 font-semibold text-white hover:bg-sky-500 disabled:opacity-40"
              >
                {busy ? "Loading…" : "Get quote"}
              </button>
            ) : (
              <button
                onClick={executeSolana}
                disabled={busy || (highRisk && !ack) || priceImpact > 25}
                className={`w-full rounded-lg py-2.5 font-semibold text-white disabled:opacity-40 ${
                  side === "buy" ? "bg-emerald-600 hover:bg-emerald-500" : "bg-red-600 hover:bg-red-500"
                }`}
              >
                {priceImpact > 25 ? "Price impact too high" : `Sign & ${side} in Phantom`}
              </button>
            )}
          </>
        ) : (
          <div className="space-y-3 text-sm text-zinc-300">
            <p>
              Swap {pair.baseSymbol} on {pair.chain === "bsc" ? "PancakeSwap" : "Uniswap"} ({chain.label}) with the connected wallet.
              The token address is pre-filled — verify it before signing.
            </p>
            <code className="block break-all rounded bg-zinc-900 p-2 text-[11px] text-zinc-400">{pair.baseAddress}</code>
            <a
              href={dexSwapUrl(pair.chain, pair.baseAddress)}
              target="_blank"
              rel="noopener noreferrer"
              aria-disabled={highRisk && !ack}
              onClick={(e) => {
                if (highRisk && !ack) e.preventDefault();
              }}
              className="flex items-center justify-center gap-2 rounded-lg bg-emerald-600 py-2.5 font-semibold text-white hover:bg-emerald-500 aria-disabled:cursor-not-allowed aria-disabled:opacity-40"
            >
              Trade on {pair.chain === "bsc" ? "PancakeSwap" : "Uniswap"} <ExternalLink className="size-4" />
            </a>
          </div>
        )}

        {status && (
          <p
            role="status"
            className={`break-all rounded p-2 text-xs ${
              status.kind === "error" ? "bg-red-500/10 text-red-300" : status.kind === "ok" ? "bg-emerald-500/10 text-emerald-300" : "bg-zinc-900 text-zinc-300"
            }`}
          >
            {status.text}
            {status.sig && (
              <>
                {" "}
                <a className="underline" target="_blank" rel="noopener noreferrer" href={`https://solscan.io/tx/${encodeURIComponent(status.sig)}`}>
                  View on Solscan
                </a>
              </>
            )}
          </p>
        )}
      </div>
    </section>
  );
}

function TabBtn(props: { active: boolean; onClick: () => void; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <button
      onClick={props.onClick}
      aria-pressed={props.active}
      className={`flex items-center justify-center gap-1.5 py-2.5 font-medium ${
        props.active ? "border-b-2 border-emerald-400 text-white" : "text-zinc-500 hover:text-zinc-300"
      }`}
    >
      {props.icon}
      {props.children}
    </button>
  );
}

function Row({ k, v, warn }: { k: string; v: string; warn?: boolean }) {
  return (
    <div className="flex justify-between gap-2">
      <span className="text-zinc-500">{k}</span>
      <span className={`text-right font-mono ${warn ? "text-amber-400" : ""}`}>{v}</span>
    </div>
  );
}
