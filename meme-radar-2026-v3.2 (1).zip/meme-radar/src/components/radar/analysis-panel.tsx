"use client";

import { useMemo } from "react";
import { analyzeToken } from "@/lib/analysis";
import { price as fmtPrice } from "@/lib/format";
import type { Candle, RadarPair, SecurityInfo } from "@/types/radar";

interface Props {
  pair: RadarPair;
  security: SecurityInfo | null;
  candles: Candle[] | null;
}

const TONE = {
  good: { text: "text-emerald-300", bar: "bg-emerald-500", ring: "border-emerald-500/40 bg-emerald-500/10" },
  ok: { text: "text-lime-300", bar: "bg-lime-500", ring: "border-lime-500/40 bg-lime-500/10" },
  wait: { text: "text-amber-300", bar: "bg-amber-500", ring: "border-amber-500/40 bg-amber-500/10" },
  bad: { text: "text-red-300", bar: "bg-red-500", ring: "border-red-500/40 bg-red-500/10" },
};

/** Phân tích & dự đoán: điểm tín hiệu Mua / Không mua, lý do và mức giá. */
export function AnalysisPanel({ pair, security, candles }: Props) {
  const a = useMemo(() => analyzeToken(pair, security, candles), [pair, security, candles]);
  const t = TONE[a.tone];

  return (
    <section className={`rounded-xl border p-3 ${t.ring}`} aria-label="Phân tích và dự đoán">
      <div className="flex items-start justify-between gap-2">
        <div>
          <h3 className="text-[11px] font-semibold uppercase tracking-widest text-zinc-400">Phân tích &amp; dự đoán</h3>
          <p className={`mt-1 text-lg font-black tracking-wide ${t.text}`}>{a.verdict}</p>
        </div>
      </div>

      <div className="mt-3">
        <div className="flex justify-between font-mono text-xs">
          <span className="text-emerald-300">Mua {a.buyPct}%</span>
          <span className="text-red-300">Không mua {a.skipPct}%</span>
        </div>
        <div className="mt-1 flex h-2.5 overflow-hidden rounded-full bg-red-500/70" role="img" aria-label={`Mua ${a.buyPct}%, không mua ${a.skipPct}%`}>
          <div className={`h-full ${t.bar}`} style={{ width: `${a.buyPct}%` }} />
        </div>
        <p className="mt-1 text-[10.5px] text-zinc-500">Tỷ lệ = điểm tín hiệu theo trọng số các yếu tố bên dưới, không phải xác suất có lãi.</p>
      </div>

      <div className="mt-3 space-y-1.5 text-[13px] leading-relaxed text-zinc-200">
        {a.summary.map((s) => (
          <p key={s}>{s}</p>
        ))}
      </div>

      {(a.levels.support || a.levels.resistance || a.levels.rsi != null) && (
        <div className="mt-3 grid grid-cols-3 gap-2 text-xs">
          <Lv k="Hỗ trợ gần" v={a.levels.support ? fmtPrice(a.levels.support) : "–"} />
          <Lv k="Kháng cự gần" v={a.levels.resistance ? fmtPrice(a.levels.resistance) : "–"} />
          <Lv k="RSI(14)" v={a.levels.rsi != null ? a.levels.rsi.toFixed(0) : "–"} />
        </div>
      )}

      <details className="mt-3 text-xs">
        <summary className="cursor-pointer text-zinc-400 hover:text-white">Chi tiết {a.factors.length} yếu tố</summary>
        <ul className="mt-2 space-y-2">
          {a.factors.map((f) => (
            <li key={f.key}>
              <div className="flex items-center justify-between gap-2">
                <span className="text-zinc-300">{f.label}</span>
                <span className={`font-mono ${f.value > 0.15 ? "text-emerald-400" : f.value < -0.15 ? "text-red-400" : "text-zinc-400"}`}>
                  {f.value > 0 ? "+" : ""}
                  {(f.value * 10).toFixed(1)}
                </span>
              </div>
              <div className="relative mt-1 h-1 rounded bg-zinc-800">
                <div
                  className={`absolute top-0 h-1 rounded ${f.value >= 0 ? "left-1/2 bg-emerald-500" : "right-1/2 bg-red-500"}`}
                  style={{ width: `${Math.abs(f.value) * 50}%` }}
                />
              </div>
              <p className="mt-0.5 text-[11px] text-zinc-500">{f.detail}</p>
            </li>
          ))}
        </ul>
      </details>

      <p className="mt-3 border-t border-zinc-800 pt-2 text-sm font-semibold text-white">{a.closing}</p>
      <p className="mt-1 text-[10.5px] text-zinc-500">
        Phân tích tự động từ dữ liệu thị trường, không phải lời khuyên tài chính. Meme coin có thể mất toàn bộ giá trị.
      </p>
    </section>
  );
}

function Lv({ k, v }: { k: string; v: string }) {
  return (
    <div className="rounded-lg border border-zinc-800 bg-black/30 px-2 py-1.5">
      <div className="text-[10px] text-zinc-500">{k}</div>
      <div className="truncate font-mono text-zinc-200">{v}</div>
    </div>
  );
}
