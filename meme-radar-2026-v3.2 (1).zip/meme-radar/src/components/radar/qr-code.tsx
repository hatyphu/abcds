"use client";

import Script from "next/script";
import { useEffect, useRef, useState } from "react";

// Exact URL required by the spec. Loaded once, then used via `new QRCode()`.
export const QRCODE_JS_URL = "https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js";

interface Props {
  value: string;
  size?: number;
}

/**
 * Real, scannable QR code rendered by qrcodejs.
 * - Black on pure white + 16px quiet zone (phone cameras / MetaMask Mobile need contrast + margin, even in a dark UI)
 * - qrcodejs 1.0.0 has a known "code length overflow" bug for some input lengths → retry with a lower error-correction level.
 */
export function QrCode({ value, size = 232 }: Props) {
  const ref = useRef<HTMLDivElement>(null);
  // Lazy init: true when the script was already loaded by an earlier mount.
  const [ready, setReady] = useState(() => typeof window !== "undefined" && !!window.QRCode);
  const [loadError, setLoadError] = useState(false);

  useEffect(() => {
    const el = ref.current;
    const QR = window.QRCode;
    if (!ready || !el || !QR || !value) return;
    let drawn = false;
    for (const level of [QR.CorrectLevel.M, QR.CorrectLevel.L]) {
      try {
        el.replaceChildren();
        new QR(el, { text: value, width: size, height: size, colorDark: "#000000", colorLight: "#ffffff", correctLevel: level });
        drawn = true;
        break;
      } catch {
        /* try next level */
      }
    }
    if (!drawn) {
      el.textContent = "Could not render QR code";
      return;
    }
    // qrcodejs swaps its <canvas> for an <img> (data: URI) by itself once the image is ready.
    const img = el.querySelector("img");
    if (img) img.alt = "Wallet QR code";
  }, [ready, value, size]);

  return (
    <>
      <Script
        src={QRCODE_JS_URL}
        strategy="afterInteractive"
        onReady={() => setReady(true)}
        onError={() => setLoadError(true)}
      />
      <div className="inline-block rounded-xl bg-white p-4 shadow-lg" data-testid="qr-wrapper">
        <div ref={ref} data-testid="qr" data-value={value} style={{ width: size, height: size }} />
      </div>
      {loadError && <p className="mt-2 text-xs text-red-400">QR library failed to load from cdnjs.</p>}
    </>
  );
}
