"use client";

import { useState } from "react";
import { usd } from "@/lib/format";
import type { RadarPair } from "@/types/radar";

type Tf = "m5" | "h1" | "h6" | "h24";
const TFS: { key: Tf; label: string }[] = [
  { key: "m5", label: "5m" },
  { key: "h1", label: "1h" },
  { key: "h6", label: "6h" },
  { key: "h24", label: "24h" },
];

const R = 42;
const C = 2 * Math.PI * R;

function pick(p: RadarPair, tf: Tf) {
  switch (tf) {
    case "m5":
      return { b: p.buys5m, s: p.sells5m, v: p.volume5m };
    case "h1":
      return { b: p.buys1h, s: p.sells1h, v: p.volume1h };
    case "h6":
      return { b: p.buys6h, s: p.sells6h, v: p.volume6h };
    default:
      return { b: p.buys24h, s: p.sells24h, v: p.volume24h };
  }
}

/**
 * Donut: buy vs sell pressure as a share of transactions (DEXScreener txns).
 * DEXScreener reports buy/sell COUNTS, not buy/sell volume, so the split is by number of trades;
 * the USD figures beside it are the window's total volume split in the same ratio (an estimate).
 */
export function BuySellDonut({ pair }: { pair: RadarPair }) {
  const [tf, setTf] = useState<Tf>("h1");
  const { b, s, v } = pick(pair, tf);
  const total = b + s;
  const buyShare = total ? b / total : 0.5;
  const buyPct = Math.round(buyShare * 100);
  const sellPct = 100 - buyPct;
  const buyLen = total ? C * buyShare : C / 2;
  const gap = total && b && s ? 1.5 : 0; // small visual gap between the two arcs
  const lead = buyPct >= 55 ? "Mua áp đảo" : sellPct >= 55 ? "Bán áp đảo" : "Cân bằng";
  const leadCls = buyPct >= 55 ? "text-emerald-400" : sellPct >= 55 ? "text-red-400" : "text-zinc-300";

  return (
    <div className="flex flex-wrap items-center gap-4 p-3 sm:flex-nowrap">
      <svg viewBox="0 0 100 100" className="size-28 shrink-0" role="img" aria-label={`Lực mua ${buyPct}%, lực bán ${sellPct}% (${tf})`}>
        <circle cx="50" cy="50" r={R} fill="none" stroke="#27272a" strokeWidth="12" />
        {total > 0 && (
          <>
            <circle
              cx="50"
              cy="50"
              r={R}
              fill="none"
              stroke="#10b981"
              strokeWidth="12"
              strokeDasharray={`${Math.max(0, buyLen - gap)} ${C}`}
              transform="rotate(-90 50 50)"
              strokeLinecap="butt"
            />
            <circle
              cx="50"
              cy="50"
              r={R}
              fill="none"
              stroke="#ef4444"
              strokeWidth="12"
              strokeDasharray={`${Math.max(0, C - buyLen - gap)} ${C}`}
              strokeDashoffset={-buyLen}
              transform="rotate(-90 50 50)"
              strokeLinecap="butt"
            />
          </>
        )}
        <text x="50" y="47" textAnchor="middle" className="fill-white font-mono" fontSize="17" fontWeight="700">
          {total ? `${buyPct}%` : "–"}
        </text>
        <text x="50" y="62" textAnchor="middle" className="fill-zinc-400" fontSize="9">
          lực mua
        </text>
      </svg>

      <div className="min-w-0 flex-1 space-y-2 text-xs">
        <div className="flex items-center justify-between gap-2">
          <h3 className="text-[11px] font-semibold uppercase tracking-widest text-zinc-500">Lực mua / bán</h3>
          <span className={`text-[11px] font-semibold ${leadCls}`}>{total ? lead : "Chưa có giao dịch"}</span>
        </div>
        <div className="grid grid-cols-4 gap-1" role="group" aria-label="Khung thời gian">
          {TFS.map((t) => (
            <button
              key={t.key}
              onClick={() => setTf(t.key)}
              aria-pressed={tf === t.key}
              className={`rounded px-1 py-0.5 font-mono text-[11px] ${tf === t.key ? "bg-zinc-800 text-white" : "text-zinc-500 hover:text-zinc-300"}`}
            >
              {t.label}
            </button>
          ))}
        </div>
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-1.5 text-zinc-300">
            <i className="inline-block size-2.5 rounded-sm bg-emerald-500" /> Mua <b className="font-mono text-emerald-400">{buyPct}%</b>
          </span>
          <span className="font-mono text-zinc-400">
            {b.toLocaleString()} lệnh · ~{usd(v * buyShare)}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-1.5 text-zinc-300">
            <i className="inline-block size-2.5 rounded-sm bg-red-500" /> Bán <b className="font-mono text-red-400">{sellPct}%</b>
          </span>
          <span className="font-mono text-zinc-400">
            {s.toLocaleString()} lệnh · ~{usd(v * (1 - buyShare))}
          </span>
        </div>
        <p className="text-[10px] text-zinc-600">Tỷ lệ theo số lệnh (DEXScreener). Giá trị USD là ước tính từ tổng volume {TFS.find((t) => t.key === tf)?.label}.</p>
      </div>
    </div>
  );
}
