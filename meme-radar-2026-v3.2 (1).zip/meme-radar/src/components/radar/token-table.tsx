"use client";

import { age, pct, price, usd } from "@/lib/format";
import { momentum, scoreRisk } from "@/lib/risk";
import type { RadarPair } from "@/types/radar";
import { TokenLogo } from "./token-logo";

export type SortKey = "hot" | "volume24h" | "liquidityUsd" | "change1h" | "createdAt" | "marketCap";

interface Props {
  pairs: RadarPair[];
  selected: string | null;
  onSelect: (p: RadarPair) => void;
  sort: SortKey;
  onSort: (k: SortKey) => void;
  loading: boolean;
}

const COLS: { key: SortKey | null; label: string; className?: string }[] = [
  { key: null, label: "Token" },
  { key: null, label: "Price", className: "text-right" },
  { key: "change1h", label: "1h", className: "text-right" },
  { key: null, label: "24h", className: "text-right hidden md:table-cell" },
  { key: "volume24h", label: "Vol 24h", className: "text-right" },
  { key: "liquidityUsd", label: "Liq", className: "text-right hidden sm:table-cell" },
  { key: "marketCap", label: "MCap", className: "text-right hidden lg:table-cell" },
  { key: "createdAt", label: "Age", className: "text-right hidden sm:table-cell" },
  { key: null, label: "Txns 1h", className: "text-right hidden lg:table-cell" },
  { key: "hot", label: "🔥", className: "text-right" },
  { key: null, label: "Risk", className: "text-right" },
];

export function TokenTable({ pairs, selected, onSelect, sort, onSort, loading }: Props) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[560px] text-sm">
        <thead className="sticky top-0 z-10 bg-zinc-950 text-xs text-zinc-500">
          <tr>
            {COLS.map((c) => (
              <th key={c.label} className={`px-2 py-2 font-medium ${c.className ?? "text-left"}`}>
                {c.key ? (
                  <button onClick={() => onSort(c.key as SortKey)} className={sort === c.key ? "text-emerald-400" : "hover:text-zinc-300"}>
                    {c.label}
                    {sort === c.key ? " ↓" : ""}
                  </button>
                ) : (
                  c.label
                )}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {loading && pairs.length === 0 &&
            Array.from({ length: 8 }).map((_, i) => (
              <tr key={i} className="border-t border-zinc-900">
                <td colSpan={COLS.length} className="px-2 py-3">
                  <div className="h-4 animate-pulse rounded bg-zinc-900" />
                </td>
              </tr>
            ))}
          {pairs.map((p) => {
            const risk = scoreRisk(p);
            const hot = momentum(p);
            const isSel = selected === p.pairAddress;
            return (
              <tr
                key={`${p.chain}:${p.pairAddress}`}
                onClick={() => onSelect(p)}
                className={`cursor-pointer border-t border-zinc-900 hover:bg-zinc-900/70 ${isSel ? "bg-zinc-900" : ""}`}
              >
                <td className="px-2 py-2">
                  <div className="flex items-center gap-2">
                    <TokenLogo src={p.imageUrl} symbol={p.baseSymbol} size={26} />
                    <div className="min-w-0">
                      <div className="truncate font-semibold text-white">
                        {p.baseSymbol}
                        <span className="ml-1 text-xs font-normal text-zinc-500">/{p.quoteSymbol}</span>
                      </div>
                      <div className="max-w-[140px] truncate text-[11px] text-zinc-500">{p.baseName || p.dexId}</div>
                    </div>
                  </div>
                </td>
                <td className="px-2 py-2 text-right font-mono text-zinc-200">{price(p.priceUsd)}</td>
                <td className={`px-2 py-2 text-right font-mono ${tone(p.change1h)}`}>{pct(p.change1h)}</td>
                <td className={`hidden px-2 py-2 text-right font-mono md:table-cell ${tone(p.change24h)}`}>{pct(p.change24h)}</td>
                <td className="px-2 py-2 text-right font-mono text-zinc-300">{usd(p.volume24h)}</td>
                <td className="hidden px-2 py-2 text-right font-mono text-zinc-300 sm:table-cell">{usd(p.liquidityUsd)}</td>
                <td className="hidden px-2 py-2 text-right font-mono text-zinc-300 lg:table-cell">{usd(p.marketCap || p.fdv)}</td>
                <td className="hidden px-2 py-2 text-right text-zinc-400 sm:table-cell">{age(p.createdAt)}</td>
                <td className="hidden px-2 py-2 text-right font-mono text-xs lg:table-cell">
                  <span className="text-emerald-400">{p.buys1h}</span>/<span className="text-red-400">{p.sells1h}</span>
                </td>
                <td className="px-2 py-2 text-right font-mono text-amber-300">{hot}</td>
                <td className="px-2 py-2 text-right">
                  <RiskBadge grade={risk.grade} />
                </td>
              </tr>
            );
          })}
          {!loading && pairs.length === 0 && (
            <tr>
              <td colSpan={COLS.length} className="px-2 py-10 text-center text-zinc-500">
                No pairs found.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

export function tone(n: number): string {
  return n > 0 ? "text-emerald-400" : n < 0 ? "text-red-400" : "text-zinc-400";
}

export function RiskBadge({ grade }: { grade: string }) {
  const c =
    grade === "LOW"
      ? "bg-emerald-500/15 text-emerald-300"
      : grade === "MEDIUM"
        ? "bg-amber-500/15 text-amber-300"
        : grade === "HIGH"
          ? "bg-orange-500/15 text-orange-300"
          : "bg-red-500/20 text-red-300";
  return <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold ${c}`}>{grade}</span>;
}
