"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { price as fmtPrice } from "@/lib/format";
import type { ChainKey } from "@/lib/chains";
import type { Candle, OhlcvResponse, Timeframe } from "@/types/radar";

const TFS: Timeframe[] = ["1m", "5m", "15m", "1h", "4h", "1d"];
const HEIGHT = 260;
const COLORS = {
  grid: "#212b3d",
  axis: "#5b6780",
  muted: "#8693aa",
  up: "#2fd08a",
  down: "#ff5d6c",
  upVol: "rgba(47,208,138,.28)",
  downVol: "rgba(255,93,108,.28)",
  labelInk: "#0b0f17",
};

interface Props {
  chain: ChainKey;
  pair: string;
  /** Live price from the radar feed: updates the last candle between candle refreshes. */
  livePrice?: number;
  /** Receives the loaded candles (used by the analysis panel). */
  onCandles?: (candles: Candle[] | null) => void;
  /** Extra content shown inside the chart card, under the candles (e.g. buy/sell donut). */
  children?: React.ReactNode;
}

type Loaded = { key: string; candles: Candle[]; source: OhlcvResponse["source"] } | { key: string; error: string };

const strip = (n: number) => fmtPrice(n).replace("$", "");

export function CandleChart({ chain, pair, livePrice, onCandles, children }: Props) {
  const [tf, setTf] = useState<Timeframe>("5m");
  const [data, setData] = useState<Loaded | null>(null);
  const [hover, setHover] = useState<number | null>(null);
  const [width, setWidth] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const key = `${chain}:${pair}:${tf}`;

  // Fetch + poll candles.
  useEffect(() => {
    let stop = false;
    const ctrl = new AbortController();
    const load = () =>
      fetch(`/api/ohlcv?chain=${chain}&pair=${encodeURIComponent(pair)}&tf=${tf}`, { signal: ctrl.signal })
        .then(async (r) => {
          const j = (await r.json()) as OhlcvResponse & { error?: string };
          if (stop) return;
          if (!r.ok || !j.candles) setData((d) => (d && d.key === key && "candles" in d ? d : { key, error: j.error ?? `HTTP ${r.status}` }));
          else setData({ key, candles: j.candles, source: j.source });
        })
        .catch(() => {
          if (!stop && !ctrl.signal.aborted) setData((d) => (d && d.key === key ? d : { key, error: "Chart data unavailable" }));
        });
    void load();
    const id = setInterval(() => document.visibilityState === "visible" && void load(), tf === "1m" ? 15_000 : 30_000);
    return () => {
      stop = true;
      ctrl.abort();
      clearInterval(id);
    };
  }, [chain, pair, tf, key]);

  // Track container width.
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const ro = new ResizeObserver(([entry]) => setWidth(Math.floor(entry.contentRect.width)));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const ready = data && data.key === key && "candles" in data ? data : null;
  const candles = ready ? withLive(ready.candles, livePrice) : null;
  const baseCandles = ready ? ready.candles : null;

  useEffect(() => {
    onCandles?.(baseCandles);
  }, [baseCandles, onCandles]);

  // Draw.
  useEffect(() => {
    const cv = canvasRef.current;
    if (!cv || !candles || candles.length < 2 || width < 50) return;
    draw(cv, candles, width, hover);
  }, [candles, width, hover]);

  const onMove = useCallback(
    (clientX: number) => {
      const cv = canvasRef.current;
      if (!cv || !candles) return;
      const r = cv.getBoundingClientRect();
      const plotW = r.width - 64;
      const i = Math.floor(((clientX - r.left - 6) / plotW) * candles.length);
      setHover(i >= 0 && i < candles.length ? i : null);
    },
    [candles],
  );

  const shown = candles ? candles[hover ?? candles.length - 1] : null;
  const chg = shown ? ((shown.c - shown.o) / shown.o) * 100 : 0;

  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-950">
      <div className="flex flex-wrap items-center gap-1 px-2 pt-2">
        {TFS.map((t) => (
          <button
            key={t}
            onClick={() => {
              setTf(t);
              setHover(null);
            }}
            aria-pressed={tf === t}
            className={`rounded px-2 py-0.5 font-mono text-[11px] ${tf === t ? "bg-zinc-800 text-white" : "text-zinc-500 hover:text-zinc-300"}`}
          >
            {t}
          </button>
        ))}
        {shown && (
          <span className="ml-auto truncate font-mono text-[10.5px] text-zinc-500">
            O <b className="font-medium text-zinc-400">{strip(shown.o)}</b> H <b className="font-medium text-zinc-400">{strip(shown.h)}</b> L{" "}
            <b className="font-medium text-zinc-400">{strip(shown.l)}</b> C{" "}
            <b className={`font-medium ${chg >= 0 ? "text-emerald-400" : "text-red-400"}`}>{strip(shown.c)}</b>
          </span>
        )}
      </div>
      <div ref={wrapRef} className="relative px-1 pb-1">
        <canvas
          ref={canvasRef}
          style={{ height: HEIGHT }}
          className="block w-full cursor-crosshair touch-pan-y"
          aria-label="Candlestick chart"
          onMouseMove={(e) => onMove(e.clientX)}
          onMouseLeave={() => setHover(null)}
          onTouchMove={(e) => onMove(e.touches[0].clientX)}
          onTouchEnd={() => setHover(null)}
        />
        {!candles && (
          <div className="absolute inset-0 flex items-center justify-center text-xs text-zinc-500">
            {data && data.key === key && "error" in data ? data.error : "Loading candles…"}
          </div>
        )}
      </div>
      {ready && (
        <p className="px-3 pb-2 text-[10px] text-zinc-600">
          Candles: {ready.source === "geckoterminal" ? "GeckoTerminal" : "Birdeye"} · {tf}
        </p>
      )}
      {children && <div className="border-t border-zinc-800">{children}</div>}
    </div>
  );
}

/** Patch the last candle with the latest feed price so the chart moves between refreshes. */
function withLive(candles: Candle[], live?: number): Candle[] {
  if (!live || !Number.isFinite(live) || live <= 0 || candles.length === 0) return candles;
  const last = candles[candles.length - 1];
  // Ignore obviously inconsistent prices (different quote / stale pair).
  if (live > last.c * 3 || live < last.c / 3) return candles;
  return [...candles.slice(0, -1), { ...last, c: live, h: Math.max(last.h, live), l: Math.min(last.l, live) }];
}

function draw(cv: HTMLCanvasElement, s: Candle[], w: number, hover: number | null) {
  const dpr = window.devicePixelRatio || 1;
  const h = HEIGHT;
  cv.width = w * dpr;
  cv.height = h * dpr;
  const ctx = cv.getContext("2d");
  if (!ctx) return;
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, w, h);

  const n = s.length;
  const axisW = 58;
  const plotW = w - axisW - 6;
  const volH = 46;
  const priceH = h - volH - 22;
  let mn = Infinity;
  let mx = -Infinity;
  let vmax = 0;
  for (const k of s) {
    mn = Math.min(mn, k.l);
    mx = Math.max(mx, k.h);
    vmax = Math.max(vmax, k.v);
  }
  const pad = (mx - mn) * 0.08 || mx * 0.01;
  mn -= pad;
  mx += pad;
  const step = plotW / n;
  const bw = Math.max(1, Math.min(10, step * 0.66));
  const X = (i: number) => 6 + step * i + step / 2;
  const Y = (v: number) => 6 + (priceH - 6) * (1 - (v - mn) / (mx - mn));

  ctx.font = "10px ui-monospace, SFMono-Regular, Menlo, monospace";
  ctx.lineWidth = 1;
  for (let g = 0; g <= 4; g++) {
    const gv = mn + ((mx - mn) * g) / 4;
    const gy = Y(gv);
    ctx.strokeStyle = COLORS.grid;
    ctx.beginPath();
    ctx.moveTo(6, gy);
    ctx.lineTo(6 + plotW, gy);
    ctx.stroke();
    ctx.fillStyle = COLORS.axis;
    ctx.fillText(strip(gv), w - axisW + 2, gy + 3);
  }

  s.forEach((k, i) => {
    const x = X(i);
    const isUp = k.c >= k.o;
    const vh = vmax ? (k.v / vmax) * (volH - 6) : 0;
    ctx.fillStyle = isUp ? COLORS.upVol : COLORS.downVol;
    ctx.fillRect(x - bw / 2, priceH + volH - vh + 2, bw, vh);
    ctx.strokeStyle = isUp ? COLORS.up : COLORS.down;
    ctx.beginPath();
    ctx.moveTo(Math.round(x) + 0.5, Y(k.h));
    ctx.lineTo(Math.round(x) + 0.5, Y(k.l));
    ctx.stroke();
    const y1 = Y(Math.max(k.o, k.c));
    const y2 = Y(Math.min(k.o, k.c));
    ctx.fillStyle = isUp ? COLORS.up : COLORS.down;
    ctx.fillRect(x - bw / 2, y1, bw, Math.max(1, y2 - y1));
  });

  const last = s[n - 1];
  const ly = Y(last.c);
  const lc = last.c >= last.o ? COLORS.up : COLORS.down;
  ctx.setLineDash([3, 3]);
  ctx.strokeStyle = lc;
  ctx.beginPath();
  ctx.moveTo(6, ly);
  ctx.lineTo(6 + plotW, ly);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.fillStyle = lc;
  ctx.fillRect(w - axisW, ly - 8, axisW, 16);
  ctx.fillStyle = COLORS.labelInk;
  ctx.fillText(strip(last.c), w - axisW + 3, ly + 3);

  ctx.fillStyle = COLORS.axis;
  const daily = n > 1 && s[1].t - s[0].t >= 86_400_000;
  for (let t = 0; t < 4; t++) {
    const idx = Math.floor(((n - 1) * t) / 3);
    const d = new Date(s[idx].t);
    const txt = daily
      ? `${d.getDate()}/${d.getMonth() + 1}`
      : `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
    ctx.fillText(txt, Math.min(Math.max(X(idx) - 14, 6), 6 + plotW - 30), h - 5);
  }

  if (hover != null && hover < n) {
    const hx = X(hover);
    ctx.strokeStyle = COLORS.muted;
    ctx.setLineDash([2, 3]);
    ctx.beginPath();
    ctx.moveTo(hx, 6);
    ctx.lineTo(hx, priceH + volH);
    ctx.stroke();
    ctx.setLineDash([]);
  }
}
