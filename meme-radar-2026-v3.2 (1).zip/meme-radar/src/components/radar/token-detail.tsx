"use client";

import { useEffect, useState } from "react";
import { Copy, ExternalLink } from "lucide-react";
import { CHAINS } from "@/lib/chains";
import { age, pct, price, shortAddr, usd } from "@/lib/format";
import { toolLinks } from "@/lib/links";
import { scoreRisk } from "@/lib/risk";
import type { Candle, RadarPair, SecurityInfo } from "@/types/radar";
import type { UseWallet } from "@/hooks/use-wallet";
import { RiskBadge, tone } from "./token-table";
import { TradeTerminal } from "./trade-terminal";
import { CandleChart } from "./candle-chart";
import { AnalysisPanel } from "./analysis-panel";
import { TokenLogo } from "./token-logo";
import { BuySellDonut } from "./buy-sell-donut";

interface Props {
  pair: RadarPair;
  w: UseWallet;
  onConnect: () => void;
}

export function TokenDetail({ pair, w, onConnect }: Props) {
  const [sec, setSec] = useState<{ key: string; data: SecurityInfo | null } | null>(null);
  const [actTf, setActTf] = useState<ActTf>("h1");
  const [candles, setCandles] = useState<Candle[] | null>(null);
  const secKey = `${pair.chain}:${pair.baseAddress}`;

  useEffect(() => {
    const ctrl = new AbortController();
    fetch(`/api/security?chain=${pair.chain}&address=${encodeURIComponent(pair.baseAddress)}`, { signal: ctrl.signal })
      .then((r) => (r.ok ? (r.json() as Promise<SecurityInfo>) : null))
      .then((data) => setSec({ key: secKey, data }))
      .catch(() => {
        if (!ctrl.signal.aborted) setSec({ key: secKey, data: null });
      });
    return () => ctrl.abort();
  }, [pair.chain, pair.baseAddress, secKey]);

  const security = sec?.key === secKey ? sec.data : null;
  const secLoading = sec?.key !== secKey;
  const risk = scoreRisk(pair, security);
  const chain = CHAINS[pair.chain];
  const cap = pair.marketCap || pair.fdv;

  return (
    <div className="space-y-3">
      <header className="flex items-center gap-3">
        <TokenLogo src={pair.imageUrl} symbol={pair.baseSymbol} size={44} />
        <div className="min-w-0 flex-1">
          <h2 className="truncate text-lg font-bold text-white">
            {pair.baseSymbol} <span className="text-sm font-normal text-zinc-500">{pair.baseName}</span>
          </h2>
          <button
            onClick={() => void navigator.clipboard?.writeText(pair.baseAddress)}
            className="flex items-center gap-1 font-mono text-xs text-zinc-500 hover:text-zinc-300"
            title="Copy token address"
          >
            <span style={{ color: chain.color }}>{chain.short}</span> {shortAddr(pair.baseAddress)} <Copy className="size-3" />
          </button>
        </div>
        <div className="text-right">
          <div className="font-mono text-lg text-white">{price(pair.priceUsd)}</div>
          <div className={`font-mono text-xs ${tone(pair.change24h)}`}>{pct(pair.change24h)} 24h</div>
        </div>
      </header>

      <CandleChart chain={pair.chain} pair={pair.pairAddress} livePrice={pair.priceUsd} onCandles={setCandles}>
        <BuySellDonut pair={pair} />
      </CandleChart>

      <AnalysisPanel pair={pair} security={security} candles={candles} />

      <section className="rounded-xl border border-zinc-800 bg-zinc-950 p-3">
        <h3 className="mb-2 text-[11px] font-semibold uppercase tracking-widest text-zinc-500">Market</h3>
        <div className="grid grid-cols-3 gap-x-3 gap-y-2 text-xs">
          <Kv k="Price USD" v={price(pair.priceUsd)} />
          <Kv k={`Price ${pair.quoteSymbol || chain.native}`} v={pair.priceNative ? pair.priceNative.toPrecision(4) : "–"} />
          <Kv k="DEX" v={pair.dexId || "–"} />
          <Kv k="Market cap" v={usd(pair.marketCap)} />
          <Kv k="FDV" v={usd(pair.fdv)} />
          <Kv k="Liquidity" v={usd(pair.liquidityUsd)} />
          <Kv k="Liq / MCap" v={cap ? `${((pair.liquidityUsd / cap) * 100).toFixed(1)}%` : "–"} />
          <Kv k="Pair age" v={age(pair.createdAt)} />
          <Kv k="Boosts" v={pair.boosts ? String(pair.boosts) : "–"} />
        </div>
      </section>

      <section className="rounded-xl border border-zinc-800 bg-zinc-950 p-3">
        <h3 className="mb-2 text-[11px] font-semibold uppercase tracking-widest text-zinc-500">Activity</h3>
        <div className="mb-2 grid grid-cols-3 gap-1">
          {ACT_TFS.map((t) => (
            <button
              key={t.key}
              onClick={() => setActTf(t.key)}
              aria-pressed={actTf === t.key}
              className={`rounded-lg border px-1 py-1.5 text-center ${actTf === t.key ? "border-amber-400/70" : "border-zinc-800"} bg-black/30`}
            >
              <span className="block text-[10px] text-zinc-500">{t.label}</span>
              <span className={`font-mono text-xs ${tone(t.change(pair))}`}>{pct(t.change(pair))}</span>
            </button>
          ))}
        </div>
        <ActivityBlock pair={pair} tf={actTf} />
      </section>

      {security && <SafetyGrid s={security} chainKind={chain.kind} />}

      <TradeTerminal key={pair.pairAddress} pair={pair} risk={risk} w={w} onConnect={onConnect} />

      <section className="rounded-xl border border-zinc-800 bg-zinc-950 p-3">
        <div className="mb-2 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-white">Risk scan</h3>
          <div className="flex items-center gap-2 text-xs text-zinc-400">
            {risk.score}/100 <RiskBadge grade={risk.grade} />
          </div>
        </div>
        <ul className="flex flex-wrap gap-1.5">
          {risk.flags.map((f) => (
            <li
              key={f.label}
              className={`rounded px-2 py-0.5 text-[11px] ${
                f.level === "danger" ? "bg-red-500/15 text-red-300" : f.level === "warn" ? "bg-amber-500/15 text-amber-300" : "bg-emerald-500/15 text-emerald-300"
              }`}
            >
              {f.label}
            </li>
          ))}
        </ul>
        <p className="mt-2 text-[11px] text-zinc-500">
          {secLoading
            ? "Loading on-chain security (Birdeye / RugCheck)…"
            : security
              ? `Security source: ${security.source}${security.holders ? ` · ${security.holders.toLocaleString()} holders` : ""}${security.note ? ` · ${security.note}` : ""}`
              : "Security data unavailable — score uses market data only."}
        </p>
        {security?.rugcheckRisks.length ? (
          <ul className="mt-1 list-inside list-disc text-[11px] text-amber-300/90">
            {security.rugcheckRisks.map((r) => (
              <li key={r}>{r}</li>
            ))}
          </ul>
        ) : null}
      </section>

      <section className="flex flex-wrap gap-1.5">
        {toolLinks(pair.chain, pair.baseAddress, pair.pairAddress).map((l) => (
          <a
            key={l.name}
            href={l.url}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 rounded-md border border-zinc-800 bg-zinc-900 px-2 py-1 text-xs text-zinc-300 hover:border-zinc-600 hover:text-white"
          >
            {l.name} <ExternalLink className="size-3" />
          </a>
        ))}
        {[...pair.websites.map((u) => ({ type: "web", url: u })), ...pair.socials].map((s) => (
          <a
            key={s.url}
            href={s.url}
            target="_blank"
            rel="noopener noreferrer nofollow"
            className="rounded-md border border-zinc-800 px-2 py-1 text-xs capitalize text-zinc-400 hover:text-white"
          >
            {s.type}
          </a>
        ))}
      </section>
    </div>
  );
}

type ActTf = "m5" | "h1" | "h24";
const ACT_TFS: { key: ActTf; label: string; change: (p: RadarPair) => number }[] = [
  { key: "m5", label: "5m", change: (p) => p.change5m },
  { key: "h1", label: "1h", change: (p) => p.change1h },
  { key: "h24", label: "24h", change: (p) => p.change24h },
];

function Kv({ k, v, cls }: { k: string; v: string; cls?: string }) {
  return (
    <div className="min-w-0">
      <div className="text-[10.5px] text-zinc-500">{k}</div>
      <div className={`truncate font-mono text-zinc-200 ${cls ?? ""}`}>{v}</div>
    </div>
  );
}

function ActivityBlock({ pair, tf }: { pair: RadarPair; tf: ActTf }) {
  const data = {
    m5: { b: pair.buys5m, s: pair.sells5m, v: pair.volume5m },
    h1: { b: pair.buys1h, s: pair.sells1h, v: pair.volume1h },
    h24: { b: pair.buys24h, s: pair.sells24h, v: pair.volume24h },
  }[tf];
  const tot = data.b + data.s;
  const share = tot ? data.b / tot : 0.5;
  return (
    <div className="space-y-2 text-xs">
      <div className="grid grid-cols-3 gap-3">
        <Kv k="Volume" v={usd(data.v)} />
        <Kv k="Txns" v={tot.toLocaleString()} />
        <Kv k="Avg trade" v={tot ? usd(data.v / tot) : "–"} />
      </div>
      <div className="flex justify-between text-[11px] text-zinc-500">
        <span>
          Buys <b className="font-mono text-emerald-400">{data.b.toLocaleString()}</b>
        </span>
        <span>
          <b className="font-mono text-red-400">{data.s.toLocaleString()}</b> Sells
        </span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-red-500/80" role="img" aria-label={`Buy share ${(share * 100).toFixed(0)}%`}>
        <div className="h-full bg-emerald-500" style={{ width: `${(share * 100).toFixed(1)}%` }} />
      </div>
    </div>
  );
}

function SafetyGrid({ s, chainKind }: { s: SecurityInfo; chainKind: "svm" | "evm" }) {
  const cell = (k: string, v: string, lvl: "ok" | "warn" | "bad" | "none") => ({ k, v, lvl });
  const yesNo = (b: boolean | null, bad: string, good: string) => (b == null ? "–" : b ? bad : good);
  const lvl = (b: boolean | null): "ok" | "bad" | "none" => (b == null ? "none" : b ? "bad" : "ok");
  const cells = [
    cell("Holders", s.holders != null ? s.holders.toLocaleString() : "–", "none"),
    cell("Top 10", s.top10HolderPct != null ? `${s.top10HolderPct.toFixed(1)}%` : "–",
      s.top10HolderPct == null ? "none" : s.top10HolderPct > 50 ? "bad" : s.top10HolderPct > 30 ? "warn" : "ok"),
    cell("Mint auth", yesNo(s.mintable, "Active", "Renounced"), lvl(s.mintable)),
    ...(chainKind === "svm"
      ? [
          cell("Freeze auth", yesNo(s.freezable, "Active", "None"), lvl(s.freezable)),
          cell("Metadata", yesNo(s.mutableMetadata, "Mutable", "Locked"), s.mutableMetadata ? "warn" : lvl(s.mutableMetadata)),
          cell("RugCheck", s.rugcheckScore != null ? String(Math.round(s.rugcheckScore)) : "–", "none"),
        ]
      : [
          cell("Honeypot", yesNo(s.honeypot, "Yes", "No"), lvl(s.honeypot)),
          cell("Buy tax", s.buyTax != null ? `${s.buyTax.toFixed(1)}%` : "–", s.buyTax == null ? "none" : s.buyTax > 10 ? "bad" : s.buyTax > 3 ? "warn" : "ok"),
          cell("Sell tax", s.sellTax != null ? `${s.sellTax.toFixed(1)}%` : "–", s.sellTax == null ? "none" : s.sellTax > 10 ? "bad" : s.sellTax > 3 ? "warn" : "ok"),
        ]),
  ];
  const color = { ok: "text-emerald-400", warn: "text-amber-300", bad: "text-red-400", none: "text-zinc-200" };
  return (
    <section className="rounded-xl border border-zinc-800 bg-zinc-950 p-3">
      <h3 className="mb-2 text-[11px] font-semibold uppercase tracking-widest text-zinc-500">Holders &amp; safety</h3>
      <div className="grid grid-cols-3 gap-1.5">
        {cells.map((c) => (
          <div key={c.k} className="rounded-lg border border-zinc-800 bg-black/30 px-2 py-1.5">
            <div className="text-[10px] text-zinc-500">{c.k}</div>
            <div className={`font-mono text-xs ${color[c.lvl]}`}>{c.v}</div>
          </div>
        ))}
      </div>
    </section>
  );
}
