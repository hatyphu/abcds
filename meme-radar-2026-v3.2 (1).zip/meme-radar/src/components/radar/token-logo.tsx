"use client";

import { useState } from "react";
import { safeImageUrl } from "@/lib/security";
import { fallbackLogo } from "@/lib/logo-svg";

export { fallbackLogo };

/** Token logo: remote image (https only) with a deterministic generated mascot as fallback. */
export function TokenLogo({ src, symbol, size = 28 }: { src: string | null; symbol: string; size?: number }) {
  const safe = safeImageUrl(src);
  const [failed, setFailed] = useState<string | null>(null);
  const useRemote = safe && failed !== safe;
  return (
    // eslint-disable-next-line @next/next/no-img-element -- remote token logos from arbitrary hosts
    <img
      src={useRemote ? safe : fallbackLogo(symbol)}
      alt=""
      width={size}
      height={size}
      loading="lazy"
      referrerPolicy="no-referrer"
      onError={() => setFailed(safe)}
      className="shrink-0 rounded-full bg-zinc-800 object-cover"
      style={{ width: size, height: size }}
    />
  );
}
