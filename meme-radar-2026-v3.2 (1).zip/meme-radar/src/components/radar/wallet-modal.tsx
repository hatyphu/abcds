"use client";

import { useEffect, useState } from "react";
import { QrCode as QrIcon, Wallet, X } from "lucide-react";
import { QrCode } from "./qr-code";
import { hasWalletConnect } from "@/lib/walletconnect";
import type { UseWallet } from "@/hooks/use-wallet";

interface Props {
  open: boolean;
  onClose: () => void;
  w: UseWallet;
}

export function WalletModal({ open, onClose, w }: Props) {
  const [showQr, setShowQr] = useState(false);
  const [origin, setOrigin] = useState("");

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  // Close automatically once a wallet is connected.
  useEffect(() => {
    if (open && w.wallet) onClose();
  }, [open, w.wallet, onClose]);

  if (!open) return null;

  const wcEnabled = hasWalletConnect();
  // Fallback QR when no WalletConnect projectId: MetaMask Mobile universal link opening this dapp.
  const deepLink = origin ? `https://metamask.app.link/dapp/${origin.replace(/^https?:\/\//, "")}` : "";
  const qrValue = wcEnabled ? w.wcUri : deepLink;

  const startQr = () => {
    setShowQr(true);
    setOrigin(window.location.origin + window.location.pathname);
    if (wcEnabled) void w.connectWalletConnect();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 p-0 sm:items-center sm:p-4" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Connect wallet"
        className="w-full max-w-md rounded-t-2xl border border-zinc-800 bg-zinc-950 p-5 sm:rounded-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-white">Connect wallet</h2>
          <button onClick={onClose} aria-label="Close" className="rounded p-1 text-zinc-400 hover:bg-zinc-800 hover:text-white">
            <X className="size-5" />
          </button>
        </div>

        {!showQr ? (
          <div className="space-y-2">
            <WalletButton label="Phantom" hint="Solana" color="#ab9ff2" onClick={w.connectPhantom} disabled={w.busy} />
            <WalletButton label="MetaMask" hint="BNB · Base · Ethereum" color="#f6851b" onClick={w.connectMetaMask} disabled={w.busy} />
            <WalletButton
              label="WalletConnect"
              hint={wcEnabled ? "Scan with MetaMask Mobile / any WC v2 wallet" : "Scan to open in MetaMask Mobile"}
              color="#3b99fc"
              onClick={startQr}
              disabled={w.busy}
              icon={<QrIcon className="size-5" />}
            />
          </div>
        ) : (
          <div className="flex flex-col items-center text-center">
            {qrValue ? (
              <QrCode value={qrValue} />
            ) : (
              <div className="flex size-[264px] items-center justify-center rounded-xl bg-zinc-900 text-sm text-zinc-400">
                {w.busy ? "Creating pairing…" : "Waiting for pairing URI…"}
              </div>
            )}
            <p className="mt-4 text-sm text-zinc-300">
              {wcEnabled
                ? "Open MetaMask Mobile → tap the scan icon (top right) → scan this code → approve."
                : "Scan with your phone camera or MetaMask Mobile to open Meme Radar inside MetaMask."}
            </p>
            {wcEnabled && qrValue && (
              <button
                className="mt-2 text-xs text-sky-400 underline"
                onClick={() => void navigator.clipboard?.writeText(qrValue)}
              >
                Copy pairing link
              </button>
            )}
            <button className="mt-4 text-sm text-zinc-400 hover:text-white" onClick={() => setShowQr(false)}>
              ← Back
            </button>
          </div>
        )}

        {w.error && <p className="mt-3 rounded bg-red-500/10 p-2 text-xs text-red-300">{w.error}</p>}
        <p className="mt-4 text-[11px] leading-snug text-zinc-500">
          Only connect and sign in your own wallet app. Meme Radar will never ask for your seed phrase.
        </p>
      </div>
    </div>
  );
}

function WalletButton(props: {
  label: string;
  hint: string;
  color: string;
  onClick: () => void;
  disabled?: boolean;
  icon?: React.ReactNode;
}) {
  return (
    <button
      onClick={props.onClick}
      disabled={props.disabled}
      className="flex w-full items-center gap-3 rounded-xl border border-zinc-800 bg-zinc-900 px-4 py-3 text-left transition hover:border-zinc-600 disabled:opacity-50"
    >
      <span className="flex size-9 items-center justify-center rounded-lg text-white" style={{ background: props.color }}>
        {props.icon ?? <Wallet className="size-5" />}
      </span>
      <span>
        <span className="block font-medium text-white">{props.label}</span>
        <span className="block text-xs text-zinc-400">{props.hint}</span>
      </span>
    </button>
  );
}
