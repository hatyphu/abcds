"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Bell, BellOff, ExternalLink, Radar, RefreshCw } from "lucide-react";
import { CHAINS, type ChainKey } from "@/lib/chains";
import { age, shortAddr, usd } from "@/lib/format";
import { launchRisk, STAGE_LABEL } from "@/lib/launch-risk";
import type { LaunchItem, LaunchResponse } from "@/types/radar";
import { RiskBadge } from "./token-table";
import { TokenLogo } from "./token-logo";

const RESCAN_MS = 20_000;

interface Props {
  chain: ChainKey;
  toolbar: React.ReactNode;
  /** Open a launched token in the main radar (search by address). */
  onOpenToken: (address: string) => void;
}

type ScanState = { chain: ChainKey; data: LaunchResponse } | null;

const STEPS = ["Reading launchpad feeds", "Computing bonding-curve progress", "Checking socials & creator", "Scoring early risk"];

/** Renders two grid children: the scan list (left) and the detail panel (right). */
export function LaunchRadar({ chain, toolbar, onOpenToken }: Props) {
  const [scan, setScan] = useState<ScanState>(null);
  const [scanning, setScanning] = useState(false);
  const [step, setStep] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<string | null>(null);
  const [watch, setWatch] = useState<Record<string, true>>({});
  const [autoRescan, setAutoRescan] = useState(true);
  const [toast, setToast] = useState<string | null>(null);
  const prevStage = useRef<Map<string, LaunchItem["stage"]>>(new Map());
  const watchRef = useRef(watch);
  useEffect(() => {
    watchRef.current = watch;
  }, [watch]);

  const data = scan && scan.chain === chain ? scan.data : null;

  const notify = useCallback((msg: string) => {
    setToast(msg);
    setTimeout(() => setToast((t) => (t === msg ? null : t)), 4000);
    try {
      if (typeof Notification !== "undefined" && Notification.permission === "granted") new Notification("Meme Radar", { body: msg });
    } catch {
      /* notifications unavailable */
    }
  }, []);

  const runScan = useCallback(
    async (quiet = false) => {
      if (!quiet) {
        setScanning(true);
        setStep(0);
      }
      setError(null);
      const stepper = quiet ? null : setInterval(() => setStep((s) => Math.min(STEPS.length - 1, s + 1)), 450);
      try {
        const r = await fetch(`/api/launches?chain=${chain}`);
        const j = (await r.json()) as LaunchResponse & { error?: string };
        if (!r.ok && !j.items) throw new Error(j.error ?? `HTTP ${r.status}`);
        // Graduation alerts for watched tokens.
        for (const it of j.items) {
          const k = it.address.toLowerCase();
          const before = prevStage.current.get(k);
          if (watchRef.current[k] && before && before !== "graduated" && it.stage === "graduated") {
            notify(`${it.symbol} graduated on ${it.platform}. It is now tradable on a DEX.`);
          }
          prevStage.current.set(k, it.stage);
        }
        setScan({ chain, data: j });
        if (!quiet) notify(j.items.length ? `Found ${j.items.length} launches on ${CHAINS[chain].label}` : "No launches found right now");
      } catch (e) {
        setError(e instanceof Error ? e.message : "Scan failed");
      } finally {
        if (stepper) clearInterval(stepper);
        setScanning(false);
      }
    },
    [chain, notify],
  );

  // Auto re-scan while results are shown (keeps progress + alerts live).
  useEffect(() => {
    if (!data || !autoRescan) return;
    const id = setInterval(() => {
      if (document.visibilityState === "visible") void runScan(true);
    }, RESCAN_MS);
    return () => clearInterval(id);
  }, [data, autoRescan, runScan]);

  const items = data?.items ?? [];
  const current = items.find((i) => i.address === selected) ?? items[0] ?? null;

  const toggleWatch = (it: LaunchItem) => {
    const k = it.address.toLowerCase();
    setWatch((w) => {
      const next = { ...w };
      if (next[k]) delete next[k];
      else next[k] = true;
      return next;
    });
    if (!watch[k] && typeof Notification !== "undefined" && Notification.permission === "default") {
      void Notification.requestPermission().catch(() => undefined);
    }
  };

  const platforms = [chain === "solana" && "Pump.fun", chain === "base" && "Clanker", "DEXScreener"].filter(Boolean);

  return (
    <>
      <section className="min-w-0 rounded-xl border border-zinc-900 bg-zinc-950">
        {toolbar}
        <div className="space-y-4 p-3 sm:p-4">
          <div className="flex flex-col items-center gap-4 rounded-xl border border-zinc-800 bg-black/40 p-4 text-center sm:flex-row sm:text-left">
            <div className={`relative size-24 shrink-0 overflow-hidden rounded-full border border-sky-500/50 ${scanning ? "animate-pulse" : ""}`}>
              <Radar className={`absolute inset-0 m-auto size-12 text-sky-400 ${scanning ? "animate-spin" : ""}`} style={{ animationDuration: "2.4s" }} />
            </div>
            <div className="min-w-0 flex-1">
              <h2 className="font-bold tracking-wide text-white">LAUNCH RADAR · {CHAINS[chain].label.toUpperCase()}</h2>
              <p className="mt-1 text-xs text-zinc-400">
                Scans {platforms.join(", ")} for tokens on the bonding curve, about to graduate, or just listed. Data refreshes every{" "}
                {RESCAN_MS / 1000}s after a scan.
              </p>
              {scanning && (
                <ul className="mt-2 space-y-0.5 text-[11px]">
                  {STEPS.map((s, i) => (
                    <li key={s} className={i < step ? "text-emerald-400" : i === step ? "text-white" : "text-zinc-600"}>
                      {i < step ? "✓" : i === step ? "›" : "·"} {s}
                    </li>
                  ))}
                </ul>
              )}
              <div className="mt-3 flex flex-wrap items-center justify-center gap-2 sm:justify-start">
                <button
                  onClick={() => void runScan()}
                  disabled={scanning}
                  className="flex items-center gap-2 rounded-lg bg-sky-500 px-4 py-2 text-sm font-bold text-black hover:bg-sky-400 disabled:opacity-60"
                >
                  <RefreshCw className={`size-4 ${scanning ? "animate-spin" : ""}`} />
                  {scanning ? "Scanning…" : data ? "Scan again" : "Scan now"}
                </button>
                {data && (
                  <label className="flex items-center gap-1.5 text-xs text-zinc-400">
                    <input type="checkbox" checked={autoRescan} onChange={(e) => setAutoRescan(e.target.checked)} /> Auto-refresh
                  </label>
                )}
              </div>
            </div>
          </div>

          {error && <p className="rounded bg-red-500/10 p-2 text-xs text-red-300">{error}</p>}

          {data && (
            <div className="flex flex-wrap gap-1.5 text-[11px]">
              {data.providers.map((p) => (
                <span
                  key={p.name}
                  title={p.error}
                  className={`rounded px-2 py-0.5 ${p.ok ? "bg-emerald-500/10 text-emerald-300" : "bg-red-500/10 text-red-300"}`}
                >
                  {p.name}: {p.ok ? `${p.count}` : "unavailable"}
                </span>
              ))}
            </div>
          )}

          {data && items.length === 0 && <p className="text-sm text-zinc-500">No launches right now. Scan again in a minute.</p>}

          <div className="grid gap-2.5 [grid-template-columns:repeat(auto-fill,minmax(240px,1fr))]">
            {items.map((it) => {
              const r = launchRisk(it);
              const isSel = current?.address === it.address;
              const watched = !!watch[it.address.toLowerCase()];
              return (
                <button
                  key={it.address}
                  onClick={() => setSelected(it.address)}
                  aria-pressed={isSel}
                  className={`grid gap-2 rounded-xl border bg-black/40 p-3 text-left transition ${isSel ? "border-sky-400 ring-1 ring-sky-400" : "border-zinc-800 hover:border-zinc-600"}`}
                >
                  <div className="flex items-center gap-2.5">
                    <TokenLogo src={it.imageUrl} symbol={it.symbol} size={36} />
                    <div className="min-w-0">
                      <div className="truncate font-semibold text-white">{it.symbol}</div>
                      <div className="truncate text-[11px] text-zinc-500">{it.name}</div>
                    </div>
                    <span className="ml-auto shrink-0 rounded bg-zinc-800 px-1.5 py-0.5 text-[10px] font-semibold text-zinc-300">{it.platform}</span>
                  </div>
                  <div className="flex items-baseline justify-between text-[11px]">
                    <span className={it.stage === "graduating" ? "font-semibold text-amber-300" : it.stage === "graduated" ? "text-emerald-400" : "text-sky-300"}>
                      {STAGE_LABEL[it.stage]}
                    </span>
                    <span className="font-mono text-zinc-400">
                      {it.marketCapUsd ? usd(it.marketCapUsd) : "–"} · {age(it.createdAt)}
                    </span>
                  </div>
                  {it.progress != null && (
                    <div>
                      <div className="h-1.5 overflow-hidden rounded-full bg-zinc-800">
                        <div className="h-full rounded-full bg-gradient-to-r from-sky-500 to-emerald-400" style={{ width: `${it.progress}%` }} />
                      </div>
                      <div className="mt-0.5 flex justify-between text-[10px] text-zinc-500">
                        <span>Bonding curve</span>
                        <span className="font-mono">{it.progress.toFixed(1)}%</span>
                      </div>
                    </div>
                  )}
                  <div className="flex flex-wrap gap-1">
                    <RiskBadge grade={r.grade} />
                    {watched && <span className="rounded bg-emerald-500/15 px-1.5 text-[10px] text-emerald-300">Alert on</span>}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      <aside className="min-w-0 space-y-3 lg:sticky lg:top-[76px] lg:max-h-[calc(100vh-92px)] lg:overflow-y-auto">
        {current ? (
          <LaunchDetail item={current} watched={!!watch[current.address.toLowerCase()]} onWatch={() => toggleWatch(current)} onOpenToken={onOpenToken} />
        ) : (
          <div className="rounded-xl border border-zinc-900 p-8 text-center text-sm text-zinc-500">
            Press <b className="text-zinc-300">Scan now</b> to find tokens about to launch on {CHAINS[chain].label}.
          </div>
        )}
      </aside>

      {toast && (
        <div role="status" className="fixed bottom-5 left-1/2 z-50 max-w-[calc(100vw-32px)] -translate-x-1/2 rounded-lg border border-zinc-700 bg-zinc-900 px-4 py-2 text-sm text-white shadow-lg">
          {toast}
        </div>
      )}
    </>
  );
}

function LaunchDetail({
  item,
  watched,
  onWatch,
  onOpenToken,
}: {
  item: LaunchItem;
  watched: boolean;
  onWatch: () => void;
  onOpenToken: (address: string) => void;
}) {
  const r = launchRisk(item);
  const c = CHAINS[item.chain];
  const a = encodeURIComponent(item.address);
  const launchpadUrl =
    item.platform === "Pump.fun" ? `https://pump.fun/coin/${a}` : item.platform === "Clanker" ? `https://www.clanker.world/clanker/${a}` : `https://dexscreener.com/${c.dexId}/${a}`;
  const explorer = item.chain === "solana" ? "https://solscan.io/account/" : item.chain === "bsc" ? "https://bscscan.com/address/" : item.chain === "base" ? "https://basescan.org/address/" : "https://etherscan.io/address/";
  const tradable = item.stage === "graduated" || item.stage === "new-listing";

  return (
    <div className="space-y-3">
      <section className="rounded-xl border border-zinc-800 bg-zinc-950 p-3">
        <header className="flex items-center gap-3">
          <TokenLogo src={item.imageUrl} symbol={item.symbol} size={44} />
          <div className="min-w-0 flex-1">
            <h2 className="truncate text-lg font-bold text-white">
              {item.symbol} <span className="text-sm font-normal text-zinc-500">{item.name}</span>
            </h2>
            <button onClick={() => void navigator.clipboard?.writeText(item.address)} className="font-mono text-xs text-zinc-500 hover:text-zinc-300" title="Copy token address">
              <span style={{ color: c.color }}>{c.short}</span> {shortAddr(item.address)}
            </button>
          </div>
          <span className="rounded bg-zinc-800 px-1.5 py-0.5 text-[10px] font-semibold text-zinc-300">{item.platform}</span>
        </header>

        {item.progress != null && (
          <div className="mt-3">
            <div className="flex justify-between text-[11px] text-zinc-400">
              <span>Bonding curve → DEX</span>
              <span className="font-mono text-white">{item.progress.toFixed(1)}%</span>
            </div>
            <div className="mt-1 h-2.5 overflow-hidden rounded-full bg-zinc-800">
              <div className="h-full rounded-full bg-gradient-to-r from-sky-500 to-emerald-400" style={{ width: `${item.progress}%` }} />
            </div>
          </div>
        )}

        <div className="mt-3 grid grid-cols-3 gap-2 text-xs">
          <Kv k="Stage" v={STAGE_LABEL[item.stage]} />
          <Kv k="Market cap" v={item.marketCapUsd ? usd(item.marketCapUsd) : "–"} />
          <Kv k="Age" v={age(item.createdAt)} />
        </div>

        <div className="mt-3 flex flex-wrap gap-1.5 text-xs">
          {item.socials.x && <Ext href={item.socials.x}>X</Ext>}
          {item.socials.telegram && <Ext href={item.socials.telegram}>Telegram</Ext>}
          {item.socials.website && <Ext href={item.socials.website}>Website</Ext>}
          <Ext href={launchpadUrl}>{item.platform}</Ext>
          {item.creator && <Ext href={`${explorer}${encodeURIComponent(item.creator)}`}>Creator {shortAddr(item.creator)}</Ext>}
        </div>
        {item.description && <p className="mt-3 text-xs leading-relaxed text-zinc-400">{item.description}</p>}
      </section>

      <section className="space-y-2 rounded-xl border border-zinc-800 bg-zinc-950 p-3">
        {tradable ? (
          <>
            <p className="text-sm text-zinc-300">{item.symbol} is trading. Open it in the radar to see the chart and trade it yourself.</p>
            <button onClick={() => onOpenToken(item.address)} className="w-full rounded-lg bg-sky-500 py-2.5 font-semibold text-black hover:bg-sky-400">
              Open {item.symbol} in radar
            </button>
          </>
        ) : (
          <p className="text-sm text-zinc-300">
            Still on the bonding curve. Meme Radar never snipes or auto-buys. Turn on an alert and decide yourself after it graduates.
          </p>
        )}
        {item.stage !== "graduated" && (
          <button
            onClick={onWatch}
            className={`flex w-full items-center justify-center gap-2 rounded-lg py-2.5 font-semibold ${watched ? "border border-zinc-700 bg-zinc-900 text-white" : "bg-zinc-800 text-white hover:bg-zinc-700"}`}
          >
            {watched ? <BellOff className="size-4" /> : <Bell className="size-4" />}
            {watched ? "Alert on · tap to turn off" : "Alert me at graduation"}
          </button>
        )}
      </section>

      <section className="rounded-xl border border-zinc-800 bg-zinc-950 p-3">
        <div className="mb-2 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-white">Early risk</h3>
          <div className="flex items-center gap-2 text-xs text-zinc-400">
            {r.score}/100 <RiskBadge grade={r.grade} />
          </div>
        </div>
        <ul className="flex flex-wrap gap-1.5">
          {r.flags.map((f) => (
            <li
              key={f.label}
              className={`rounded px-2 py-0.5 text-[11px] ${f.level === "danger" ? "bg-red-500/15 text-red-300" : f.level === "warn" ? "bg-amber-500/15 text-amber-300" : "bg-emerald-500/15 text-emerald-300"}`}
            >
              {f.label}
            </li>
          ))}
        </ul>
        <p className="mt-2 text-[11px] text-zinc-500">Source: {item.platform} (unofficial API, validated server-side).</p>
      </section>
    </div>
  );
}

function Kv({ k, v }: { k: string; v: string }) {
  return (
    <div className="min-w-0">
      <div className="text-[10.5px] text-zinc-500">{k}</div>
      <div className="truncate font-mono text-zinc-200">{v}</div>
    </div>
  );
}

function Ext({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer nofollow"
      className="inline-flex items-center gap-1 rounded-md border border-zinc-800 bg-zinc-900 px-2 py-1 text-zinc-300 hover:border-zinc-600 hover:text-white"
    >
      {children} <ExternalLink className="size-3" />
    </a>
  );
}
