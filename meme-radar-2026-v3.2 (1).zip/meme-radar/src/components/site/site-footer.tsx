import Link from "next/link";
import { COMPANY, Wordmark } from "./logo";

export function SiteFooter() {
  return (
    <footer className="border-t border-line bg-ink">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:px-6 md:grid-cols-[1.2fr_1fr]">
        <div className="space-y-3">
          <Wordmark />
          <p className="text-sm text-zinc-300">
            Một sản phẩm của <strong className="font-semibold text-white">{COMPANY}</strong>
          </p>
          <p className="max-w-md text-xs leading-relaxed text-zinc-500">
            Meme coin có rủi ro rất cao và có thể mất toàn bộ giá trị. Mọi phân tích, điểm rủi ro và tỷ lệ Mua / Không mua trên Meme Radar
            được tính tự động từ dữ liệu thị trường, chỉ để tham khảo, không phải lời khuyên tài chính. Meme Radar là trung tâm dữ liệu và tín
            hiệu: không giữ tiền của bất kỳ ai, không cung cấp thanh khoản, không khớp lệnh và không giao dịch thay bạn.
          </p>
        </div>
        <div className="grid grid-cols-2 gap-6 text-sm">
          <div className="space-y-2">
            <p className="font-display text-xs font-bold uppercase tracking-widest text-zinc-500">Sản phẩm</p>
            <Link href="/app" className="block text-zinc-300 hover:text-white">
              Terminal
            </Link>
            <a href="/#tinh-nang" className="block text-zinc-300 hover:text-white">
              Tính năng
            </a>
            <a href="/#cach-dung" className="block text-zinc-300 hover:text-white">
              Cách dùng
            </a>
          </div>
          <div className="space-y-2">
            <p className="font-display text-xs font-bold uppercase tracking-widest text-zinc-500">Tin cậy</p>
            <a href="/#an-toan" className="block text-zinc-300 hover:text-white">
              Không giữ tiền · không thanh khoản
            </a>
            <a href="/#hoi-dap" className="block text-zinc-300 hover:text-white">
              Hỏi đáp
            </a>
          </div>
        </div>
      </div>
      <div className="border-t border-line">
        <p className="mx-auto max-w-6xl px-4 py-4 text-[11px] text-zinc-600 sm:px-6">© 2026 {COMPANY}. Meme Radar là sản phẩm của {COMPANY}. Dữ liệu: DEXScreener, GeckoTerminal, Birdeye, RugCheck, Pump.fun, Clanker, Jupiter.</p>
      </div>
    </footer>
  );
}
