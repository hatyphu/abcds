/** Meme Radar mark: a radar scope with an amber sweep and one blip. */
export function LogoMark({ size = 30, animated = true }: { size?: number; animated?: boolean }) {
  return (
    <span className="relative inline-block shrink-0 overflow-hidden rounded-full" style={{ width: size, height: size }} aria-hidden>
      <svg viewBox="0 0 32 32" width={size} height={size} className="absolute inset-0">
        <circle cx="16" cy="16" r="15" fill="#0b0f17" stroke="#f5a524" strokeWidth="1.5" />
        <circle cx="16" cy="16" r="10" fill="none" stroke="#f5a524" strokeOpacity=".28" />
        <circle cx="16" cy="16" r="5" fill="none" stroke="#f5a524" strokeOpacity=".28" />
        <circle cx="21.5" cy="10.5" r="1.6" fill="#2fd08a" />
      </svg>
      <span
        className={`absolute inset-0 ${animated ? "radar-sweep" : ""}`}
        style={{ background: "conic-gradient(from 0deg, rgba(245,165,36,.7), transparent 28%)", borderRadius: "9999px" }}
      />
    </span>
  );
}

export const COMPANY = "Petalabs AI";

export function Wordmark({ sub = true, byline = false }: { sub?: boolean; byline?: boolean }) {
  return (
    <span className="flex items-center gap-2.5">
      <LogoMark />
      <span className="leading-none">
        <span className="block font-display text-[17px] font-bold tracking-wide text-white">
          MEME RADAR <span className="text-brand">2026</span>
        </span>
        {sub && <span className="mt-1 block font-display text-[10px] font-medium uppercase tracking-[0.22em] text-zinc-500">V3.2 Ultimate Fusion</span>}
        {byline && <span className="mt-1 block text-[10px] font-medium tracking-wide text-zinc-500">by {COMPANY}</span>}
      </span>
    </span>
  );
}
