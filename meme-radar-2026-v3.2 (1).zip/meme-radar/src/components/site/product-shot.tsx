import { fallbackLogo } from "@/lib/logo-svg";

// Static illustration of the terminal for the landing hero. Sample data, clearly labelled.
const ROWS = [
  { sym: "GLORP", name: "Glorp the Frog", price: "$0.0₄5355", ch: 18.1, vol: "$486K", hot: 74, risk: "LOW" },
  { sym: "MOCHI", name: "Mochi Seal", price: "$0.0₄1422", ch: 10.9, vol: "$5.75M", hot: 61, risk: "MEDIUM" },
  { sym: "SPUD", name: "Space Potato", price: "$0.000182", ch: -4.2, vol: "$277K", hot: 47, risk: "MEDIUM" },
  { sym: "NEBU", name: "Nebula Cat", price: "$0.001755", ch: -0.6, vol: "$70K", hot: 38, risk: "EXTREME" },
];

const RISK_CLS: Record<string, string> = {
  LOW: "bg-emerald-500/15 text-emerald-300",
  MEDIUM: "bg-amber-500/15 text-amber-300",
  EXTREME: "bg-red-500/20 text-red-300",
};

/** Deterministic candle path for the mini chart (no randomness at render). */
function candles(n = 34) {
  const out: { o: number; c: number; h: number; l: number }[] = [];
  let p = 40;
  for (let i = 0; i < n; i++) {
    const wave = Math.sin(i / 3.2) * 5 + i * 0.9;
    const o = p;
    const c = 40 + wave + ((i * 37) % 7) - 3;
    out.push({ o, c, h: Math.max(o, c) + 2 + (i % 3), l: Math.min(o, c) - 2 - (i % 2) });
    p = c;
  }
  return out;
}

export function ProductShot() {
  const ks = candles();
  const max = Math.max(...ks.map((k) => k.h));
  const min = Math.min(...ks.map((k) => k.l));
  const Y = (v: number) => 6 + ((max - v) / (max - min)) * 88;
  const R = 30;
  const C = 2 * Math.PI * R;
  const buy = 0.68;

  return (
    <figure className="relative">
      <div className="overflow-hidden rounded-2xl border border-line-2 bg-panel shadow-[0_30px_80px_-20px_rgba(0,0,0,.8)]">
        {/* window bar */}
        <div className="flex items-center gap-2 border-b border-line px-4 py-2.5">
          <span className="size-2.5 rounded-full bg-zinc-700" />
          <span className="size-2.5 rounded-full bg-zinc-700" />
          <span className="size-2.5 rounded-full bg-zinc-700" />
          <div className="ml-3 flex gap-1 rounded-md bg-ink p-0.5 font-display text-[10px] font-bold tracking-wider">
            <span className="rounded bg-panel-2 px-2 py-0.5 text-white">● SOL</span>
            <span className="px-2 py-0.5 text-zinc-500">BNB</span>
            <span className="px-2 py-0.5 text-zinc-500">BASE</span>
            <span className="px-2 py-0.5 text-zinc-500">ETH</span>
          </div>
          <span className="ml-auto flex items-center gap-1.5 text-[10px] text-zinc-500">
            <i className="size-1.5 animate-pulse rounded-full bg-emerald-400" /> Live
          </span>
        </div>

        <div className="grid gap-0 md:grid-cols-[1.35fr_1fr]">
          {/* table */}
          <div className="min-w-0 overflow-x-auto border-line md:border-r">
            <table className="w-full min-w-[380px] text-[12px]">
              <thead className="text-[10px] text-zinc-500">
                <tr>
                  <th className="px-3 py-2 text-left font-medium">Token</th>
                  <th className="px-2 py-2 text-right font-medium">Giá</th>
                  <th className="px-2 py-2 text-right font-medium">1h</th>
                  <th className="px-2 py-2 text-right font-medium">Vol</th>
                  <th className="px-3 py-2 text-right font-medium">Rủi ro</th>
                </tr>
              </thead>
              <tbody>
                {ROWS.map((r, i) => (
                  <tr key={r.sym} className={`border-t border-line ${i === 1 ? "bg-panel-2 shadow-[inset_2px_0_0_#f5a524]" : ""}`}>
                    <td className="px-3 py-2">
                      <div className="flex items-center gap-2">
                        {/* eslint-disable-next-line @next/next/no-img-element -- generated data: URI mascot */}
                        <img src={fallbackLogo(r.sym)} alt="" width={22} height={22} className="size-[22px] rounded-full" />
                        <div className="min-w-0">
                          <div className="font-semibold text-white">{r.sym}</div>
                          <div className="truncate text-[10px] text-zinc-500">{r.name}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-2 py-2 text-right font-mono text-zinc-200">{r.price}</td>
                    <td className={`px-2 py-2 text-right font-mono ${r.ch >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                      {r.ch > 0 ? "+" : ""}
                      {r.ch}%
                    </td>
                    <td className="px-2 py-2 text-right font-mono text-zinc-300">{r.vol}</td>
                    <td className="px-3 py-2 text-right">
                      <span className={`rounded px-1.5 py-0.5 font-display text-[9px] font-bold tracking-wider ${RISK_CLS[r.risk]}`}>{r.risk}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <svg viewBox="0 0 340 100" className="block h-28 w-full border-t border-line" preserveAspectRatio="none" aria-hidden>
              {[25, 50, 75].map((y) => (
                <line key={y} x1="0" x2="340" y1={y} y2={y} stroke="#212b3d" strokeWidth="1" />
              ))}
              {ks.map((k, i) => {
                const x = 6 + i * 9.7;
                const up = k.c >= k.o;
                const col = up ? "#2fd08a" : "#ff5d6c";
                return (
                  <g key={i}>
                    <line x1={x} x2={x} y1={Y(k.h)} y2={Y(k.l)} stroke={col} strokeWidth="1" />
                    <rect x={x - 3} y={Y(Math.max(k.o, k.c))} width="6" height={Math.max(1, Math.abs(Y(k.o) - Y(k.c)))} fill={col} />
                  </g>
                );
              })}
            </svg>
          </div>

          {/* detail card */}
          <div className="space-y-3 p-4">
            <div className="flex items-center gap-2.5">
              {/* eslint-disable-next-line @next/next/no-img-element -- generated data: URI mascot */}
              <img src={fallbackLogo("MOCHI")} alt="" width={34} height={34} className="size-[34px] rounded-full" />
              <div>
                <div className="font-display text-base font-bold text-white">MOCHI</div>
                <div className="font-mono text-[11px] text-emerald-400">+153% 24h</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <svg viewBox="0 0 80 80" className="size-20 shrink-0" aria-hidden>
                <circle cx="40" cy="40" r={R} fill="none" stroke="#171f2f" strokeWidth="10" />
                <circle cx="40" cy="40" r={R} fill="none" stroke="#2fd08a" strokeWidth="10" strokeDasharray={`${C * buy - 1.5} ${C}`} transform="rotate(-90 40 40)" />
                <circle
                  cx="40"
                  cy="40"
                  r={R}
                  fill="none"
                  stroke="#ff5d6c"
                  strokeWidth="10"
                  strokeDasharray={`${C * (1 - buy) - 1.5} ${C}`}
                  strokeDashoffset={-C * buy}
                  transform="rotate(-90 40 40)"
                />
                <text x="40" y="44" textAnchor="middle" fill="#fff" fontSize="14" fontWeight="600" fontFamily="ui-monospace, monospace">
                  68%
                </text>
              </svg>
              <div className="text-[11px] leading-relaxed text-zinc-400">
                <div className="font-display text-[10px] font-bold uppercase tracking-widest text-zinc-500">Lực mua / bán · 1h</div>
                <div>
                  <span className="text-emerald-400">Mua 68%</span> · <span className="text-red-400">Bán 32%</span>
                </div>
                <div>700 lệnh mua / 330 lệnh bán</div>
              </div>
            </div>
            <div className="rounded-xl border border-lime-500/30 bg-lime-500/10 p-3">
              <div className="font-display text-[10px] font-bold uppercase tracking-widest text-zinc-400">Phân tích &amp; dự đoán</div>
              <div className="mt-1 font-display text-lg font-bold text-lime-300">CÓ THỂ CÂN NHẮC</div>
              <div className="mt-2 flex justify-between font-mono text-[11px]">
                <span className="text-emerald-300">Mua 64%</span>
                <span className="text-red-300">Không mua 36%</span>
              </div>
              <div className="mt-1 h-2 overflow-hidden rounded-full bg-red-500/70">
                <div className="h-full w-[64%] bg-lime-500" />
              </div>
              <p className="mt-2 text-[11px] text-zinc-300">Quyết định là ở bạn. Chúc bạn x tài khoản!</p>
            </div>
          </div>
        </div>
      </div>
      <figcaption className="mt-2 text-center text-[11px] text-zinc-600">Minh hoạ giao diện với dữ liệu mẫu</figcaption>
    </figure>
  );
}
