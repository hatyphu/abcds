import Link from "next/link";
import { Menu } from "lucide-react";
import { Wordmark } from "./logo";

const NAV = [
  { href: "/#tinh-nang", label: "Tính năng" },
  { href: "/#cach-dung", label: "Cách dùng" },
  { href: "/#an-toan", label: "An toàn" },
  { href: "/#hoi-dap", label: "Hỏi đáp" },
];

/** Marketing header. The mobile menu is a <details> so the page needs no client JS. */
export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-line bg-ink/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center gap-6 px-4 py-3 sm:px-6">
        <Link href="/" aria-label="Meme Radar – trang chủ">
          <Wordmark sub={false} byline />
        </Link>
        <nav className="ml-4 hidden items-center gap-6 text-sm text-zinc-400 md:flex" aria-label="Chính">
          {NAV.map((n) => (
            <a key={n.href} href={n.href} className="hover:text-white">
              {n.label}
            </a>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-2">
          <Link
            href="/app"
            className="rounded-lg bg-brand px-4 py-2 text-sm font-semibold text-brand-ink transition hover:brightness-110"
          >
            Mở Radar
          </Link>
          <details className="relative md:hidden">
            <summary className="flex cursor-pointer list-none items-center rounded-lg border border-line p-2 text-zinc-300 [&::-webkit-details-marker]:hidden" aria-label="Menu">
              <Menu className="size-5" />
            </summary>
            <nav className="absolute right-0 mt-2 grid w-48 gap-1 rounded-xl border border-line-2 bg-panel p-2 text-sm shadow-xl" aria-label="Menu di động">
              {NAV.map((n) => (
                <a key={n.href} href={n.href} className="rounded-md px-3 py-2 text-zinc-300 hover:bg-panel-2 hover:text-white">
                  {n.label}
                </a>
              ))}
            </nav>
          </details>
        </div>
      </div>
    </header>
  );
}
