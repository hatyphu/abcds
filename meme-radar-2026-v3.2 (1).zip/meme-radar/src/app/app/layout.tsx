import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Terminal",
  description: "Radar meme coin trực tiếp: Trending, New pairs, Launch Radar, biểu đồ nến, lực mua bán và phân tích tự động.",
};

export default function TerminalLayout({ children }: { children: React.ReactNode }) {
  return children;
}
