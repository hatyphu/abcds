"use client";

// MEME COIN RADAR 2026 — V3.2 Ultimate Fusion
// GMGN + DEXScreener + Birdeye + Photon + BullX + DEXTools + RugCheck + Bubblemaps
// Multi-chain (Solana / BNB / Base / Ethereum) · Non-custodial · No auto-trading.

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { LogOut, RefreshCw, Rocket, Search, Wallet } from "lucide-react";
import { CHAIN_KEYS, CHAINS, type ChainKey } from "@/lib/chains";
import { shortAddr } from "@/lib/format";
import { momentum } from "@/lib/risk";
import { isValidAddress, isValidSearch } from "@/lib/security";
import { useWallet } from "@/hooks/use-wallet";
import type { RadarPair } from "@/types/radar";
import { NonCustodialBanner } from "@/components/radar/non-custodial-banner";
import { TokenTable, type SortKey } from "@/components/radar/token-table";
import { TokenDetail } from "@/components/radar/token-detail";
import { WalletModal } from "@/components/radar/wallet-modal";
import { LaunchRadar } from "@/components/radar/launch-radar";
import { Wordmark } from "@/components/site/logo";
import Link from "next/link";

type Feed = "trending" | "new" | "gainers" | "launch";
const REFRESH_MS = 20_000;

function sortView(pairs: RadarPair[], feed: Feed, sort: SortKey, now: number): RadarPair[] {
  let list = pairs;
  if (feed === "new") list = list.filter((p) => p.createdAt && now - p.createdAt < 72 * 3_600_000);
  if (feed === "gainers") list = list.filter((p) => p.change1h > 0);
  const val = (p: RadarPair): number => {
    switch (sort) {
      case "hot":
        return momentum(p);
      case "createdAt":
        return p.createdAt ?? 0;
      case "marketCap":
        return p.marketCap || p.fdv;
      default:
        return p[sort];
    }
  };
  return [...list].sort((a, b) => val(b) - val(a));
}

export default function Home() {
  const [chain, setChain] = useState<ChainKey>("solana");
  const [feed, setFeed] = useState<Feed>("trending");
  const [sort, setSort] = useState<SortKey>("hot");
  const [query, setQuery] = useState("");
  const [activeQuery, setActiveQuery] = useState("");
  const [pairs, setPairs] = useState<RadarPair[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [updatedAt, setUpdatedAt] = useState<number | null>(null);
  // Clock used by the "New pairs" filter; updated on each load so render stays pure.
  const [now, setNow] = useState(0);
  const feedRef = useRef(feed);
  const sortRef = useRef(sort);
  useEffect(() => {
    feedRef.current = feed;
    sortRef.current = sort;
  }, [feed, sort]);
  const [selected, setSelected] = useState<RadarPair | null>(null);
  // Token shown when the user has not clicked one yet. Pinned on load so re-sorting never swaps it.
  const [autoPair, setAutoPair] = useState<string | null>(null);
  const [walletOpen, setWalletOpen] = useState(false);
  const w = useWallet();

  const load = useCallback(
    async (signal?: AbortSignal) => {
      setLoading(true);
      setError(null);
      const q = activeQuery.trim();
      let url = `/api/dex?mode=trending&chain=${chain}`;
      if (q && isValidAddress(chain, q)) url = `/api/dex?mode=token&chain=${chain}&address=${encodeURIComponent(q)}`;
      else if (q) url = `/api/dex?mode=search&chain=${chain}&q=${encodeURIComponent(q)}`;
      try {
        const r = await fetch(url, { signal });
        const data = (await r.json()) as { pairs?: RadarPair[]; error?: string; updatedAt?: number };
        if (!r.ok) throw new Error(data.error ?? `HTTP ${r.status}`);
        const t = Date.now();
        const list = data.pairs ?? [];
        setPairs(list);
        setAutoPair((prev) =>
          prev && list.some((p) => p.pairAddress === prev)
            ? prev
            : (sortView(list, feedRef.current, sortRef.current, t)[0]?.pairAddress ?? null),
        );
        setUpdatedAt(data.updatedAt ?? t);
        setNow(t);
      } catch (e) {
        if (signal?.aborted) return;
        setError(e instanceof Error ? e.message : "Failed to load");
      } finally {
        if (!signal?.aborted) setLoading(false);
      }
    },
    [chain, activeQuery],
  );

  useEffect(() => {
    const ctrl = new AbortController();
    const first = setTimeout(() => void load(ctrl.signal), 0);
    const id = setInterval(() => {
      // No background polling while the Launch Radar tab is open (it polls its own feed).
      if (document.visibilityState === "visible" && feedRef.current !== "launch") void load(ctrl.signal);
    }, REFRESH_MS);
    return () => {
      ctrl.abort();
      clearTimeout(first);
      clearInterval(id);
    };
  }, [load]);

  const view = useMemo(() => sortView(pairs, feed, sort, now), [pairs, feed, sort, now]);

  // Keep the selected pair's numbers fresh after each refresh.
  const current = useMemo(() => {
    if (selected) return pairs.find((p) => p.pairAddress === selected.pairAddress) ?? selected;
    return view.find((p) => p.pairAddress === autoPair) ?? view[0] ?? null;
  }, [selected, pairs, view, autoPair]);

  const submitSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const q = query.trim();
    if (q && !isValidSearch(q) && !isValidAddress(chain, q)) {
      setError("Search: letters, numbers, $ . _ - only (or a valid token address)");
      return;
    }
    setSelected(null);
    setAutoPair(null);
    setActiveQuery(q);
  };

  const openWallet = useCallback(() => setWalletOpen(true), []);
  const openToken = useCallback((address: string) => {
    setFeed("trending");
    setSelected(null);
    setAutoPair(null);
    setQuery(address);
    setActiveQuery(address);
  }, []);
  const closeWallet = useCallback(() => setWalletOpen(false), []);

  const toolbar = (
          <div className="flex flex-wrap items-center gap-2 border-b border-zinc-900 px-3 py-2">
            {(["trending", "new", "gainers"] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFeed(f)}
                aria-pressed={feed === f}
                className={`rounded-md px-2.5 py-1 text-xs font-semibold capitalize ${feed === f ? "bg-brand/15 text-brand" : "text-zinc-500 hover:text-zinc-300"}`}
              >
                {f === "trending" ? "🔥 Trending" : f === "new" ? "🆕 New pairs" : "🚀 Gainers"}
              </button>
            ))}
            <button
              onClick={() => setFeed("launch")}
              aria-pressed={feed === "launch"}
              className={`flex items-center gap-1.5 rounded-md px-2.5 py-1 text-xs font-semibold ${feed === "launch" ? "bg-sky-500/15 text-sky-300" : "text-zinc-500 hover:text-zinc-300"}`}
            >
              <Rocket className="size-3.5" /> Launch Radar
            </button>
            {activeQuery && feed !== "launch" && (
              <button onClick={() => { setActiveQuery(""); setQuery(""); }} className="rounded-md bg-zinc-900 px-2 py-1 text-xs text-zinc-300">
                “{activeQuery}” ✕
              </button>
            )}
            {feed !== "launch" && (
            <div className="ml-auto flex items-center gap-2 text-[11px] text-zinc-500">
              {updatedAt && <span>Updated {new Date(updatedAt).toLocaleTimeString()}</span>}
              <button onClick={() => void load()} aria-label="Refresh" className="rounded p-1 hover:bg-zinc-900 hover:text-white">
                <RefreshCw className={`size-3.5 ${loading ? "animate-spin" : ""}`} />
              </button>
            </div>
            )}
          </div>
  );

  return (
    <div className="dark min-h-screen bg-ink text-zinc-200">
      <NonCustodialBanner />

      <header className="sticky top-0 z-30 border-b border-line bg-ink/90 backdrop-blur">
        <div className="mx-auto flex max-w-[1600px] flex-wrap items-center gap-3 px-4 py-3">
          <Link href="/" className="mr-2" aria-label="Meme Radar – trang chủ">
            <h1 className="sr-only">Meme Radar 2026 Terminal</h1>
            <Wordmark />
          </Link>

          <nav className="flex gap-1 rounded-lg border border-line bg-panel p-1" aria-label="Chain">
            {CHAIN_KEYS.map((k) => (
              <button
                key={k}
                onClick={() => {
                  setChain(k);
                  setSelected(null);
                  setAutoPair(null);
                  setActiveQuery("");
                  setQuery("");
                }}
                aria-pressed={chain === k}
                className={`rounded-md px-2.5 py-1 font-display text-xs font-bold tracking-wider ${chain === k ? "bg-panel-2 text-white" : "text-zinc-500 hover:text-zinc-300"}`}
              >
                <span className="mr-1 inline-block size-2 rounded-full" style={{ background: CHAINS[k].color }} />
                {CHAINS[k].short}
              </button>
            ))}
          </nav>

          <form onSubmit={submitSearch} className="order-last flex w-full items-center gap-2 rounded-lg border border-zinc-800 bg-zinc-950 px-3 sm:order-none sm:w-auto sm:flex-1" role="search">
            <Search className="size-4 text-zinc-500" aria-hidden />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value.slice(0, 64))}
              placeholder={`Search token or paste ${CHAINS[chain].label} address…`}
              className="w-full bg-transparent py-2 text-sm text-white outline-none placeholder:text-zinc-600"
              aria-label="Search tokens"
              spellCheck={false}
              autoComplete="off"
            />
          </form>

          <div className="ml-auto flex items-center gap-2">
            {w.wallet ? (
              <div className="flex items-center gap-1 rounded-lg border border-zinc-800 bg-zinc-950 pl-3">
                <span className="font-mono text-xs text-zinc-300">
                  {w.wallet.kind === "phantom" ? "◎" : "Ξ"} {shortAddr(w.wallet.address)}
                </span>
                <button onClick={() => void w.disconnect()} aria-label="Disconnect" className="p-2 text-zinc-500 hover:text-white">
                  <LogOut className="size-4" />
                </button>
              </div>
            ) : (
              <button onClick={openWallet} className="flex items-center gap-2 rounded-lg bg-brand px-3 py-2 text-sm font-semibold text-brand-ink hover:brightness-110">
                <Wallet className="size-4" /> Connect
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="mx-auto grid max-w-[1600px] gap-4 px-4 py-4 lg:grid-cols-[minmax(0,1fr)_420px]">
        {feed === "launch" ? (
          <LaunchRadar key={chain} chain={chain} toolbar={toolbar} onOpenToken={openToken} />
        ) : (
          <>
        <section className="min-w-0 rounded-xl border border-line bg-panel">
          {toolbar}
          {error && <p className="border-b border-zinc-900 bg-red-500/10 px-3 py-2 text-xs text-red-300">{error}</p>}
          <TokenTable
            pairs={view}
            selected={current?.pairAddress ?? null}
            onSelect={setSelected}
            sort={sort}
            onSort={setSort}
            loading={loading}
          />
          <p className="border-t border-zinc-900 px-3 py-2 text-[10px] text-zinc-600">
            Data: DEXScreener (public API) · Security: Birdeye &amp; RugCheck · Links: GMGN, DEXTools, Bubblemaps, Photon, BullX-style terminal.
          </p>
        </section>

        <aside className="min-w-0 lg:sticky lg:top-[76px] lg:max-h-[calc(100vh-92px)] lg:overflow-y-auto">
          {current ? (
            <TokenDetail key={`${current.chain}:${current.pairAddress}`} pair={current} w={w} onConnect={openWallet} />
          ) : (
            <div className="rounded-xl border border-zinc-900 p-8 text-center text-sm text-zinc-500">Select a token</div>
          )}
        </aside>
          </>
        )}
      </main>

      <WalletModal open={walletOpen} onClose={closeWallet} w={w} />
      <footer className="border-t border-line px-4 py-4 text-center text-[11px] text-zinc-600">
        Meme Radar · sản phẩm của Petalabs AI. Meme coin có rủi ro rất cao. Phân tích tự động, không phải lời khuyên tài chính. Meme Radar không giữ tiền và không giao dịch thay bạn.{" "}
        <Link href="/" className="text-zinc-400 underline hover:text-white">
          Về trang chủ
        </Link>
      </footer>
    </div>
  );
}
