import type { Metadata, Viewport } from "next";
import { Chakra_Petch, IBM_Plex_Mono, IBM_Plex_Sans } from "next/font/google";
import "./globals.css";

// Vietnamese subsets so diacritics render in the brand faces.
const chakra = Chakra_Petch({ variable: "--font-chakra", weight: ["500", "700"], subsets: ["latin", "vietnamese"], display: "swap" });
const plexSans = IBM_Plex_Sans({ variable: "--font-plex-sans", weight: ["400", "500", "600"], subsets: ["latin", "vietnamese"], display: "swap" });
const plexMono = IBM_Plex_Mono({ variable: "--font-plex-mono", weight: ["400", "500"], subsets: ["latin", "vietnamese"], display: "swap" });

export const metadata: Metadata = {
  title: { default: "Meme Radar 2026 · Radar meme coin đa chuỗi", template: "%s · Meme Radar 2026" },
  description:
    "Radar meme coin cho Solana, BNB, Base và Ethereum: biểu đồ nến, lực mua bán, phân tích tự động, quét rủi ro và Launch Radar. Trung tâm tín hiệu: không giữ tiền, không cung cấp thanh khoản.",
  openGraph: {
    title: "Meme Radar 2026 · Petalabs AI",
    siteName: "Meme Radar by Petalabs AI",
    description: "Trung tâm dữ liệu & tín hiệu AI Radar cho meme coin đa chuỗi. Không giữ tiền, không cung cấp thanh khoản.",
    type: "website",
    locale: "vi_VN",
  },
  applicationName: "Meme Radar",
  authors: [{ name: "Petalabs AI" }],
  creator: "Petalabs AI",
  publisher: "Petalabs AI",
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  themeColor: "#0b0f17",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="vi" className={`${chakra.variable} ${plexSans.variable} ${plexMono.variable} dark h-full antialiased`}>
      <body className="flex min-h-full flex-col bg-ink font-sans">{children}</body>
    </html>
  );
}
