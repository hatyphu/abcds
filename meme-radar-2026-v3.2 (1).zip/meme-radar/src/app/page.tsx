import Link from "next/link";
import { Activity, ArrowRight, Check, Gauge, Radar, Rocket, ShieldAlert, Wallet, X } from "lucide-react";
import { SiteHeader } from "@/components/site/site-header";
import { SiteFooter } from "@/components/site/site-footer";
import { ProductShot } from "@/components/site/product-shot";
import { LogoMark } from "@/components/site/logo";

// Landing page (server component, no client JS). The live terminal lives at /app.

const FACTS = [
  { n: "4", l: "chuỗi: Solana, BNB, Base, Ethereum" },
  { n: "6", l: "khung nến từ 1 phút đến 1 ngày" },
  { n: "9", l: "yếu tố trong mỗi lần phân tích" },
  { n: "0", l: "đồng tiền của khách do Meme Radar giữ" },
];

const SOURCES = ["DEXScreener", "GeckoTerminal", "Birdeye", "RugCheck", "Pump.fun", "Clanker", "Jupiter"];

const FEATURES = [
  {
    icon: Radar,
    title: "Radar đa chuỗi",
    body: "Trending, New pairs và Gainers cho Solana, BNB, Base, Ethereum, cập nhật mỗi 20 giây. Tìm theo tên hoặc dán địa chỉ hợp đồng.",
  },
  {
    icon: Activity,
    title: "Nến & lực mua / bán",
    body: "Biểu đồ nến 1m đến 1d có volume, hover xem giá mở/cao/thấp/đóng. Biểu đồ tròn chia lực mua và lực bán theo 5m, 1h, 6h, 24h.",
  },
  {
    icon: Gauge,
    title: "Phân tích & dự đoán",
    body: "Bấm vào token là có kết luận Nên mua, Cân nhắc, Theo dõi hoặc Không nên mua, kèm tỷ lệ Mua / Không mua và lý do cụ thể.",
  },
  {
    icon: ShieldAlert,
    title: "Quét rủi ro",
    body: "Honeypot, thuế bán, quyền mint và freeze, top 10 ví nắm giữ, thanh khoản mỏng. Dữ liệu từ Birdeye và RugCheck, chấm điểm 0 đến 100.",
  },
  {
    icon: Rocket,
    title: "Launch Radar",
    body: "Quét token đang trên bonding curve Pump.fun, token mới trên Clanker và DEXScreener. Bật cảnh báo để biết lúc token graduate.",
  },
  {
    icon: Wallet,
    title: "Giao dịch không lưu ký",
    body: "Kết nối Phantom, MetaMask hoặc quét QR WalletConnect. Mua bán qua Jupiter, Uniswap, PancakeSwap hoặc mở thẳng Photon.",
  },
];

const STEPS = [
  { t: "Chọn chuỗi và bảng", d: "Chọn Solana, BNB, Base hoặc Ethereum, rồi xem Trending, New pairs, Gainers hay quét Launch Radar." },
  { t: "Bấm vào token", d: "Xem nến, lực mua bán, điểm rủi ro và kết luận tự động với tỷ lệ Mua / Không mua." },
  { t: "Tự quyết, tự ký lệnh", d: "Nếu muốn giao dịch, bạn xem báo giá rồi ký trong ví của chính mình. Meme Radar không bấm thay bạn." },
];

const NEVER = [
  "Giữ tiền hay token của bất kỳ ai",
  "Cung cấp thanh khoản, làm market maker hay khớp lệnh",
  "Là sàn giao dịch, phát hành hay bán token",
  "Hỏi seed phrase hay private key",
  "Tự mua, tự bán hay snipe token thay bạn",
];

// What Meme Radar is: a data & signal hub.
const IS = [
  { t: "Trung tâm dữ liệu", d: "Đọc dữ liệu công khai trên chuỗi và từ DEXScreener, GeckoTerminal, Birdeye, RugCheck, các launchpad." },
  { t: "Trung tâm tín hiệu", d: "Biến dữ liệu thành tín hiệu: điểm rủi ro, lực mua bán, kết luận Mua / Không mua kèm lý do." },
  { t: "Không đứng giữa giao dịch", d: "Lệnh đi thẳng từ ví của bạn tới DEX (Jupiter, Uniswap, PancakeSwap). Tiền không đi qua Meme Radar." },
];

const GUARDS = [
  "Phát hiện honeypot và thuế bán cao, hạ điểm Mua xuống gần 0",
  "Bắt xác nhận trước khi giao dịch token rủi ro HIGH / EXTREME",
  "Chặn lệnh khi price impact trên 25%, giới hạn slippage tối đa 50%",
  "API key của nguồn dữ liệu chỉ nằm trên server, không lộ ra trình duyệt",
];

const FAQ = [
  {
    q: "Meme Radar là gì? Có phải sàn giao dịch không?",
    a: "Không. Meme Radar là trung tâm dữ liệu và tín hiệu AI Radar: chúng tôi tổng hợp dữ liệu, chấm điểm rủi ro và đưa ra tín hiệu. Chúng tôi không giữ tiền của bất kỳ ai, không cung cấp thanh khoản, không khớp lệnh và không phát hành token.",
  },
  {
    q: "Meme Radar có mất phí không?",
    a: "Bạn mở Radar và dùng ngay, không cần tạo tài khoản. Khi giao dịch, bạn chỉ trả phí mạng và phí của sàn DEX như bình thường.",
  },
  {
    q: "Tỷ lệ \"Mua 64%\" có phải là xác suất có lãi?",
    a: "Không. Đó là điểm tín hiệu tổng hợp từ 9 yếu tố: động lượng giá, lực mua bán, thanh khoản, xu hướng nến, RSI, an toàn hợp đồng… Điểm cao nghĩa là nhiều yếu tố đang tích cực, không phải lời hứa về lợi nhuận.",
  },
  {
    q: "Tiền của tôi có đi qua Meme Radar không?",
    a: "Không. Khi bạn giao dịch, lệnh đi thẳng từ ví của bạn tới DEX (Jupiter, Uniswap, PancakeSwap) hoặc Photon. Meme Radar không có quyền truy cập ví và không tự giao dịch thay bạn.",
  },
  {
    q: "Tôi dùng ví nào được?",
    a: "Phantom cho Solana; MetaMask cho BNB Chain, Base và Ethereum; hoặc bất kỳ ví hỗ trợ WalletConnect v2 bằng cách quét mã QR, ví dụ MetaMask Mobile.",
  },
  {
    q: "Dữ liệu lấy từ đâu và cập nhật bao lâu một lần?",
    a: "Giá và giao dịch từ DEXScreener (mỗi 20 giây), nến từ GeckoTerminal hoặc Birdeye (15–30 giây), bảo mật hợp đồng từ Birdeye và RugCheck, token sắp ra mắt từ Pump.fun, Clanker và DEXScreener.",
  },
  {
    q: "Launch Radar có báo giờ ra mắt chính xác không?",
    a: "Các launchpad không công bố giờ ra mắt. Launch Radar cho bạn thấy tiến độ bonding curve và giai đoạn của token, rồi báo khi token graduate lên DEX.",
  },
];

export default function Landing() {
  return (
    <div className="min-h-screen bg-ink text-zinc-200">
      <SiteHeader />

      <main>
        {/* Hero */}
        <section className="relative overflow-hidden border-b border-line">
          <div
            aria-hidden
            className="pointer-events-none absolute -top-40 left-1/2 size-[760px] -translate-x-1/2 rounded-full opacity-60"
            style={{
              background:
                "radial-gradient(circle, transparent 0 29%, rgba(245,165,36,.10) 29.5% 30%, transparent 30.5% 49%, rgba(245,165,36,.08) 49.5% 50%, transparent 50.5% 69%, rgba(245,165,36,.06) 69.5% 70%, transparent 70.5%)",
            }}
          />
          <div className="relative mx-auto grid max-w-6xl items-center gap-12 px-4 py-16 sm:px-6 lg:grid-cols-[1fr_1.1fr] lg:py-24">
            <div>
              <p className="font-display text-xs font-bold uppercase tracking-[0.25em] text-brand">Trung tâm tín hiệu AI Radar · Solana · BNB · Base · Ethereum</p>
              <h1 className="mt-4 text-balance font-display text-4xl font-bold leading-[1.08] text-white sm:text-5xl lg:text-[56px]">
                Thấy meme coin sớm hơn. Né rug trước khi quá muộn.
              </h1>
              <p className="mt-5 max-w-xl text-base leading-relaxed text-zinc-400 sm:text-lg">
                Meme Radar là trung tâm dữ liệu và tín hiệu: gom DEXScreener, Birdeye, GeckoTerminal, RugCheck và các launchpad vào một màn hình.
                Mỗi token có biểu đồ nến, lực mua bán, điểm rủi ro và phân tích tự động. Chúng tôi không giữ tiền, không cung cấp thanh khoản; bạn
                tự quyết và tự ký lệnh trong ví của mình.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link
                  href="/app"
                  className="inline-flex items-center gap-2 rounded-xl bg-brand px-6 py-3 font-semibold text-brand-ink transition hover:brightness-110"
                >
                  Mở Radar <ArrowRight className="size-4" />
                </Link>
                <a href="#tinh-nang" className="inline-flex items-center gap-2 rounded-xl border border-line-2 px-6 py-3 font-semibold text-white hover:bg-panel">
                  Xem tính năng
                </a>
              </div>
              <ul className="mt-6 flex flex-wrap gap-x-5 gap-y-2 text-sm text-zinc-400">
                {["Dùng ngay, không cần đăng ký", "Không giữ tiền của ai", "Không cung cấp thanh khoản", "Chỉ cung cấp tín hiệu"].map((t) => (
                  <li key={t} className="flex items-center gap-1.5">
                    <Check className="size-4 text-emerald-400" /> {t}
                  </li>
                ))}
              </ul>
            </div>
            <ProductShot />
          </div>
        </section>

        {/* Facts + sources */}
        <section className="border-b border-line bg-panel/40">
          <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
            <dl className="grid grid-cols-2 gap-6 md:grid-cols-4">
              {FACTS.map((f) => (
                <div key={f.l}>
                  <dt className="font-display text-4xl font-bold text-white">{f.n}</dt>
                  <dd className="mt-1 text-sm text-zinc-400">{f.l}</dd>
                </div>
              ))}
            </dl>
            <div className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-2 border-t border-line pt-6">
              <span className="font-display text-[11px] font-bold uppercase tracking-widest text-zinc-500">Dữ liệu từ</span>
              {SOURCES.map((s) => (
                <span key={s} className="font-mono text-sm text-zinc-300">
                  {s}
                </span>
              ))}
            </div>
          </div>
        </section>

        {/* Features */}
        <section id="tinh-nang" className="scroll-mt-20 border-b border-line">
          <div className="mx-auto max-w-6xl px-4 py-20 sm:px-6">
            <h2 className="max-w-2xl text-balance font-display text-3xl font-bold text-white sm:text-4xl">Mọi thứ bạn cần trước khi bấm mua</h2>
            <p className="mt-3 max-w-2xl text-zinc-400">
              Gộp những gì trader meme thường mở trên nhiều tab (GMGN, DEXScreener, Birdeye, DEXTools, RugCheck, Bubblemaps, Photon) vào một terminal.
            </p>
            <div className="mt-10 grid gap-px overflow-hidden rounded-2xl border border-line bg-line sm:grid-cols-2 lg:grid-cols-3">
              {FEATURES.map((f) => (
                <article key={f.title} className="bg-ink p-6">
                  <f.icon className="size-6 text-brand" aria-hidden />
                  <h3 className="mt-4 font-display text-lg font-bold text-white">{f.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-zinc-400">{f.body}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* How it works */}
        <section id="cach-dung" className="scroll-mt-20 border-b border-line bg-panel/40">
          <div className="mx-auto max-w-6xl px-4 py-20 sm:px-6">
            <h2 className="font-display text-3xl font-bold text-white sm:text-4xl">Ba bước, không cần tài khoản</h2>
            <ol className="mt-10 grid gap-6 md:grid-cols-3">
              {STEPS.map((s, i) => (
                <li key={s.t} className="relative rounded-2xl border border-line bg-ink p-6">
                  <span className="font-mono text-sm text-brand">Bước {i + 1}</span>
                  <h3 className="mt-2 font-display text-lg font-bold text-white">{s.t}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-zinc-400">{s.d}</p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        {/* Safety */}
        <section id="an-toan" className="scroll-mt-20 border-b border-line">
          <div className="mx-auto grid max-w-6xl gap-10 px-4 py-20 sm:px-6 lg:grid-cols-[0.9fr_1.1fr]">
            <div>
              <p className="font-display text-xs font-bold uppercase tracking-[0.25em] text-emerald-400">Tin cậy · 100% non-custodial</p>
              <h2 className="mt-3 text-balance font-display text-3xl font-bold text-white sm:text-4xl">
                Chỉ là trung tâm tín hiệu. Không giữ tiền của bất kỳ ai.
              </h2>
              <p className="mt-4 text-zinc-400">
                Meme Radar là trung tâm dữ liệu và tín hiệu AI Radar của Petalabs AI. Chúng tôi không phải sàn giao dịch, không giữ tiền, không cung
                cấp thanh khoản. Quyết định cuối cùng và chữ ký luôn là của bạn.
              </p>
              <dl className="mt-8 space-y-5">
                {IS.map((x) => (
                  <div key={x.t} className="border-l-2 border-brand pl-4">
                    <dt className="font-display font-bold text-white">{x.t}</dt>
                    <dd className="mt-1 text-sm text-zinc-400">{x.d}</dd>
                  </div>
                ))}
              </dl>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="rounded-2xl border border-red-500/25 bg-red-500/5 p-6">
                <h3 className="font-display text-sm font-bold uppercase tracking-widest text-red-300">Không bao giờ</h3>
                <ul className="mt-4 space-y-3 text-sm text-zinc-300">
                  {NEVER.map((t) => (
                    <li key={t} className="flex gap-2">
                      <X className="mt-0.5 size-4 shrink-0 text-red-400" /> {t}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="rounded-2xl border border-emerald-500/25 bg-emerald-500/5 p-6">
                <h3 className="font-display text-sm font-bold uppercase tracking-widest text-emerald-300">Luôn bảo vệ</h3>
                <ul className="mt-4 space-y-3 text-sm text-zinc-300">
                  {GUARDS.map((t) => (
                    <li key={t} className="flex gap-2">
                      <Check className="mt-0.5 size-4 shrink-0 text-emerald-400" /> {t}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section id="hoi-dap" className="scroll-mt-20 border-b border-line bg-panel/40">
          <div className="mx-auto max-w-3xl px-4 py-20 sm:px-6">
            <h2 className="font-display text-3xl font-bold text-white sm:text-4xl">Hỏi đáp</h2>
            <div className="mt-8 divide-y divide-line rounded-2xl border border-line bg-ink">
              {FAQ.map((f) => (
                <details key={f.q} className="group px-5 py-4">
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-semibold text-white [&::-webkit-details-marker]:hidden">
                    {f.q}
                    <span className="font-mono text-brand transition group-open:rotate-45">+</span>
                  </summary>
                  <p className="mt-3 text-sm leading-relaxed text-zinc-400">{f.a}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* Final CTA */}
        <section className="relative overflow-hidden">
          <div className="mx-auto flex max-w-6xl flex-col items-center px-4 py-20 text-center sm:px-6">
            <LogoMark size={56} />
            <h2 className="mt-6 text-balance font-display text-3xl font-bold text-white sm:text-4xl">Bật radar, xem token nào đang nóng</h2>
            <p className="mt-3 max-w-xl text-zinc-400">Mở terminal, chọn chuỗi và bấm vào token đầu tiên. Không cần đăng ký.</p>
            <Link
              href="/app"
              className="mt-8 inline-flex items-center gap-2 rounded-xl bg-brand px-7 py-3.5 font-semibold text-brand-ink transition hover:brightness-110"
            >
              Mở Radar <ArrowRight className="size-4" />
            </Link>
          </div>
        </section>
      </main>

      <SiteFooter />
    </div>
  );
}
