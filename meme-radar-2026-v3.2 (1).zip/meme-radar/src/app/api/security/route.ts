import { NextResponse } from "next/server";
import { CHAINS, isChainKey } from "@/lib/chains";
import { clientKey, rateLimit } from "@/lib/rate-limit";
import { cleanText, isValidAddress, num } from "@/lib/security";
import type { SecurityInfo } from "@/types/radar";

// GET /api/security?chain=solana&address=<token>
// Birdeye key stays on the server (BIRDEYE_API_KEY) and is never sent to the browser.
// RugCheck public summary is added for Solana tokens (no key).

type Json = Record<string, unknown>;
const obj = (v: unknown): Json => (v && typeof v === "object" && !Array.isArray(v) ? (v as Json) : {});
const bool = (v: unknown): boolean | null => {
  if (typeof v === "boolean") return v;
  if (v === "1" || v === 1) return true;
  if (v === "0" || v === 0) return false;
  return null;
};
const pct = (v: unknown): number | null => {
  if (v === null || v === undefined || v === "") return null;
  const n = num(v);
  // Birdeye returns ratios (0–1) for most fields.
  return n <= 1 ? n * 100 : n;
};

export async function GET(req: Request) {
  if (!rateLimit(clientKey(req, "sec"), 40, 0.5)) {
    return NextResponse.json({ error: "Too many requests" }, { status: 429 });
  }
  const { searchParams } = new URL(req.url);
  const chain = searchParams.get("chain");
  const address = (searchParams.get("address") ?? "").trim();
  if (!isChainKey(chain) || !isValidAddress(chain, address)) {
    return NextResponse.json({ error: "Invalid chain or address" }, { status: 400 });
  }

  const info: SecurityInfo = {
    source: "none",
    top10HolderPct: null,
    mintable: null,
    freezable: null,
    mutableMetadata: null,
    honeypot: null,
    buyTax: null,
    sellTax: null,
    holders: null,
    rugcheckScore: null,
    rugcheckRisks: [],
  };

  const key = process.env.BIRDEYE_API_KEY;
  const tasks: Promise<void>[] = [];

  if (key) {
    const headers = { "X-API-KEY": key, "x-chain": CHAINS[chain].birdeye, accept: "application/json" };
    tasks.push(
      fetch(`https://public-api.birdeye.so/defi/token_security?address=${encodeURIComponent(address)}`, {
        headers,
        signal: AbortSignal.timeout(8000),
        next: { revalidate: 120 },
      })
        .then(async (r) => {
          if (!r.ok) throw new Error(`Birdeye ${r.status}`);
          const d = obj(obj(await r.json()).data);
          info.source = "birdeye";
          if (chain === "solana") {
            info.top10HolderPct = pct(d.top10HolderPercent);
            info.mintable = d.mintAuthority == null ? null : !!d.mintAuthority;
            info.freezable = d.freezeAuthority == null ? bool(d.freezeable) : !!d.freezeAuthority;
            info.mutableMetadata = bool(d.mutableMetadata);
          } else {
            // EVM security payload (GoPlus-style fields)
            info.honeypot = bool(d.isHoneypot ?? d.is_honeypot);
            info.mintable = bool(d.isMintable ?? d.is_mintable);
            info.buyTax = pct(d.buyTax ?? d.buy_tax);
            info.sellTax = pct(d.sellTax ?? d.sell_tax);
            info.holders = d.holderCount != null ? num(d.holderCount) : null;
            info.top10HolderPct = pct(d.top10HolderPercent);
          }
        })
        .catch((e: unknown) => {
          info.note = `Birdeye: ${e instanceof Error ? e.message : "error"}`;
        }),
    );
    tasks.push(
      fetch(`https://public-api.birdeye.so/defi/token_overview?address=${encodeURIComponent(address)}`, {
        headers,
        signal: AbortSignal.timeout(8000),
        next: { revalidate: 120 },
      })
        .then(async (r) => {
          if (!r.ok) return;
          const d = obj(obj(await r.json()).data);
          if (d.holder != null) info.holders = num(d.holder);
        })
        .catch(() => undefined),
    );
  } else {
    info.note = "BIRDEYE_API_KEY not set – Birdeye security data disabled";
  }

  if (chain === "solana") {
    tasks.push(
      fetch(`https://api.rugcheck.xyz/v1/tokens/${encodeURIComponent(address)}/report/summary`, {
        headers: { accept: "application/json" },
        signal: AbortSignal.timeout(8000),
        next: { revalidate: 120 },
      })
        .then(async (r) => {
          if (!r.ok) return;
          const d = obj(await r.json());
          info.rugcheckScore = d.score_normalised != null ? num(d.score_normalised) : d.score != null ? num(d.score) : null;
          info.rugcheckRisks = Array.isArray(d.risks)
            ? d.risks.map((x) => cleanText(obj(x).name, 60)).filter(Boolean).slice(0, 8)
            : [];
          if (info.source === "none") info.source = "rugcheck";
        })
        .catch(() => undefined),
    );
  }

  await Promise.all(tasks);
  return NextResponse.json(info, {
    headers: { "cache-control": "public, s-maxage=60, stale-while-revalidate=120" },
  });
}
