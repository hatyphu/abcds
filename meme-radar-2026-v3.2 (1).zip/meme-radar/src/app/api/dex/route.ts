import { NextResponse } from "next/server";
import { CHAINS, isChainKey } from "@/lib/chains";
import { bestPairPerToken, searchPairs, tokensPairs, trending } from "@/lib/dexscreener";
import { clientKey, rateLimit } from "@/lib/rate-limit";
import { isValidAddress, isValidSearch } from "@/lib/security";

// Majors and stablecoins are not meme coins: never list them as the base token.
const NOT_MEME = new Set(["SOL", "WSOL", "USDC", "USDT", "USD1", "PYUSD", "DAI", "FDUSD", "ETH", "WETH", "BNB", "WBNB", "BTC", "WBTC", "CBBTC", "BTCB", "JUP", "RAY"]);
const isMeme = (p: { baseSymbol: string }) => !NOT_MEME.has(p.baseSymbol.toUpperCase());

// GET /api/dex?mode=trending&chain=solana
// GET /api/dex?mode=search&q=pepe[&chain=base]
// GET /api/dex?mode=token&chain=solana&address=<mint>
export async function GET(req: Request) {
  if (!rateLimit(clientKey(req, "dex"), 90, 1.5)) {
    return NextResponse.json({ error: "Too many requests" }, { status: 429 });
  }
  const { searchParams } = new URL(req.url);
  const mode = searchParams.get("mode") ?? "trending";
  const chainParam = searchParams.get("chain");
  const chain = isChainKey(chainParam) ? chainParam : null;

  try {
    if (mode === "trending") {
      if (!chain) return bad("Invalid chain");
      let pairs = await trending(chain);
      if (pairs.length < 5) {
        // Fallback: pairs quoted in the chain's native token.
        const extra = (await searchPairs(CHAINS[chain].native)).filter((p) => p.chain === chain);
        pairs = bestPairPerToken([...pairs, ...extra]);
      }
      return ok(pairs.filter(isMeme).slice(0, 80));
    }

    if (mode === "search") {
      const q = (searchParams.get("q") ?? "").trim();
      if (!isValidSearch(q)) return bad("Invalid search term");
      let pairs = await searchPairs(q);
      if (chain) pairs = pairs.filter((p) => p.chain === chain);
      return ok(bestPairPerToken(pairs).slice(0, 60));
    }

    if (mode === "token") {
      const address = (searchParams.get("address") ?? "").trim();
      if (!chain || !isValidAddress(chain, address)) return bad("Invalid chain or address");
      const pairs = await tokensPairs(chain, [address]);
      return ok(pairs.sort((a, b) => b.liquidityUsd - a.liquidityUsd).slice(0, 10));
    }

    return bad("Unknown mode");
  } catch (err) {
    console.error("[api/dex]", err instanceof Error ? err.message : err);
    return NextResponse.json({ error: "Upstream unavailable" }, { status: 502 });
  }
}

function ok(pairs: unknown[]) {
  return NextResponse.json(
    { pairs, updatedAt: Date.now() },
    { headers: { "cache-control": "public, s-maxage=10, stale-while-revalidate=20" } },
  );
}

function bad(msg: string) {
  return NextResponse.json({ error: msg }, { status: 400 });
}
