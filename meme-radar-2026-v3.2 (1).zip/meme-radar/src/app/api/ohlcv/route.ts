import { NextResponse } from "next/server";
import { isChainKey } from "@/lib/chains";
import { birdeyeOhlcv, geckoOhlcv, isTimeframe } from "@/lib/ohlcv";
import { clientKey, rateLimit } from "@/lib/rate-limit";
import { isValidPairId } from "@/lib/security";
import type { OhlcvResponse } from "@/types/radar";

// GET /api/ohlcv?chain=solana&pair=<pairAddress>&tf=5m
// GeckoTerminal first (free, no key); falls back to Birdeye when BIRDEYE_API_KEY is set.
export async function GET(req: Request) {
  if (!rateLimit(clientKey(req, "ohlcv"), 60, 1)) {
    return NextResponse.json({ error: "Too many requests" }, { status: 429 });
  }
  const { searchParams } = new URL(req.url);
  const chain = searchParams.get("chain");
  const pair = (searchParams.get("pair") ?? "").trim();
  const tf = searchParams.get("tf") ?? "5m";
  if (!isChainKey(chain) || !isValidPairId(chain, pair) || !isTimeframe(tf)) {
    return NextResponse.json({ error: "Invalid chain, pair or timeframe" }, { status: 400 });
  }

  const errors: string[] = [];
  const attempts: [OhlcvResponse["source"], () => Promise<OhlcvResponse["candles"]>][] = [
    ["geckoterminal", () => geckoOhlcv(chain, pair, tf)],
    ["birdeye", () => birdeyeOhlcv(chain, pair, tf)],
  ];
  for (const [source, run] of attempts) {
    try {
      const candles = await run();
      if (candles.length >= 2) {
        const body: OhlcvResponse = { candles, source, timeframe: tf };
        return NextResponse.json(body, {
          headers: { "cache-control": `public, s-maxage=${tf === "1m" ? 15 : 30}, stale-while-revalidate=60` },
        });
      }
      errors.push(`${source}: no candles`);
    } catch (e) {
      errors.push(`${source}: ${e instanceof Error ? e.message : "error"}`);
    }
  }
  console.warn("[api/ohlcv]", errors.join(" | "));
  return NextResponse.json({ error: "No candle data for this pair yet" }, { status: 404 });
}
