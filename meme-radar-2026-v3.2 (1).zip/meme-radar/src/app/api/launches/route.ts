import { NextResponse } from "next/server";
import { isChainKey } from "@/lib/chains";
import { enabledProviders, mergeLaunches } from "@/lib/launches";
import { clientKey, rateLimit } from "@/lib/rate-limit";
import type { LaunchResponse } from "@/types/radar";

// GET /api/launches?chain=solana
// Aggregates launchpad adapters (Pump.fun, Clanker, DEXScreener new profiles). Each provider fails soft.
export async function GET(req: Request) {
  if (!rateLimit(clientKey(req, "launch"), 20, 0.25)) {
    return NextResponse.json({ error: "Too many scans. Wait a few seconds." }, { status: 429 });
  }
  const chain = new URL(req.url).searchParams.get("chain");
  if (!isChainKey(chain)) return NextResponse.json({ error: "Invalid chain" }, { status: 400 });

  const providers = enabledProviders(chain);
  const settled = await Promise.allSettled(providers.map((p) => p.run(chain)));
  const status: LaunchResponse["providers"] = settled.map((r, i) =>
    r.status === "fulfilled"
      ? { name: providers[i].name, ok: true, count: r.value.length }
      : { name: providers[i].name, ok: false, count: 0, error: r.reason instanceof Error ? r.reason.message.slice(0, 80) : "error" },
  );
  for (const s of status) if (!s.ok) console.warn(`[api/launches] ${chain} ${s.name}: ${s.error}`);

  const items = mergeLaunches(settled.map((r) => (r.status === "fulfilled" ? r.value : [])));
  const body: LaunchResponse = { items, providers: status, updatedAt: Date.now() };
  return NextResponse.json(body, {
    status: items.length === 0 && status.every((s) => !s.ok) ? 502 : 200,
    headers: { "cache-control": "public, s-maxage=10, stale-while-revalidate=20" },
  });
}
