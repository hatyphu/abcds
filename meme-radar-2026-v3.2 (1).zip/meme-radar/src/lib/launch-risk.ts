import type { LaunchItem, RiskReport } from "@/types/radar";

/** Early (pre-/just-launched) risk heuristic. Informational only. */
export function launchRisk(l: LaunchItem): RiskReport {
  let score = 0;
  const flags: RiskReport["flags"] = [];
  const add = (pts: number, level: "warn" | "danger", label: string) => {
    score += pts;
    flags.push({ level, label });
  };
  const hasSocial = !!(l.socials.x || l.socials.telegram);
  if (!hasSocial) add(20, "danger", "No X / Telegram");
  else if (!l.socials.website) add(5, "warn", "No website");
  else flags.push({ level: "ok", label: "Socials linked" });

  if (l.createdAt) {
    const mins = (Date.now() - l.createdAt) / 60_000;
    if (mins < 10) add(15, "danger", "Created < 10 min ago");
    else if (mins < 60) add(8, "warn", "Created < 1h ago");
  }
  if (l.marketCapUsd != null && l.marketCapUsd < 8_000) add(10, "warn", "Market cap < $8K");
  if (!l.creator && l.platform !== "DEXScreener") add(5, "warn", "Creator unknown");
  if (!l.description) add(5, "warn", "No description");
  if (l.stage === "graduating") flags.push({ level: "warn", label: "Near graduation: high volatility" });

  score = Math.min(100, score);
  return { score, grade: score >= 70 ? "EXTREME" : score >= 45 ? "HIGH" : score >= 20 ? "MEDIUM" : "LOW", flags };
}

export const STAGE_LABEL: Record<LaunchItem["stage"], string> = {
  bonding: "Bonding",
  graduating: "Graduating soon",
  graduated: "Graduated",
  "new-listing": "New listing",
};
