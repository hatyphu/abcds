// Phân tích & dự đoán tự động cho một token (rule-based, chạy trên trình duyệt).
// Đọc: giá/khối lượng/giao dịch (DEXScreener), nến (GeckoTerminal/Birdeye), bảo mật (Birdeye/RugCheck).
// Kết quả là ĐIỂM TÍN HIỆU theo trọng số các yếu tố — KHÔNG phải xác suất lãi. Không phải lời khuyên tài chính.
import { scoreRisk } from "./risk";
import type { Candle, RadarPair, RiskReport, SecurityInfo } from "@/types/radar";

export type Verdict = "NÊN MUA" | "CÓ THỂ CÂN NHẮC" | "THEO DÕI, CHƯA MUA" | "KHÔNG NÊN MUA";

export interface Factor {
  key: string;
  label: string;
  /** -1 (rất xấu) … +1 (rất tốt) */
  value: number;
  weight: number;
  detail: string;
}

export interface Analysis {
  buyPct: number; // 0–100: tỷ lệ tín hiệu Mua
  skipPct: number; // 100 - buyPct
  verdict: Verdict;
  tone: "good" | "ok" | "wait" | "bad";
  factors: Factor[];
  risk: RiskReport;
  capReason: string | null;
  levels: { support: number | null; resistance: number | null; rsi: number | null; trend: "up" | "down" | "flat" | null };
  summary: string[];
  closing: string;
}

const clamp = (v: number, lo = -1, hi = 1) => Math.max(lo, Math.min(hi, v));

export function ema(values: number[], period: number): number[] {
  const k = 2 / (period + 1);
  const out: number[] = [];
  values.forEach((v, i) => out.push(i === 0 ? v : v * k + out[i - 1] * (1 - k)));
  return out;
}

export function rsi(closes: number[], period = 14): number | null {
  if (closes.length <= period) return null;
  let gain = 0;
  let loss = 0;
  for (let i = 1; i <= period; i++) {
    const d = closes[i] - closes[i - 1];
    if (d >= 0) gain += d;
    else loss -= d;
  }
  gain /= period;
  loss /= period;
  for (let i = period + 1; i < closes.length; i++) {
    const d = closes[i] - closes[i - 1];
    gain = (gain * (period - 1) + Math.max(0, d)) / period;
    loss = (loss * (period - 1) + Math.max(0, -d)) / period;
  }
  if (gain === 0 && loss === 0) return 50; // flat price: neutral, not "overbought"
  if (loss === 0) return 100;
  return 100 - 100 / (1 + gain / loss);
}

function fmtUsd(n: number): string {
  const a = Math.abs(n);
  if (a >= 1e9) return `$${(n / 1e9).toFixed(2)}B`;
  if (a >= 1e6) return `$${(n / 1e6).toFixed(2)}M`;
  if (a >= 1e3) return `$${(n / 1e3).toFixed(1)}K`;
  return `$${n.toFixed(0)}`;
}
const sign = (n: number) => `${n > 0 ? "+" : ""}${n.toFixed(1)}%`;

export function analyzeToken(p: RadarPair, sec: SecurityInfo | null, candles: Candle[] | null): Analysis {
  const factors: Factor[] = [];
  const add = (key: string, label: string, value: number, weight: number, detail: string) =>
    factors.push({ key, label, value: clamp(value), weight, detail });

  // 1. Động lượng giá (ưu tiên 1h, tham chiếu 5m và 24h). Tăng quá nóng bị trừ.
  const mom = clamp(p.change1h / 40) * 0.6 + clamp(p.change5m / 10) * 0.25 + clamp(p.change24h / 150) * 0.15;
  const overheated = p.change1h > 150 || p.change24h > 800;
  add(
    "momentum",
    "Động lượng giá",
    overheated ? Math.min(mom, -0.2) : mom,
    1.4,
    overheated
      ? `Tăng quá nóng (1h ${sign(p.change1h)}, 24h ${sign(p.change24h)}), dễ bị chốt lời mạnh.`
      : `5m ${sign(p.change5m)} · 1h ${sign(p.change1h)} · 24h ${sign(p.change24h)}.`,
  );

  // 2. Lực mua / bán
  const tx1 = p.buys1h + p.sells1h;
  const tx5 = p.buys5m + p.sells5m;
  const share1 = tx1 ? p.buys1h / tx1 : 0.5;
  const share5 = tx5 ? p.buys5m / tx5 : share1;
  add(
    "pressure",
    "Lực mua / bán",
    ((share1 - 0.5) * 0.6 + (share5 - 0.5) * 0.4) * 4,
    1.3,
    `Mua chiếm ${(share1 * 100).toFixed(0)}% giao dịch 1h (${p.buys1h} mua / ${p.sells1h} bán), ${(share5 * 100).toFixed(0)}% trong 5m.`,
  );

  // 3. Mức độ sôi động: volume 1h so với thanh khoản
  const turn = p.liquidityUsd ? p.volume1h / p.liquidityUsd : 0;
  add(
    "activity",
    "Mức độ sôi động",
    turn < 0.02 ? -0.7 : turn < 0.1 ? -0.1 : turn < 1.5 ? 0.7 : turn < 4 ? 0.3 : -0.3,
    1.0,
    `Volume 1h ${fmtUsd(p.volume1h)} = ${(turn * 100).toFixed(0)}% thanh khoản${turn >= 4 ? " (bất thường, có thể wash-trade)" : turn < 0.02 ? " (gần như không ai giao dịch)" : ""}.`,
  );

  // 4. Độ sâu thanh khoản
  const liq = p.liquidityUsd;
  add(
    "liquidity",
    "Thanh khoản",
    liq < 5_000 ? -1 : liq < 20_000 ? -0.5 : liq < 60_000 ? 0 : liq < 300_000 ? 0.5 : 0.8,
    1.2,
    `${fmtUsd(liq)}${liq < 20_000 ? ": mỏng, lệnh nhỏ cũng trượt giá mạnh" : liq >= 300_000 ? ": sâu, vào/ra lệnh dễ" : ""}.`,
  );

  // 5. Định giá: vốn hoá / thanh khoản
  const cap = p.marketCap || p.fdv;
  const ratio = liq ? cap / liq : 0;
  if (ratio > 0) {
    add(
      "valuation",
      "Vốn hoá / thanh khoản",
      ratio < 5 ? 0.6 : ratio < 15 ? 0.3 : ratio < 30 ? -0.2 : ratio < 60 ? -0.6 : -1,
      0.8,
      `MC ${fmtUsd(cap)} gấp ${ratio.toFixed(1)} lần thanh khoản${ratio >= 30 ? ": dễ sập khi bị xả" : ""}.`,
    );
  }

  // 6. Tuổi cặp giao dịch
  if (p.createdAt) {
    const h = (Date.now() - p.createdAt) / 3_600_000;
    add(
      "age",
      "Tuổi token",
      h < 1 ? -0.7 : h < 6 ? -0.3 : h < 72 ? 0.2 : h < 24 * 30 ? 0.4 : 0.2,
      0.6,
      h < 1 ? "Mới ra dưới 1 giờ: biến động cực mạnh, rủi ro rug cao." : h < 24 ? `${h.toFixed(0)} giờ tuổi.` : `${(h / 24).toFixed(0)} ngày tuổi.`,
    );
  }

  // 7. Xu hướng kỹ thuật từ nến: EMA9/EMA21, RSI14, hỗ trợ / kháng cự
  let support: number | null = null;
  let resistance: number | null = null;
  let rsiV: number | null = null;
  let trend: Analysis["levels"]["trend"] = null;
  if (candles && candles.length >= 22) {
    const closes = candles.map((c) => c.c);
    const e9 = ema(closes, 9);
    const e21 = ema(closes, 21);
    const last = closes.length - 1;
    const gap = (e9[last] - e21[last]) / e21[last];
    const slope = (e21[last] - e21[Math.max(0, last - 5)]) / e21[Math.max(0, last - 5)];
    trend = gap > 0.005 && slope > 0 ? "up" : gap < -0.005 && slope < 0 ? "down" : "flat";
    add(
      "trend",
      "Xu hướng (EMA9/21)",
      clamp(gap * 25) * 0.7 + clamp(slope * 20) * 0.3,
      1.2,
      trend === "up" ? "EMA9 nằm trên EMA21 và đang dốc lên: xu hướng tăng." : trend === "down" ? "EMA9 dưới EMA21, xu hướng giảm." : "Đi ngang, chưa rõ xu hướng.",
    );
    rsiV = rsi(closes);
    if (rsiV != null) {
      add(
        "rsi",
        "RSI(14)",
        rsiV > 80 ? -0.8 : rsiV > 70 ? -0.3 : rsiV < 25 ? 0.2 : rsiV < 45 ? 0.1 : 0.4,
        0.8,
        `${rsiV.toFixed(0)}${rsiV > 70 ? ": quá mua, dễ điều chỉnh" : rsiV < 30 ? ": quá bán, có thể hồi nhưng chưa xác nhận" : ": vùng cân bằng"}.`,
      );
    }
    const recent = candles.slice(-48);
    const price = closes[last];
    const lows = recent.map((c) => c.l).filter((v) => v < price);
    const highs = recent.map((c) => c.h).filter((v) => v > price);
    support = lows.length ? Math.max(...lows.filter((v) => v <= price * 0.995).concat(Math.min(...lows))) : null;
    resistance = highs.length ? Math.min(...highs.filter((v) => v >= price * 1.005).concat(Math.max(...highs))) : null;
  }

  // 8. An toàn hợp đồng
  const risk = scoreRisk(p, sec);
  add(
    "safety",
    "An toàn hợp đồng",
    risk.grade === "LOW" ? 0.6 : risk.grade === "MEDIUM" ? 0 : risk.grade === "HIGH" ? -0.6 : -1,
    1.6,
    `Rủi ro ${risk.grade} (${risk.score}/100)${risk.flags.filter((f) => f.level === "danger").length ? ": " + risk.flags.filter((f) => f.level === "danger").map((f) => f.label).join(", ") : ""}.`,
  );

  // Tổng hợp: trung bình có trọng số → 0–100
  const wSum = factors.reduce((a, f) => a + f.weight, 0);
  const raw = factors.reduce((a, f) => a + f.value * f.weight, 0) / wSum; // -1..1
  let buyPct = Math.round(((raw + 1) / 2) * 100);

  // Chặn cứng theo an toàn
  let capReason: string | null = null;
  const cap1 = (max: number, why: string) => {
    if (buyPct > max) {
      buyPct = max;
      capReason = why;
    }
  };
  if (sec?.honeypot) cap1(3, "Phát hiện honeypot: có thể mua nhưng không bán được.");
  if (sec?.sellTax != null && sec.sellTax > 20) cap1(10, `Thuế bán ${sec.sellTax.toFixed(0)}%: gần như không thể chốt lời.`);
  if (risk.grade === "EXTREME") cap1(20, "Rủi ro EXTREME: nhiều dấu hiệu rug/lừa đảo.");
  if (risk.grade === "HIGH") cap1(45, "Rủi ro HIGH: điểm bị giới hạn dù giá đang tốt.");
  if (p.liquidityUsd < 5_000) cap1(30, "Thanh khoản dưới $5K: không đủ để vào/ra lệnh an toàn.");
  if (rsiV != null && rsiV > 80) cap1(65, `RSI ${rsiV.toFixed(0)}: quá mua, nên chờ điều chỉnh thay vì đuổi giá.`);
  buyPct = Math.max(0, Math.min(100, buyPct));

  const verdict: Verdict = buyPct >= 70 ? "NÊN MUA" : buyPct >= 55 ? "CÓ THỂ CÂN NHẮC" : buyPct >= 40 ? "THEO DÕI, CHƯA MUA" : "KHÔNG NÊN MUA";
  const tone = buyPct >= 70 ? "good" : buyPct >= 55 ? "ok" : buyPct >= 40 ? "wait" : "bad";

  const sorted = [...factors].sort((a, b) => b.value * b.weight - a.value * a.weight);
  const pros = sorted.filter((f) => f.value > 0.15).slice(0, 3);
  const cons = [...sorted].reverse().filter((f) => f.value < -0.15).slice(0, 3);

  const summary: string[] = [];
  summary.push(
    `${p.baseSymbol} đang giao dịch ở ${p.priceUsd < 1 ? p.priceUsd.toPrecision(4) : p.priceUsd.toFixed(4)} USD, vốn hoá ${fmtUsd(cap)}, thanh khoản ${fmtUsd(liq)}.` +
      (trend ? ` Trên biểu đồ, xu hướng ngắn hạn ${trend === "up" ? "đang tăng" : trend === "down" ? "đang giảm" : "đi ngang"}.` : ""),
  );
  if (pros.length) summary.push(`Điểm cộng: ${pros.map((f) => f.label.toLowerCase()).join(", ")}.`);
  if (cons.length) summary.push(`Điểm trừ: ${cons.map((f) => f.label.toLowerCase()).join(", ")}.`);
  if (capReason) summary.push(capReason);
  summary.push(
    verdict === "NÊN MUA"
      ? "Tín hiệu tổng hợp tích cực. Nếu vào lệnh, chỉ dùng số vốn bạn chấp nhận mất và đặt điểm cắt lỗ dưới vùng hỗ trợ."
      : verdict === "CÓ THỂ CÂN NHẮC"
        ? "Tín hiệu nghiêng về tích cực nhưng chưa mạnh. Có thể vào lệnh nhỏ, chờ xác nhận thêm rồi mới tăng."
        : verdict === "THEO DÕI, CHƯA MUA"
          ? "Tín hiệu lẫn lộn. Nên đưa vào danh sách theo dõi và chờ lực mua hoặc xu hướng rõ hơn."
          : "Rủi ro lớn hơn cơ hội ở thời điểm này. Không nên mua.",
  );

  return {
    buyPct,
    skipPct: 100 - buyPct,
    verdict,
    tone,
    factors,
    risk,
    capReason,
    levels: { support, resistance, rsi: rsiV, trend },
    summary,
    closing: "Quyết định là ở bạn. Chúc bạn x tài khoản!",
  };
}
