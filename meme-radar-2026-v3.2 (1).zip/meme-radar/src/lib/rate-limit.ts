// Server-side only (imported from route handlers).
interface Bucket {
  tokens: number;
  updated: number;
}

const buckets = new Map<string, Bucket>();
const MAX_KEYS = 5000;

/**
 * Simple in-memory token bucket per client key.
 * Good enough for a single Node instance; use Redis/Upstash when running several.
 */
export function rateLimit(key: string, capacity = 60, refillPerSec = 1): boolean {
  const now = Date.now();
  const b = buckets.get(key) ?? { tokens: capacity, updated: now };
  b.tokens = Math.min(capacity, b.tokens + ((now - b.updated) / 1000) * refillPerSec);
  b.updated = now;
  if (b.tokens < 1) {
    buckets.set(key, b);
    return false;
  }
  b.tokens -= 1;
  if (buckets.size > MAX_KEYS) buckets.clear();
  buckets.set(key, b);
  return true;
}

export function clientKey(req: Request, scope: string): string {
  const fwd = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim();
  const ip = fwd || req.headers.get("x-real-ip") || "local";
  return `${scope}:${ip}`;
}
