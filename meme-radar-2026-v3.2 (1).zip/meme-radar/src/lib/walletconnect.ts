"use client";

// WalletConnect v2 (Sign API). Needs NEXT_PUBLIC_WC_PROJECT_ID from https://cloud.reown.com
// The projectId is a public identifier (safe in the browser) — restrict allowed origins in the Reown dashboard.
import type SignClientType from "@walletconnect/sign-client";

type SignClientInstance = Awaited<ReturnType<typeof SignClientType.init>>;

let clientPromise: Promise<SignClientInstance> | null = null;

export const WC_PROJECT_ID = process.env.NEXT_PUBLIC_WC_PROJECT_ID ?? "";

export function hasWalletConnect(): boolean {
  return /^[a-f0-9]{32}$/i.test(WC_PROJECT_ID);
}

async function getClient(): Promise<SignClientInstance> {
  if (!clientPromise) {
    clientPromise = import("@walletconnect/sign-client").then(({ default: SignClient }) =>
      SignClient.init({
        projectId: WC_PROJECT_ID,
        metadata: {
          name: "Meme Coin Radar 2026",
          description: "Non-custodial multi-chain meme coin radar",
          url: window.location.origin,
          icons: [`${window.location.origin}/favicon.ico`],
        },
      }),
    );
    clientPromise.catch(() => {
      clientPromise = null;
    });
  }
  return clientPromise;
}

export interface WcPairing {
  uri: string;
  approval: Promise<{ topic: string; accounts: string[] }>;
}

export async function startPairing(): Promise<WcPairing> {
  const client = await getClient();
  const { uri, approval } = await client.connect({
    optionalNamespaces: {
      eip155: {
        methods: ["eth_sendTransaction", "personal_sign", "eth_signTypedData_v4", "wallet_switchEthereumChain"],
        chains: ["eip155:1", "eip155:56", "eip155:8453"],
        events: ["accountsChanged", "chainChanged"],
      },
    },
  });
  if (!uri) throw new Error("WalletConnect did not return a pairing URI");
  return {
    uri,
    approval: approval().then((session) => ({
      topic: session.topic,
      accounts: Object.values(session.namespaces).flatMap((ns) => ns.accounts),
    })),
  };
}

export async function disconnectSession(topic: string): Promise<void> {
  const client = await getClient();
  await client.disconnect({ topic, reason: { code: 6000, message: "User disconnected" } }).catch(() => undefined);
}
