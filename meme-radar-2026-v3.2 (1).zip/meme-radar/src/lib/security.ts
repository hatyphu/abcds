import type { ChainKey } from "./chains";

// Base58 (no 0, O, I, l), 32–44 chars: Solana public keys / mints.
const SOL_ADDRESS = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;
// 0x + 40 hex chars: EVM addresses.
const EVM_ADDRESS = /^0x[a-fA-F0-9]{40}$/;
// Search terms: letters, numbers, space, a few symbols. No quotes / angle brackets.
const SEARCH_TERM = /^[\p{L}\p{N} $._\-]{1,64}$/u;

export function isSolAddress(v: string): boolean {
  return SOL_ADDRESS.test(v);
}

export function isEvmAddress(v: string): boolean {
  return EVM_ADDRESS.test(v);
}

export function isValidAddress(chain: ChainKey, v: string): boolean {
  return chain === "solana" ? isSolAddress(v) : isEvmAddress(v);
}

/** Pair ids on DEXScreener are addresses on all supported chains (V4 pools can be 32-byte ids). */
export function isValidPairId(chain: ChainKey, v: string): boolean {
  if (chain === "solana") return isSolAddress(v);
  return EVM_ADDRESS.test(v) || /^0x[a-fA-F0-9]{64}$/.test(v);
}

export function isValidSearch(v: string): boolean {
  return SEARCH_TERM.test(v.trim());
}

/** Only allow https image URLs from the remote APIs; everything else is dropped. */
export function safeImageUrl(u: unknown): string | null {
  if (typeof u !== "string" || u.length > 512) return null;
  try {
    const url = new URL(u);
    return url.protocol === "https:" ? url.toString() : null;
  } catch {
    return null;
  }
}

/** Only allow http(s) links (blocks javascript:, data:, etc.). */
export function safeLinkUrl(u: unknown): string | null {
  if (typeof u !== "string" || u.length > 512) return null;
  try {
    const url = new URL(u);
    return url.protocol === "https:" || url.protocol === "http:" ? url.toString() : null;
  } catch {
    return null;
  }
}

/** Trim and strip control chars from remote text before rendering (React already escapes HTML). */
export function cleanText(v: unknown, max = 64): string {
  if (typeof v !== "string") return "";
  // eslint-disable-next-line no-control-regex
  return v.replace(/[\u0000-\u001f\u007f​-‏‪-‮]/g, "").trim().slice(0, max);
}

export function num(v: unknown): number {
  const n = typeof v === "string" ? Number(v) : typeof v === "number" ? v : NaN;
  return Number.isFinite(n) ? n : 0;
}
