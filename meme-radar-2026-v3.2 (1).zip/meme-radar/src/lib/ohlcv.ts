// Candle (OHLCV) sources. Server-side only.
// - GeckoTerminal public API (no key, ~30 req/min): https://www.geckoterminal.com/dex-api
// - Birdeye (BIRDEYE_API_KEY) as fallback: https://docs.birdeye.so
import { CHAINS, type ChainKey } from "./chains";
import { num } from "./security";
import type { Candle, Timeframe } from "@/types/radar";

export const TIMEFRAMES: Timeframe[] = ["1m", "5m", "15m", "1h", "4h", "1d"];

export function isTimeframe(v: unknown): v is Timeframe {
  return typeof v === "string" && (TIMEFRAMES as string[]).includes(v);
}

const GECKO_TF: Record<Timeframe, { unit: "minute" | "hour" | "day"; agg: number }> = {
  "1m": { unit: "minute", agg: 1 },
  "5m": { unit: "minute", agg: 5 },
  "15m": { unit: "minute", agg: 15 },
  "1h": { unit: "hour", agg: 1 },
  "4h": { unit: "hour", agg: 4 },
  "1d": { unit: "day", agg: 1 },
};
const BIRDEYE_TF: Record<Timeframe, string> = { "1m": "1m", "5m": "5m", "15m": "15m", "1h": "1H", "4h": "4H", "1d": "1D" };
const TF_SECONDS: Record<Timeframe, number> = { "1m": 60, "5m": 300, "15m": 900, "1h": 3600, "4h": 14400, "1d": 86400 };

const MAX_CANDLES = 300;

/** Validate + sort + de-duplicate candles; drops anything non-finite or inconsistent. */
export function cleanCandles(raw: Candle[]): Candle[] {
  const seen = new Set<number>();
  return raw
    .filter((k) => {
      if (![k.t, k.o, k.h, k.l, k.c, k.v].every(Number.isFinite)) return false;
      if (k.t <= 0 || k.o <= 0 || k.c <= 0 || k.l <= 0 || k.h < k.l || k.v < 0) return false;
      if (seen.has(k.t)) return false;
      seen.add(k.t);
      return true;
    })
    .map((k) => ({ ...k, h: Math.max(k.h, k.o, k.c), l: Math.min(k.l, k.o, k.c) }))
    .sort((a, b) => a.t - b.t)
    .slice(-MAX_CANDLES);
}

/** GeckoTerminal: data.attributes.ohlcv_list = [[unixSec, o, h, l, c, volUsd], …] newest first. */
export function parseGecko(json: unknown): Candle[] {
  const list = (json as { data?: { attributes?: { ohlcv_list?: unknown } } })?.data?.attributes?.ohlcv_list;
  if (!Array.isArray(list)) return [];
  return cleanCandles(
    list
      .filter((r): r is unknown[] => Array.isArray(r) && r.length >= 6)
      .map((r) => ({ t: num(r[0]) * 1000, o: num(r[1]), h: num(r[2]), l: num(r[3]), c: num(r[4]), v: num(r[5]) })),
  );
}

/** Birdeye: data.items = [{ unixTime, o, h, l, c, v }]. */
export function parseBirdeye(json: unknown): Candle[] {
  const items = (json as { data?: { items?: unknown } })?.data?.items;
  if (!Array.isArray(items)) return [];
  return cleanCandles(
    items.map((x) => {
      const o = (x ?? {}) as Record<string, unknown>;
      return { t: num(o.unixTime) * 1000, o: num(o.o), h: num(o.h), l: num(o.l), c: num(o.c), v: num(o.v) };
    }),
  );
}

export async function geckoOhlcv(chain: ChainKey, pool: string, tf: Timeframe, limit = 200): Promise<Candle[]> {
  const { unit, agg } = GECKO_TF[tf];
  const url =
    `https://api.geckoterminal.com/api/v2/networks/${CHAINS[chain].gecko}/pools/${encodeURIComponent(pool)}` +
    `/ohlcv/${unit}?aggregate=${agg}&limit=${Math.min(limit, MAX_CANDLES)}&currency=usd`;
  const res = await fetch(url, {
    headers: { accept: "application/json;version=20230302" },
    signal: AbortSignal.timeout(8000),
    next: { revalidate: tf === "1m" ? 20 : 45 },
  });
  if (!res.ok) throw new Error(`GeckoTerminal ${res.status}`);
  return parseGecko(await res.json());
}

export async function birdeyeOhlcv(chain: ChainKey, pair: string, tf: Timeframe, limit = 200): Promise<Candle[]> {
  const key = process.env.BIRDEYE_API_KEY;
  if (!key) throw new Error("BIRDEYE_API_KEY not set");
  const to = Math.floor(Date.now() / 1000);
  const from = to - TF_SECONDS[tf] * Math.min(limit, MAX_CANDLES);
  const url =
    `https://public-api.birdeye.so/defi/ohlcv/pair?address=${encodeURIComponent(pair)}` +
    `&type=${BIRDEYE_TF[tf]}&time_from=${from}&time_to=${to}`;
  const res = await fetch(url, {
    headers: { "X-API-KEY": key, "x-chain": CHAINS[chain].birdeye, accept: "application/json" },
    signal: AbortSignal.timeout(8000),
    next: { revalidate: tf === "1m" ? 20 : 45 },
  });
  if (!res.ok) throw new Error(`Birdeye ${res.status}`);
  return parseBirdeye(await res.json());
}
