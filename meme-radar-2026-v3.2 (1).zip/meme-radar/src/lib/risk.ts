import type { RadarPair, RiskFlag, RiskReport, SecurityInfo } from "@/types/radar";

/** RugCheck-style heuristic risk score. Informational only — not financial advice. */
export function scoreRisk(p: RadarPair, s?: SecurityInfo | null): RiskReport {
  let score = 0;
  const flags: RiskFlag[] = [];
  const add = (pts: number, level: RiskFlag["level"], label: string) => {
    score += pts;
    flags.push({ level, label });
  };

  if (p.liquidityUsd < 5_000) add(30, "danger", "Liquidity < $5K");
  else if (p.liquidityUsd < 25_000) add(15, "warn", "Liquidity < $25K");
  else flags.push({ level: "ok", label: "Liquidity OK" });

  const cap = p.marketCap || p.fdv;
  if (cap > 0 && p.liquidityUsd > 0) {
    const ratio = cap / p.liquidityUsd;
    if (ratio > 50) add(15, "danger", `MC/Liq ${ratio.toFixed(0)}x`);
    else if (ratio > 20) add(8, "warn", `MC/Liq ${ratio.toFixed(0)}x`);
  }

  if (p.createdAt) {
    const ageH = (Date.now() - p.createdAt) / 3_600_000;
    if (ageH < 1) add(15, "danger", "Pair < 1h old");
    else if (ageH < 24) add(8, "warn", "Pair < 24h old");
  }

  const tx = p.buys1h + p.sells1h;
  if (tx > 20) {
    const sellShare = p.sells1h / tx;
    if (sellShare > 0.7) add(10, "warn", "Heavy selling (1h)");
    if (p.sells1h === 0) add(20, "danger", "No sells in 1h (honeypot?)");
  }
  if (p.change1h < -40) add(10, "danger", "Dumped > 40% (1h)");

  if (s) {
    if (s.honeypot) add(50, "danger", "Honeypot detected");
    if (s.mintable) add(15, "danger", "Mint authority active");
    if (s.freezable) add(15, "danger", "Freeze authority active");
    if (s.mutableMetadata) add(5, "warn", "Mutable metadata");
    if (s.top10HolderPct != null) {
      if (s.top10HolderPct > 50) add(15, "danger", `Top10 hold ${s.top10HolderPct.toFixed(0)}%`);
      else if (s.top10HolderPct > 30) add(7, "warn", `Top10 hold ${s.top10HolderPct.toFixed(0)}%`);
      else flags.push({ level: "ok", label: `Top10 ${s.top10HolderPct.toFixed(0)}%` });
    }
    if (s.sellTax != null && s.sellTax > 10) add(20, "danger", `Sell tax ${s.sellTax.toFixed(0)}%`);
    if (s.buyTax != null && s.buyTax > 10) add(10, "warn", `Buy tax ${s.buyTax.toFixed(0)}%`);
    if (s.rugcheckRisks.length) add(Math.min(20, s.rugcheckRisks.length * 5), "warn", `RugCheck: ${s.rugcheckRisks.length} risk(s)`);
  }

  score = Math.min(100, score);
  const grade: RiskReport["grade"] = score >= 70 ? "EXTREME" : score >= 45 ? "HIGH" : score >= 20 ? "MEDIUM" : "LOW";
  return { score, grade, flags };
}

/** 0–100 momentum score used to rank "hot" tokens (GMGN-style). */
export function momentum(p: RadarPair): number {
  const tx = p.buys5m + p.sells5m;
  const buyPressure = tx ? p.buys5m / tx : 0.5;
  const volLiq = p.liquidityUsd ? Math.min(3, p.volume1h / p.liquidityUsd) : 0;
  const change = Math.max(-50, Math.min(100, p.change1h));
  const s = buyPressure * 40 + (volLiq / 3) * 30 + ((change + 50) / 150) * 30;
  return Math.round(Math.max(0, Math.min(100, s)));
}
