export type ChainKey = "solana" | "bsc" | "base" | "ethereum";

export interface ChainConfig {
  key: ChainKey;
  label: string;
  short: string;
  /** DEXScreener chainId */
  dexId: string;
  /** Birdeye x-chain header value */
  birdeye: string;
  /** Bubblemaps path segment */
  bubblemaps: string;
  /** GeckoTerminal network id */
  gecko: string;
  /** GMGN path segment */
  gmgn: string;
  /** DEXTools path segment */
  dextools: string;
  /** EIP-155 chain id (EVM only) */
  evmChainId?: number;
  native: string;
  color: string;
  kind: "svm" | "evm";
}

export const CHAINS: Record<ChainKey, ChainConfig> = {
  solana: {
    key: "solana",
    label: "Solana",
    short: "SOL",
    dexId: "solana",
    gecko: "solana",
    birdeye: "solana",
    bubblemaps: "sol",
    gmgn: "sol",
    dextools: "solana",
    native: "SOL",
    color: "#14f195",
    kind: "svm",
  },
  bsc: {
    key: "bsc",
    label: "BNB Chain",
    short: "BNB",
    dexId: "bsc",
    gecko: "bsc",
    birdeye: "bsc",
    bubblemaps: "bsc",
    gmgn: "bsc",
    dextools: "bnb",
    evmChainId: 56,
    native: "BNB",
    color: "#f3ba2f",
    kind: "evm",
  },
  base: {
    key: "base",
    label: "Base",
    short: "BASE",
    dexId: "base",
    gecko: "base",
    birdeye: "base",
    bubblemaps: "base",
    gmgn: "base",
    dextools: "base",
    evmChainId: 8453,
    native: "ETH",
    color: "#3b82f6",
    kind: "evm",
  },
  ethereum: {
    key: "ethereum",
    label: "Ethereum",
    short: "ETH",
    dexId: "ethereum",
    gecko: "eth",
    birdeye: "ethereum",
    bubblemaps: "eth",
    gmgn: "eth",
    dextools: "ether",
    evmChainId: 1,
    native: "ETH",
    color: "#8b9cf7",
    kind: "evm",
  },
};

export const CHAIN_KEYS = Object.keys(CHAINS) as ChainKey[];

export function isChainKey(v: unknown): v is ChainKey {
  return typeof v === "string" && (CHAIN_KEYS as string[]).includes(v);
}

export function chainFromDexId(dexId: string): ChainKey | null {
  const found = CHAIN_KEYS.find((k) => CHAINS[k].dexId === dexId);
  return found ?? null;
}
