"use client";

// Direct non-custodial Solana swaps via Jupiter (public lite API, no key).
// The transaction is built by Jupiter for the user's public key and signed in Phantom — nothing is signed here.
const JUP = "https://lite-api.jup.ag";
export const WSOL = "So11111111111111111111111111111111111111112";

export interface JupQuote {
  inAmount: string;
  outAmount: string;
  priceImpactPct: string;
  routePlan: { swapInfo: { label?: string } }[];
  [k: string]: unknown;
}

export async function tokenDecimals(mint: string): Promise<number> {
  const r = await fetch(`${JUP}/tokens/v2/search?query=${encodeURIComponent(mint)}`, { signal: AbortSignal.timeout(8000) });
  if (!r.ok) throw new Error(`Token lookup failed (${r.status})`);
  const list = (await r.json()) as { id?: string; decimals?: number }[];
  const t = Array.isArray(list) ? list.find((x) => x.id === mint) : undefined;
  if (typeof t?.decimals !== "number") throw new Error("Unknown token decimals");
  return t.decimals;
}

export async function getQuote(inputMint: string, outputMint: string, rawAmount: bigint, slippageBps: number): Promise<JupQuote> {
  const qs = new URLSearchParams({
    inputMint,
    outputMint,
    amount: rawAmount.toString(),
    slippageBps: String(slippageBps),
    restrictIntermediateTokens: "true",
  });
  const r = await fetch(`${JUP}/swap/v1/quote?${qs}`, { signal: AbortSignal.timeout(10000) });
  const data = (await r.json()) as JupQuote & { error?: string };
  if (!r.ok || data.error) throw new Error(data.error ?? `Quote failed (${r.status})`);
  return data;
}

export async function buildSwapTx(quote: JupQuote, userPublicKey: string): Promise<string> {
  const r = await fetch(`${JUP}/swap/v1/swap`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      quoteResponse: quote,
      userPublicKey,
      dynamicComputeUnitLimit: true,
      dynamicSlippage: false,
      prioritizationFeeLamports: { priorityLevelWithMaxLamports: { maxLamports: 1_000_000, priorityLevel: "high" } },
    }),
    signal: AbortSignal.timeout(15000),
  });
  const data = (await r.json()) as { swapTransaction?: string; error?: string };
  if (!r.ok || !data.swapTransaction) throw new Error(data.error ?? `Swap build failed (${r.status})`);
  return data.swapTransaction;
}

/** Decimal string → raw integer units without floating point errors. */
export function toRaw(amount: string, decimals: number): bigint {
  const clean = amount.trim();
  if (!/^\d+(\.\d+)?$/.test(clean)) throw new Error("Invalid amount");
  const [whole, frac = ""] = clean.split(".");
  const f = (frac + "0".repeat(decimals)).slice(0, decimals);
  return BigInt(whole) * BigInt(10) ** BigInt(decimals) + BigInt(f || "0");
}

export function fromRaw(raw: string, decimals: number): number {
  return Number(raw) / 10 ** decimals;
}
