// Launch Radar adapters. Server-side only.
//
// Launchpad APIs used here are UNOFFICIAL and change without notice. Every adapter:
//  - reads its base URL from env only (never from the request → no SSRF),
//  - has a hard timeout and response-size cap,
//  - validates every field and drops records that don't pass (addresses, URLs, numbers),
//  - fails soft: one broken provider never breaks the route.
import { CHAINS, type ChainKey } from "./chains";
import { dexFetch, tokensPairs, bestPairPerToken } from "./dexscreener";
import { cleanText, isEvmAddress, isSolAddress, num, safeImageUrl, safeLinkUrl } from "./security";
import type { LaunchItem, LaunchStage } from "@/types/radar";

type Json = Record<string, unknown>;
const obj = (v: unknown): Json => (v && typeof v === "object" && !Array.isArray(v) ? (v as Json) : {});
const arr = (v: unknown): unknown[] => (Array.isArray(v) ? v : []);

const TIMEOUT_MS = 8000;
const MAX_BYTES = 2_000_000;

/** Pump.fun bonding curve: 793.1M tokens (6 decimals) are sold on the curve before graduation. */
const PUMP_CURVE_TOKENS_RAW = 793_100_000 * 1e6;

export interface Provider {
  name: string;
  chains: ChainKey[];
  run(chain: ChainKey): Promise<LaunchItem[]>;
}

async function getJson(url: string, revalidate = 15): Promise<unknown> {
  const res = await fetch(url, {
    headers: { accept: "application/json", "user-agent": "MemeRadar/3.2 (+launch-radar)" },
    signal: AbortSignal.timeout(TIMEOUT_MS),
    next: { revalidate },
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const len = Number(res.headers.get("content-length") ?? 0);
  if (len > MAX_BYTES) throw new Error("Response too large");
  const text = await res.text();
  if (text.length > MAX_BYTES) throw new Error("Response too large");
  return JSON.parse(text) as unknown;
}

function envBase(name: string, fallback: string): string {
  const v = process.env[name];
  if (!v) return fallback;
  // Only allow https base URLs from env.
  return /^https:\/\/[a-z0-9.-]+(\/[\w./-]*)?$/i.test(v) ? v.replace(/\/$/, "") : fallback;
}

function clampPct(n: number): number {
  return Math.max(0, Math.min(100, Math.round(n * 10) / 10));
}

function ts(v: unknown): number | null {
  if (typeof v === "string" && !/^\d+$/.test(v)) {
    const p = Date.parse(v);
    return Number.isFinite(p) ? p : null;
  }
  const n = num(v);
  if (!n) return null;
  return n < 1e12 ? n * 1000 : n; // seconds → ms
}

// ---------------------------------------------------------------- Pump.fun (Solana)

export function parsePumpCoin(raw: unknown): LaunchItem | null {
  const c = obj(raw);
  const mint = cleanText(c.mint, 64);
  if (!isSolAddress(mint)) return null;
  if (c.nsfw === true) return null;
  const symbol = cleanText(c.symbol, 20);
  if (!symbol) return null;
  const complete = c.complete === true;
  const realTokens = c.real_token_reserves != null ? num(c.real_token_reserves) : null;
  const progress = complete ? 100 : realTokens != null && realTokens > 0 ? clampPct((1 - realTokens / PUMP_CURVE_TOKENS_RAW) * 100) : null;
  const stage: LaunchStage = complete ? "graduated" : progress != null && progress >= 85 ? "graduating" : "bonding";
  const creator = cleanText(c.creator, 64);
  const pool = cleanText(c.pump_swap_pool ?? c.raydium_pool, 64);
  return {
    chain: "solana",
    address: mint,
    symbol,
    name: cleanText(c.name, 48),
    imageUrl: safeImageUrl(c.image_uri),
    platform: "Pump.fun",
    stage,
    progress,
    marketCapUsd: c.usd_market_cap != null ? num(c.usd_market_cap) || null : null,
    createdAt: ts(c.created_timestamp),
    creator: isSolAddress(creator) ? creator : null,
    pairAddress: isSolAddress(pool) ? pool : null,
    socials: {
      x: safeLinkUrl(c.twitter),
      telegram: safeLinkUrl(c.telegram),
      website: safeLinkUrl(c.website),
    },
    description: cleanText(c.description, 280),
  };
}

export const pumpfun: Provider = {
  name: "Pump.fun",
  chains: ["solana"],
  async run() {
    const base = envBase("PUMPFUN_API_BASE", "https://frontend-api-v3.pump.fun");
    const q = (sort: string) => `${base}/coins?offset=0&limit=50&sort=${sort}&order=DESC&includeNsfw=false`;
    const [active, fresh] = await Promise.all([getJson(q("last_trade_timestamp")), getJson(q("created_timestamp")).catch(() => [])]);
    const list = [...arr(active), ...arr(fresh)];
    if (list.length === 0) throw new Error("Unexpected response shape");
    return list.map(parsePumpCoin).filter((x): x is LaunchItem => !!x);
  },
};

// ---------------------------------------------------------------- Clanker (Base)

export function parseClankerToken(raw: unknown): LaunchItem | null {
  const t = obj(raw);
  const address = cleanText(t.contract_address ?? t.address, 64);
  if (!isEvmAddress(address)) return null;
  const symbol = cleanText(t.symbol, 20);
  if (!symbol) return null;
  const meta = obj(t.metadata);
  const socials = arr(meta.socialMediaUrls).map((s) => safeLinkUrl(typeof s === "string" ? s : obj(s).url)).filter((s): s is string => !!s);
  const pool = cleanText(t.pool_address, 80);
  return {
    chain: "base",
    address,
    symbol,
    name: cleanText(t.name, 48),
    imageUrl: safeImageUrl(t.img_url),
    platform: "Clanker",
    stage: "new-listing",
    progress: null,
    marketCapUsd: t.market_cap != null ? num(t.market_cap) || null : null,
    createdAt: ts(t.deployed_at ?? t.created_at),
    creator: isEvmAddress(cleanText(t.admin ?? t.requestor_address, 64)) ? cleanText(t.admin ?? t.requestor_address, 64) : null,
    pairAddress: /^0x[a-fA-F0-9]{40}([a-fA-F0-9]{24})?$/.test(pool) ? pool : null,
    socials: {
      x: socials.find((u) => /(?:x|twitter)\.com/i.test(u)) ?? null,
      telegram: socials.find((u) => /t\.me/i.test(u)) ?? null,
      website: safeLinkUrl(meta.website) ?? socials.find((u) => !/(x|twitter)\.com|t\.me|warpcast/i.test(u)) ?? null,
    },
    description: cleanText(meta.description ?? t.description, 280),
  };
}

export const clanker: Provider = {
  name: "Clanker",
  chains: ["base"],
  async run() {
    const base = envBase("CLANKER_API_BASE", "https://www.clanker.world/api");
    const j = obj(await getJson(`${base}/tokens?sort=desc&page=1`));
    const list = arr(j.data ?? j.tokens);
    if (list.length === 0) throw new Error("Unexpected response shape");
    return list.map(parseClankerToken).filter((x): x is LaunchItem => !!x);
  },
};

// ---------------------------------------------------------------- DEXScreener (all chains, official API)
// New token profiles whose first pair is < 6h old (or not listed yet).

export const dexscreenerNew: Provider = {
  name: "DEXScreener",
  chains: ["solana", "bsc", "base", "ethereum"],
  async run(chain) {
    const profiles = arr(await dexFetch("/token-profiles/latest/v1", 20))
      .map(obj)
      .filter((p) => p.chainId === CHAINS[chain].dexId);
    const valid = profiles.filter((p) => {
      const a = cleanText(p.tokenAddress, 64);
      return chain === "solana" ? isSolAddress(a) : isEvmAddress(a);
    });
    const addrs = valid.map((p) => cleanText(p.tokenAddress, 64)).slice(0, 30);
    const pairs = bestPairPerToken(await tokensPairs(chain, addrs));
    const byToken = new Map(pairs.map((p) => [p.baseAddress.toLowerCase(), p]));
    const now = Date.now();
    const out: LaunchItem[] = [];
    for (const prof of valid) {
      const address = cleanText(prof.tokenAddress, 64);
      const pair = byToken.get(address.toLowerCase());
      if (!pair) continue; // no symbol without a pair
      if (pair.createdAt && now - pair.createdAt > 6 * 3_600_000) continue;
      const links = arr(prof.links).map(obj);
      const link = (re: RegExp) => links.map((l) => safeLinkUrl(l.url)).find((u) => !!u && re.test(u)) ?? null;
      out.push({
        chain,
        address,
        symbol: pair.baseSymbol,
        name: pair.baseName,
        imageUrl: safeImageUrl(prof.icon) ?? pair.imageUrl,
        platform: "DEXScreener",
        stage: "new-listing",
        progress: null,
        marketCapUsd: pair.marketCap || pair.fdv || null,
        createdAt: pair.createdAt,
        creator: null,
        pairAddress: pair.pairAddress,
        socials: { x: link(/(?:x|twitter)\.com/i), telegram: link(/t\.me/i), website: pair.websites[0] ?? null },
        description: cleanText(prof.description, 280),
      });
    }
    return out;
  },
};

export const PROVIDERS: Provider[] = [pumpfun, clanker, dexscreenerNew];

export function enabledProviders(chain: ChainKey): Provider[] {
  const allow = (process.env.LAUNCH_PROVIDERS ?? "").toLowerCase().split(",").map((s) => s.trim()).filter(Boolean);
  return PROVIDERS.filter((p) => p.chains.includes(chain) && (allow.length === 0 || allow.includes(p.name.toLowerCase())));
}

const STAGE_ORDER: Record<LaunchStage, number> = { graduating: 0, bonding: 1, "new-listing": 2, graduated: 3 };

/** Merge (launchpad data wins over DEXScreener), then sort: graduating → bonding → new → graduated. */
export function mergeLaunches(lists: LaunchItem[][], limit = 48): LaunchItem[] {
  const map = new Map<string, LaunchItem>();
  for (const list of lists) {
    for (const it of list) {
      const k = it.address.toLowerCase();
      const cur = map.get(k);
      if (!cur || (cur.platform === "DEXScreener" && it.platform !== "DEXScreener")) map.set(k, { ...it, pairAddress: it.pairAddress ?? cur?.pairAddress ?? null });
    }
  }
  return [...map.values()]
    .sort(
      (a, b) =>
        STAGE_ORDER[a.stage] - STAGE_ORDER[b.stage] ||
        (b.progress ?? -1) - (a.progress ?? -1) ||
        (b.createdAt ?? 0) - (a.createdAt ?? 0),
    )
    .slice(0, limit);
}
