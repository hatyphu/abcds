import { CHAINS, type ChainKey } from "./chains";

/** External tool links. All path params are validated addresses, still URI-encoded defensively. */
export function toolLinks(chain: ChainKey, token: string, pair: string) {
  const c = CHAINS[chain];
  const t = encodeURIComponent(token);
  const p = encodeURIComponent(pair);
  return [
    { name: "GMGN", url: `https://gmgn.ai/${c.gmgn}/token/${t}` },
    { name: "DEXScreener", url: `https://dexscreener.com/${c.dexId}/${p}` },
    { name: "Birdeye", url: `https://birdeye.so/token/${t}?chain=${c.birdeye}` },
    { name: "DEXTools", url: `https://www.dextools.io/app/en/${c.dextools}/pair-explorer/${p}` },
    ...(chain === "solana" ? [{ name: "RugCheck", url: `https://rugcheck.xyz/tokens/${t}` }] : []),
    { name: "Bubblemaps", url: `https://app.bubblemaps.io/${c.bubblemaps}/token/${t}` },
  ];
}

export function photonUrl(chain: ChainKey, pair: string): string | null {
  // Photon trading terminal currently routes Solana pairs.
  return chain === "solana" ? `https://photon-sol.tinyastro.io/en/lp/${encodeURIComponent(pair)}` : null;
}

export function dexSwapUrl(chain: ChainKey, token: string): string {
  const t = encodeURIComponent(token);
  if (chain === "bsc") return `https://pancakeswap.finance/swap?chain=bsc&inputCurrency=BNB&outputCurrency=${t}`;
  if (chain === "base") return `https://app.uniswap.org/swap?chain=base&inputCurrency=ETH&outputCurrency=${t}`;
  if (chain === "ethereum") return `https://app.uniswap.org/swap?chain=mainnet&inputCurrency=ETH&outputCurrency=${t}`;
  return `https://jup.ag/swap/SOL-${t}`;
}

export function chartEmbedUrl(chain: ChainKey, pair: string): string {
  return `https://dexscreener.com/${CHAINS[chain].dexId}/${encodeURIComponent(pair)}?embed=1&theme=dark&trades=0&info=0`;
}
