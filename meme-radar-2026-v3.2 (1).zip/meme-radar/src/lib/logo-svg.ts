// Deterministic mascot SVG (data: URI) from a token symbol. Shared by server and client components.
const cache = new Map<string, string>();

function hash(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

/** Deterministic mascot SVG (data: URI) from the symbol. No user text goes into the SVG. */
export function fallbackLogo(symbol: string): string {
  const hit = cache.get(symbol);
  if (hit) return hit;
  let h = hash(symbol || "?");
  const r = (n: number) => {
    h = (Math.imul(h, 1103515245) + 12345) >>> 0;
    return h % n;
  };
  const hue = r(360);
  const hue2 = (hue + 40 + r(80)) % 360;
  const type = r(4);
  const skin = `hsl(${(hue + 180) % 360},70%,${55 + r(15)}%)`;
  const bodies = [
    `<ellipse cx="32" cy="38" rx="19" ry="16" fill="${skin}"/><circle cx="24" cy="25" r="7" fill="${skin}"/><circle cx="40" cy="25" r="7" fill="${skin}"/>`,
    `<path d="M14 26 L20 10 L28 22 Z M50 26 L44 10 L36 22 Z" fill="${skin}"/><circle cx="32" cy="35" r="18" fill="${skin}"/>`,
    `<path d="M13 44 Q12 18 32 16 Q52 18 51 44 Q32 54 13 44Z" fill="${skin}"/>`,
    `<circle cx="32" cy="34" r="19" fill="${skin}"/><path d="M15 26 Q32 4 49 26 Z" fill="hsl(${hue2},80%,30%)"/>`,
  ];
  const ey = type === 0 ? 26 : type === 2 ? 30 : 32;
  const ex = 8;
  const eyes =
    `<circle cx="${32 - ex}" cy="${ey}" r="5" fill="#fff"/><circle cx="${32 + ex}" cy="${ey}" r="5" fill="#fff"/>` +
    `<circle cx="${33 - ex}" cy="${ey + 1}" r="2.4" fill="#111"/><circle cx="${33 + ex}" cy="${ey + 1}" r="2.4" fill="#111"/>`;
  const my = ey + 11;
  const mouth = `<path d="M25 ${my} Q32 ${my + 7} 39 ${my}" stroke="#111" stroke-width="2.4" fill="none" stroke-linecap="round"/>`;
  const svg =
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">` +
    `<stop offset="0" stop-color="hsl(${hue},75%,58%)"/><stop offset="1" stop-color="hsl(${hue2},70%,38%)"/></linearGradient></defs>` +
    `<circle cx="32" cy="32" r="32" fill="url(#g)"/>${bodies[type]}${eyes}${mouth}</svg>`;
  const uri = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
  cache.set(symbol, uri);
  return uri;
}
