// Server-side helpers for the public DEXScreener API (no key required).
// Docs: https://docs.dexscreener.com/api/reference
import { chainFromDexId, type ChainKey } from "./chains";
import { cleanText, num, safeImageUrl, safeLinkUrl } from "./security";
import type { RadarPair } from "@/types/radar";

const BASE = "https://api.dexscreener.com";
const TIMEOUT_MS = 8000;

type Json = Record<string, unknown>;

function obj(v: unknown): Json {
  return v && typeof v === "object" && !Array.isArray(v) ? (v as Json) : {};
}

export async function dexFetch(path: string, revalidate = 15): Promise<unknown> {
  const res = await fetch(`${BASE}${path}`, {
    headers: { accept: "application/json" },
    signal: AbortSignal.timeout(TIMEOUT_MS),
    next: { revalidate },
  });
  if (!res.ok) throw new Error(`DEXScreener ${res.status}`);
  return res.json();
}

export function normalisePair(raw: unknown): RadarPair | null {
  const p = obj(raw);
  const chain = chainFromDexId(String(p.chainId ?? ""));
  if (!chain) return null;
  const base = obj(p.baseToken);
  const quote = obj(p.quoteToken);
  const txns = obj(p.txns);
  const t5 = obj(txns.m5);
  const t1 = obj(txns.h1);
  const t6 = obj(txns.h6);
  const t24 = obj(txns.h24);
  const vol = obj(p.volume);
  const pc = obj(p.priceChange);
  const info = obj(p.info);
  const boosts = obj(p.boosts);
  const pairAddress = cleanText(p.pairAddress, 80);
  const baseAddress = cleanText(base.address, 80);
  if (!pairAddress || !baseAddress) return null;

  const websites = Array.isArray(info.websites)
    ? info.websites.map((w) => safeLinkUrl(obj(w).url)).filter((u): u is string => !!u).slice(0, 3)
    : [];
  const socials = Array.isArray(info.socials)
    ? info.socials
        .map((s) => ({ type: cleanText(obj(s).type, 16), url: safeLinkUrl(obj(s).url) }))
        .filter((s): s is { type: string; url: string } => !!s.url)
        .slice(0, 4)
    : [];

  return {
    chain,
    pairAddress,
    dexId: cleanText(p.dexId, 32),
    url: safeLinkUrl(p.url),
    baseAddress,
    baseSymbol: cleanText(base.symbol, 20) || "?",
    baseName: cleanText(base.name, 48),
    quoteAddress: cleanText(quote.address, 80),
    quoteSymbol: cleanText(quote.symbol, 20),
    priceUsd: num(p.priceUsd),
    priceNative: num(p.priceNative),
    change5m: num(pc.m5),
    change1h: num(pc.h1),
    change6h: num(pc.h6),
    change24h: num(pc.h24),
    volume5m: num(vol.m5),
    volume1h: num(vol.h1),
    volume6h: num(vol.h6),
    volume24h: num(vol.h24),
    buys5m: num(t5.buys),
    sells5m: num(t5.sells),
    buys1h: num(t1.buys),
    sells1h: num(t1.sells),
    buys6h: num(t6.buys),
    sells6h: num(t6.sells),
    buys24h: num(t24.buys),
    sells24h: num(t24.sells),
    liquidityUsd: num(obj(p.liquidity).usd),
    fdv: num(p.fdv),
    marketCap: num(p.marketCap),
    createdAt: num(p.pairCreatedAt) || null,
    imageUrl: safeImageUrl(info.imageUrl),
    boosts: num(boosts.active),
    websites,
    socials,
  };
}

/** Keep the most liquid pair per base token. */
export function bestPairPerToken(pairs: RadarPair[]): RadarPair[] {
  const map = new Map<string, RadarPair>();
  for (const p of pairs) {
    const k = `${p.chain}:${p.baseAddress.toLowerCase()}`;
    const cur = map.get(k);
    if (!cur || p.liquidityUsd > cur.liquidityUsd) map.set(k, p);
  }
  return [...map.values()];
}

export async function searchPairs(q: string): Promise<RadarPair[]> {
  const data = obj(await dexFetch(`/latest/dex/search?q=${encodeURIComponent(q)}`, 10));
  const pairs = Array.isArray(data.pairs) ? data.pairs : [];
  return pairs.map(normalisePair).filter((p): p is RadarPair => !!p);
}

export async function tokensPairs(chain: ChainKey, addresses: string[]): Promise<RadarPair[]> {
  if (addresses.length === 0) return [];
  const chunks: string[][] = [];
  for (let i = 0; i < addresses.length; i += 30) chunks.push(addresses.slice(i, i + 30));
  const results = await Promise.all(
    chunks.map((c) =>
      dexFetch(`/tokens/v1/${chain}/${c.map(encodeURIComponent).join(",")}`, 15).catch(() => []),
    ),
  );
  return results
    .flatMap((r) => (Array.isArray(r) ? r : []))
    .map(normalisePair)
    .filter((p): p is RadarPair => !!p);
}

/** Trending = most-boosted + latest profiles on DEXScreener, filtered by chain. */
export async function trending(chain: ChainKey): Promise<RadarPair[]> {
  const [top, latest, profiles] = await Promise.all([
    dexFetch("/token-boosts/top/v1", 30).catch(() => []),
    dexFetch("/token-boosts/latest/v1", 30).catch(() => []),
    dexFetch("/token-profiles/latest/v1", 30).catch(() => []),
  ]);
  const seen = new Set<string>();
  const addrs: string[] = [];
  for (const list of [top, latest, profiles]) {
    if (!Array.isArray(list)) continue;
    for (const item of list) {
      const o = obj(item);
      if (o.chainId !== chain) continue;
      const a = cleanText(o.tokenAddress, 80);
      if (a && !seen.has(a)) {
        seen.add(a);
        addrs.push(a);
      }
      if (addrs.length >= 60) break;
    }
  }
  return bestPairPerToken(await tokensPairs(chain, addrs));
}
