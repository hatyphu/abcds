export function usd(n: number): string {
  if (!n) return "$0";
  const a = Math.abs(n);
  if (a >= 1e9) return `$${(n / 1e9).toFixed(2)}B`;
  if (a >= 1e6) return `$${(n / 1e6).toFixed(2)}M`;
  if (a >= 1e3) return `$${(n / 1e3).toFixed(1)}K`;
  return `$${n.toFixed(0)}`;
}

export function price(n: number): string {
  if (!n) return "$0";
  if (n >= 1) return `$${n.toLocaleString("en-US", { maximumFractionDigits: 4 })}`;
  // 0.0000123 → $0.0₅123 (DEXScreener style subscript zeros)
  const s = n.toFixed(12);
  const m = /^0\.(0+)(\d{1,4})/.exec(s);
  if (m && m[1].length >= 4) {
    const sub = String(m[1].length).split("").map((d) => "₀₁₂₃₄₅₆₇₈₉"[Number(d)]).join("");
    return `$0.0${sub}${m[2]}`;
  }
  return `$${n.toPrecision(4)}`;
}

export function pct(n: number): string {
  if (!Number.isFinite(n)) return "–";
  return `${n > 0 ? "+" : ""}${n.toFixed(Math.abs(n) >= 100 ? 0 : 1)}%`;
}

export function age(ts: number | null): string {
  if (!ts) return "–";
  const m = Math.max(0, (Date.now() - ts) / 60000);
  if (m < 60) return `${Math.floor(m)}m`;
  const h = m / 60;
  if (h < 48) return `${Math.floor(h)}h`;
  const d = h / 24;
  if (d < 60) return `${Math.floor(d)}d`;
  return `${Math.floor(d / 30)}mo`;
}

export function shortAddr(a: string): string {
  return a.length > 12 ? `${a.slice(0, 4)}…${a.slice(-4)}` : a;
}
