# MEME COIN RADAR 2026 — V3.2 Ultimate Fusion

Một sản phẩm của **Petalabs AI**.

GMGN + DEXScreener + Birdeye + Photon + BullX + DEXTools + RugCheck + Bubblemaps  
Multi-chain: **Solana · BNB Chain · Base · Ethereum** — **100% non-custodial, no auto-trading.**

Base template: https://github.com/JCodesMore/ai-website-cloner-template (Next.js 16 · React 19 · Tailwind v4)

## Chạy dự án / Run

Yêu cầu Node **24+** (xem `.nvmrc`).

```bash
npm install
cp .env.example .env.local      # điền BIRDEYE_API_KEY và NEXT_PUBLIC_WC_PROJECT_ID
npm run dev                     # http://localhost:3000 (trang chủ) · /app (terminal)
npm run check                   # lint + typecheck + build
```

## Kiểm tra QR bằng MetaMask Mobile

1. Lấy Project ID tại https://cloud.reown.com, điền `NEXT_PUBLIC_WC_PROJECT_ID`, và thêm `http://localhost:3000` vào danh sách domain cho phép trong dashboard.
2. `npm run dev` → mở http://localhost:3000/app → **Connect** → **WalletConnect**.
3. Điện thoại: MetaMask Mobile → biểu tượng quét (góc trên phải) → quét mã → **Connect**. Địa chỉ ví hiện trên header.
4. Kiểm tra tự động (máy tính): trong terminal khác chạy `npx playwright install chromium` (một lần) rồi `npm run verify:qr`.
   Script giải mã ảnh QR bằng jsQR, so với URI `wc:…@2?relay-protocol=irn&symKey=…`, lưu ảnh `qr-check.png`.

Không có Project ID: nút WalletConnect hiển thị QR deep-link `https://metamask.app.link/dapp/<site>` — quét sẽ mở trang trong trình duyệt của MetaMask Mobile. Deep-link chỉ hoạt động khi site truy cập được từ điện thoại (deploy HTTPS hoặc dùng IP LAN, không phải `localhost`).

## Kiến trúc

| Phần | File |
|---|---|
| Landing page bán hàng (/) | `src/app/page.tsx`, `src/components/site/*` |
| Terminal radar (/app) | `src/app/app/page.tsx` |
| Proxy DEXScreener (trending / search / token) | `src/app/api/dex/route.ts` |
| Proxy Birdeye + RugCheck (security) | `src/app/api/security/route.ts` |
| Ví Phantom / MetaMask (EIP-6963) / WalletConnect v2 | `src/hooks/use-wallet.ts`, `src/lib/walletconnect.ts` |
| QR (qrcodejs từ cdnjs, `new QRCode()`) | `src/components/radar/qr-code.tsx` |
| Terminal: Direct Trade / Route to Photon | `src/components/radar/trade-terminal.tsx` |
| Risk score kiểu RugCheck | `src/lib/risk.ts` |
| Nến OHLCV (GeckoTerminal → Birdeye) | `src/app/api/ohlcv/route.ts`, `src/lib/ohlcv.ts` |
| Biểu đồ nến (canvas, 1m→1d, hover OHLC) | `src/components/radar/candle-chart.tsx` |
| Launch Radar API (Pump.fun, Clanker, DEXScreener) | `src/app/api/launches/route.ts`, `src/lib/launches.ts` |
| Launch Radar UI + cảnh báo graduation | `src/components/radar/launch-radar.tsx` |
| Logo token (ảnh thật, fallback linh vật SVG) | `src/components/radar/token-logo.tsx` |

**Direct Trade:** Solana dùng Jupiter (quote → giao dịch → ký trong Phantom). BNB/Base/ETH mở PancakeSwap/Uniswap với địa chỉ token điền sẵn; người dùng ký trong ví của mình.  
**Route to Photon:** mở cặp trong `photon-sol.tinyastro.io` (Photon chỉ hỗ trợ Solana).

## Biểu đồ nến

`GET /api/ohlcv?chain=solana&pair=<pairAddress>&tf=5m` (tf: 1m, 5m, 15m, 1h, 4h, 1d).
Lấy từ GeckoTerminal (miễn phí, không cần key, ~30 request/phút, cache 20–45 giây). Nếu GeckoTerminal lỗi hoặc chưa có dữ liệu và có `BIRDEYE_API_KEY` thì dùng Birdeye. Nến được kiểm tra (số hữu hạn, giá > 0, high ≥ low, bỏ trùng), sắp xếp, tối đa 300 nến. Nến cuối được cập nhật theo giá live từ feed.

## Launch Radar

`GET /api/launches?chain=solana` — bấm **Scan now** trong tab Launch Radar.

| Chain | Nguồn | Giai đoạn |
|---|---|---|
| Solana | Pump.fun (API không chính thức) | Bonding, Graduating soon (curve ≥ 85%), Graduated |
| Base | Clanker (API không chính thức) | New listing |
| Tất cả | DEXScreener token profiles mới (API chính thức), cặp < 6 giờ | New listing |

Tiến độ bonding curve Pump.fun = `1 − real_token_reserves / 793.1M token`. Sau khi quét, dữ liệu tự làm mới mỗi 20 giây; bật **Alert me at graduation** để nhận thông báo (toast + thông báo trình duyệt) khi token graduate. Không có auto-buy hay snipe.

Các API launchpad là không chính thức và có thể đổi bất cứ lúc nào, nên mỗi adapter:
- chỉ đọc base URL từ env (`PUMPFUN_API_BASE`, `CLANKER_API_BASE`, chỉ chấp nhận https) — không bao giờ từ request, tránh SSRF;
- có timeout 8 giây và giới hạn kích thước phản hồi 2 MB;
- kiểm tra từng trường (địa chỉ, link chỉ http(s), ảnh chỉ https, bỏ ký tự điều khiển/bidi) và bỏ bản ghi không hợp lệ;
- lỗi riêng lẻ: một nguồn hỏng không làm hỏng route, trạng thái từng nguồn hiện trên UI.
Tắt bớt nguồn bằng `LAUNCH_PROVIDERS=pump.fun,dexscreener`. Pump.fun có thể chặn request từ server (Cloudflare) — khi đó chip nguồn hiện "unavailable", các nguồn khác vẫn chạy.

## Phân tích & dự đoán (khi khách bấm vào token)

Khung **Phân tích & dự đoán** nằm ngay dưới biểu đồ nến (`src/lib/analysis.ts`, `src/components/radar/analysis-panel.tsx`). Nó chấm 9 yếu tố có trọng số:

| Yếu tố | Dữ liệu |
|---|---|
| Động lượng giá (5m/1h/24h, trừ điểm khi tăng quá nóng) | DEXScreener |
| Lực mua / bán (1h, 5m) | DEXScreener |
| Mức độ sôi động (volume 1h / thanh khoản, cảnh báo wash-trade) | DEXScreener |
| Thanh khoản, Vốn hoá / thanh khoản, Tuổi token | DEXScreener |
| Xu hướng EMA9/EMA21, RSI(14), hỗ trợ / kháng cự gần | Nến GeckoTerminal / Birdeye |
| An toàn hợp đồng | Birdeye + RugCheck |

Kết quả: **NÊN MUA** (≥ 70) · **CÓ THỂ CÂN NHẮC** (55–69) · **THEO DÕI, CHƯA MUA** (40–54) · **KHÔNG NÊN MUA** (< 40), hiển thị tỷ lệ **Mua x% / Không mua y%**, tóm tắt điểm cộng/trừ và câu kết *"Quyết định là ở bạn. Chúc bạn x tài khoản!"*.
Chặn cứng: honeypot → tối đa 3%; thuế bán > 20% → 10%; rủi ro EXTREME → 20%; HIGH → 45%; thanh khoản < $5K → 30%; RSI > 80 → 65%.
Tỷ lệ % là **điểm tín hiệu theo trọng số**, không phải xác suất có lãi — giao diện ghi rõ điều này.

## Bảo mật

- `BIRDEYE_API_KEY` chỉ ở server (route `/api/security`), không bao giờ gửi xuống trình duyệt.
- Mọi tham số API được kiểm tra bằng regex (địa chỉ Solana base58 / EVM 0x, từ khóa tìm kiếm) và `encodeURIComponent`.
- Dữ liệu từ API bên ngoài được chuẩn hóa ở server: link chỉ `http(s)`, ảnh chỉ `https`, loại ký tự điều khiển/bidi (chống giả mạo tên token).
- Rate-limit theo IP trên các route API, timeout cho mọi fetch, lỗi upstream không lộ chi tiết.
- Header: CSP chặt (chỉ cdnjs, Jupiter, WalletConnect; biểu đồ vẽ tại chỗ, không nhúng iframe ngoài), `frame-ancestors 'none'`, nosniff, Referrer-Policy, Permissions-Policy, HSTS (production).
- Không bao giờ hỏi seed phrase/private key; mọi giao dịch do người dùng ký. Cảnh báo + bắt xác nhận khi risk HIGH/EXTREME, chặn khi price impact > 25%, giới hạn slippage ≤ 50%.
- Rate-limit dùng bộ nhớ trong — khi chạy nhiều instance hãy chuyển sang Redis/Upstash.

> Thông tin chỉ mang tính tham khảo, không phải lời khuyên tài chính.

## Lưu ý khi triển khai

- **Chạy `npm install` một lần trước khi build Docker / CI.** Dự án thêm `@walletconnect/sign-client`, `@solana/web3.js`, `jsqr`, `playwright` nên `package-lock.json` cần được cập nhật; `npm ci` (Dockerfile, GitHub Actions) sẽ báo lock file không khớp cho tới khi bạn commit lock file mới.
- **Rate-limit dựa trên `x-forwarded-for`.** Trên Vercel hoặc sau reverse proxy (Nginx, Cloudflare) header này do proxy đặt nên tin được. Nếu chạy Node trực tiếp ra Internet không qua proxy, người dùng có thể giả header để né giới hạn — hãy đặt app sau proxy.
- **GeckoTerminal giới hạn ~30 request/phút cho mỗi IP server.** Nến được cache 20–45 giây theo từng cặp, nhưng khi nhiều người xem nhiều cặp khác nhau cùng lúc, hãy đặt `BIRDEYE_API_KEY` để có nguồn dự phòng.
