// Verifies that the wallet QR code rendered by qrcodejs is really scannable.
// Usage: npm run dev   (in another terminal)   then   npm run verify:qr [url]
// It opens the page, clicks Connect → WalletConnect, decodes the QR image with jsQR
// and checks the decoded text equals the WalletConnect v2 URI (or MetaMask deep link).
import { chromium } from "playwright";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
const jsqrPath = require.resolve("jsqr/dist/jsQR.js");
const url = process.argv[2] ?? "http://localhost:3000/app";

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
try {
  await page.goto(url, { waitUntil: "networkidle" });
  await page.getByRole("button", { name: /connect/i }).first().click();
  await page.getByRole("button", { name: /walletconnect/i }).click();
  await page.waitForSelector('[data-testid="qr"] img[src^="data:image"]', { timeout: 20000 });
  await page.addScriptTag({ path: jsqrPath });

  const result = await page.evaluate(async () => {
    const holder = document.querySelector('[data-testid="qr"]');
    const img = holder.querySelector("img");
    await img.decode().catch(() => {});
    const pad = 32;
    const c = document.createElement("canvas");
    c.width = img.naturalWidth + pad * 2;
    c.height = img.naturalHeight + pad * 2;
    const ctx = c.getContext("2d");
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, c.width, c.height);
    ctx.drawImage(img, pad, pad);
    const data = ctx.getImageData(0, 0, c.width, c.height);
    // eslint-disable-next-line no-undef
    const code = jsQR(data.data, c.width, c.height);
    return { expected: holder.getAttribute("data-value"), decoded: code?.data ?? null };
  });

  await page.locator('[data-testid="qr-wrapper"]').screenshot({ path: "qr-check.png" });

  const ok = result.decoded && result.decoded === result.expected;
  const isWc = /^wc:[0-9a-f]{64}@2\?.*relay-protocol=irn.*symKey=[0-9a-f]{64}/.test(result.decoded ?? "");
  const isDeepLink = /^https:\/\/metamask\.app\.link\/dapp\//.test(result.decoded ?? "");
  console.log("Decoded :", result.decoded);
  console.log("Expected:", result.expected);
  console.log("Format  :", isWc ? "WalletConnect v2 pairing URI (MetaMask Mobile → Scan)" : isDeepLink ? "MetaMask Mobile deep link" : "UNKNOWN");
  console.log("Saved   : qr-check.png");
  if (!ok || (!isWc && !isDeepLink)) {
    console.error("❌ QR verification FAILED");
    process.exitCode = 1;
  } else {
    console.log("✅ QR is scannable and matches the pairing value");
  }
} finally {
  await browser.close();
}
